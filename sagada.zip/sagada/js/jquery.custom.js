var sID;
$(document).ready(function(){
		$(".sub-nav-button li ul").hide(); // Hide all sub menus
		$(".sub-nav-button li div.nav-ul-selected").parent().find("ul").slideToggle("fast"); // Slide down the current menu item's sub menu
		
		$(".sub-nav-button li div.nav-ul").click( // When a top menu item is clicked...
			function () {
				$(this).parent().siblings().find("ul").slideUp("fast"); // Slide up all sub menus except the one clicked
				$(this).next().slideToggle("fast"); // Slide down the clicked sub menu
				return false;
			}
		);
		
		$(".sub-nav-button li a.no-submenu").click( // When a menu item with no sub menu is clicked...
			function () {
				window.location.href=(this.href); // Just open the link instead of a sub menu
				return false;
			}
		); 
		
		$("div[class^='nav-ul']").hover(
			function () {
				$(this).stop().animate({ paddingRight: "25px" }, 20);
			}, 
			function () {
				$(this).stop().animate({ paddingRight: "5px" });
			}
		);
		//Minimize Content Box
		
		$(".content-box-header h3").css({ "cursor":"s-resize" }); // Give the h3 in Content Box Header a different cursor
		$(".closed-box .content-box-content").hide(); // Hide the content of the header if it has the class "closed"
		$(".closed-box .content-box-tabs").hide(); // Hide the tabs in the header if it has the class "closed"
		
		$(".content-box-header h3").click( // When the h3 is clicked...
			function () {
			  $(this).parent().next().toggle(); // Toggle the Content Box
			  $(this).parent().parent().toggleClass("closed-box"); // Toggle the class "closed-box" on the content box
			  $(this).parent().find(".content-box-tabs").toggle(); // Toggle the tabs
			}
		);

    // Content box tabs:
		
		$('.content-box .content-box-content div.tab-content').hide(); // Hide the content divs
		$('ul.content-box-tabs li a.default-tab').addClass('current'); // Add the class "current" to the default tab
		$('.content-box-content div.default-tab').show(); // Show the div with class "default-tab"
		
		$('.content-box ul.content-box-tabs li a').click( // When a tab is clicked...
			function() { 
				$(this).parent().siblings().find("a").removeClass('current'); // Remove "current" class from all tabs
				$(this).addClass('current'); // Add class "current" to clicked tab
				var currentTab = $(this).attr('href'); // Set variable "currentTab" to the value of href of clicked tab
				$(currentTab).siblings().hide(); // Hide all content divs
				$(currentTab).show(); // Show the content div with the id equal to the id of clicked tab
				return false; 
			}
		);
		$(".close").click(
			function () {
				$(this).parent().fadeTo(400, 0, function () { // Links with the class "close" will close parent
					$(this).slideUp(400);
				});
				return false;
			}
		);
		$('tbody tr:even').addClass("alt-row"); // Add class "alt-row" to even table rows
});
new function($) {
	$.fn.setCursorPosition = function(pos) {
	if ($(this).get(0).setSelectionRange) {
		 $(this).get(0).setSelectionRange(pos, pos);
	} else if ($(this).get(0).createTextRange) {
		 var range = $(this).get(0).createTextRange();
		 range.collapse(true);
		 range.moveEnd('character', pos);
		 range.moveStart('character', pos);
		 range.select();
		}
	}
}(jQuery);

new function($) {
	$.fn.setPrint = function(num) {
		var mode = Array();
   
	   if(typeof(jsPrintSetup) == "undefined" || jsPrintSetup == null) window.print();
	   else {
	   mode[1]= jsPrintSetup.kLandscapeOrientation;
	   mode[2]= jsPrintSetup.kPortraitOrientation;
	   // set orientation
	   jsPrintSetup.setOption('orientation', mode[num]);
	   // set empty page header
	   jsPrintSetup.setOption('headerStrLeft', '');
	   jsPrintSetup.setOption('headerStrCenter', '');
	   jsPrintSetup.setOption('headerStrRight', '');
	   // set empty page footer
	   jsPrintSetup.setOption('footerStrLeft', '');
	   jsPrintSetup.setOption('footerStrCenter', '');
	   jsPrintSetup.setOption('footerStrRight', '');
	   // clears user preferences always silent print value
	   // to enable using 'printSilent' option
	   jsPrintSetup.clearSilentPrint();
	   // Suppress print dialog (for this context only)
	   jsPrintSetup.setOption('printSilent', 1);
	   // Do Print 
	   // When print is submitted it is executed asynchronous and
	   // script flow continues after print independently of completetion of print process! 
	   jsPrintSetup.print();
	   // next commands
	   }
   }
}(jQuery);

new function($) {
	$.fn.showCoords = function(c) {
	jQuery('#pos-x').val(c.x);
	jQuery('#pos-y').val(c.y);
	}
}(jQuery);
  
new function($) {
	$.fn.eventNavClicked = function() {
	$("div[class^='nav-mid-button']").unbind('click').click(function(event) { 
		event.preventDefault();

		if($(this).attr('class')!='nav-mid-button-selected') {
			$("div[class^='nav-mid-button-selected']").each(function() { 
				if($(this).attr('class')=='nav-mid-button-selected nav-left-border')
					$(this).attr('class','nav-mid-button nav-left-border');
				else
					$(this).attr('class','nav-mid-button');
			})
			
			if($(this).attr('class')=='nav-mid-button nav-left-border')
				$(this).attr('class','nav-mid-button-selected nav-left-border');
			else
				$(this).attr('class','nav-mid-button-selected');
		}
		$(".content").load($(this).attr('link')+'.php', "",
			function(responseText, textStatus, XMLHttpRequest) {
			if(textStatus == 'success') {	
					$.fn.eventTabClicked();
					$.fn.eventNavClicked();
					$.fn.eventPopup();
					$.fn.setMore();
					$.fn.setChkBox();
					$.fn.eventSearch();
					$.fn.eventMainPage();
			}
		});
		
	})
	}
}(jQuery); 
  
new function($) {
	$.fn.eventTabClicked = function() {
	$("div[class^='tab']").unbind('click').click(function(event) { 
		event.preventDefault();

		if($(this).attr('class')!='tab-selected') {
			$("div[class^='tab']").attr('class','tab');
			$(this).attr('class','tab-selected');
		}
		
		var link = $(this).attr('link');
		var parseLink = link.split('?');
		
		if(parseLink.length>1)
				var gid = '?acc='+parseLink[1];
			else
				var gid = '';
					
		$(".sub-content").load(parseLink[0]+'.php'+gid, "",
			function(responseText, textStatus, XMLHttpRequest) {
			if(textStatus == 'success') {	
					$.fn.eventPopup(); $.fn.eventTabClicked(); $.fn.setMore(); $.fn.setChkBox(); $.fn.eventSearch(); $.fn.printEvent(); $.fn.eventMainPage();
			}
		});	
	})
	
	$("div[class^='cview-button']").unbind('click').click(function(event) { 
		
			var link = $(this).attr('link');
			
			
					
		$(this).parents('.sub-content').load(link+'.php', "",
			function(responseText, textStatus, XMLHttpRequest) {
			if(textStatus == 'success') {	
					$.fn.eventPopup(); $.fn.eventTabClicked(); $.fn.setMore(); $.fn.setChkBox(); $.fn.eventSearch(); $.fn.printEvent(); $.fn.eventMainPage();
			}
		});	
	})
	
	$("div[class^='pagination-button']").unbind('click').click(function(event) { 
		event.preventDefault();

		$(this).parents('ul').children().children().attr('class','pagination-button');
		if($(this).attr('class')!='pagination-button-selected') {
			$(this).attr('class','pagination-button-selected');
		
		
			var link = $(this).attr('link');
			
			var parseLink = link.split('?');
			
			if(parseLink.length>1)
				var gid = '?'+parseLink[1];
			else
				var gid = '';
				
			$(this).parents('.sub-content, .popup-main').load(parseLink[0]+'.php'+gid, "",
				function(responseText, textStatus, XMLHttpRequest) {
				if(textStatus == 'success') {	
						$.fn.eventTabClicked(); $.fn.closeButton(); $.fn.eventPopup(); $.fn.eventSave(); $.fn.setChkBox(); $.fn.setMore(); $.fn.eventSearch(); $.fn.printEvent(); $.fn.eventMainPage();
						$(this).Drags({	handler: '.popup-header' });
				}
			});	
		
		}
	})
	}
}(jQuery);

new function($) {
	$.fn.addCommas = function(num,nul) {
	num = num.toString().replace(/\$|\,/g,'');
	if(isNaN(num))
	num = "0";
	sign = (num == (num = Math.abs(num)));
	num = Math.floor(num*100+0.50000000001);
	cents = num%100;
	num = Math.floor(num/100).toString();
	for (var i = 0; i < Math.floor((num.length-(1+i))/3); i++)
	num = num.substring(0,num.length-(4*i+3))+','+num.substring(num.length-(4*i+3));
	if(nul=='') if(num==0) num = '';
	return (num);
	}
}(jQuery);

new function($) {
	$.fn.checkPercent = function(num) {
	if(isNaN(num))
		num = 0;
		
	if(num>=100)
		num = 100;
		

	return (num);
	}
}(jQuery);

new function($) {
	$.fn.customDatepicker = function() {
	var datepicker_html = '<div class="datepicker-box"><input class="datepicker-text" type="text" /><div class="datepicker-button"></div><div class="calendar-box"><table class="calendar-title"><tr><td width="10%" align="right"><span class="prebutt">◄</span></td><td align="center"></td><td width="10%"><span class="nexbutt">►</span></td></tr></table><table class="cnotable"><tr class="calendar-day"><td>Min</td><td>Sen</td><td>Sel</td><td>Rab</td><td>Kam</td><td>Jum</td><td>Sab</td></tr></table></div></div>';
	
	$("input[type^='datepicker']").each(function() { 
		var dtName = $(this).attr('name');
		var dtVal = $(this).attr('value');
		
		$(this).replaceWith(datepicker_html);
		$('.datepicker-text:last').attr('name',dtName).attr('value',dtVal);
		$("div[class^='datepicker-button'],span[class^='prebutt'],span[class^='nexbutt'],tr[class^='calendar-day'],table[class^='calendar-title'],input[class^='datepicker-text']").unbind('click').click(function(e) { 
				if($(this).parent().children('.calendar-box').css('display')=='none') {
					$("div[class^='calendar-box']").slideUp(100);
					$(this).parent().children('.calendar-box').css('z-index',212).show();
					$.fn.setCalender($(this).parent().children(':eq(0)').val(),$(this));
				}
				e.stopPropagation();
		})	
		$('html,body').unbind('click').click(function() { 
			$("div[class^='calendar-box']").slideUp(100,function() { $(this).removeAttr('style') });
		})
	})
	}
}(jQuery);

new function($) {
	$.fn.setCalender = function(value,obj) {
	var cal_months_labels = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
	var cal_days_in_month = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
	var pattern = /^([\d]+\/[\d]+\/[\d]{4})?$/;
	
	if(value!='') if(!pattern.test(obj.val())) { value=''; obj.val(''); }
	
	if(value!='') {
		var dateVal = value.split('/');
		dateVal[1] -= 1;

		var firstDay = new Date(dateVal[2], dateVal[1], 1);
		var today = dateVal[0];
	} else {
		var dNow = new Date();

		var today = dNow.getDate();
		var dMonth = dNow.getMonth();
		var dYear = dNow.getFullYear();
		
		var firstDay = new Date(dYear, dMonth, 1);
	}
	
	var startingDay = firstDay.getDay();
	var startingMonth = firstDay.getMonth()+1;
	var startingYear = firstDay.getFullYear();
	
	var calendarTitle = cal_months_labels[startingMonth-1]+' '+startingYear;
	
	var tDate = today;
	var tMonth = startingMonth;
	var tYear = startingYear;
	
	if(tMonth<=0) { tMonth = 12; tYear--; }
	
	var prevDate = today+'/'+(tMonth-1)+'/'+tYear;
	
	var nextDate = today+'/'+(tMonth+1)+'/'+tYear;
	
	var monthLength = cal_days_in_month[startingMonth-1];
	
	if (startingMonth == 2) { // February only!
		if((startingYear % 4 == 0 && startingYear % 100 != 0) || startingYear % 400 == 0){
			 monthLength = 29;
		}
	}
	
	html = '';
	var day=1;
	var istoday; 
	for (var i = 0; i < 9; i++) {
		html += '<tr class="calendar-date">';
		for (var j = 0; j <= 6; j++) { 
			html += '<td>';
			if (day <= monthLength && (i > 0 || j >= startingDay)) {
				var dateVal = day+'/'+startingMonth+'/'+startingYear;
				if(day==today) {
				html += '<p dateval="'+dateVal+'" class="today">'+day+'</p>';
				} else {
				html += '<p dateval="'+dateVal+'">'+day+'</p>';
				}
				day++;
			}
			html += '</td>';
		}
		if (day > monthLength) {
			break;
		}
		html += '</tr>';
	}
	
	$(obj).parent().children('.calendar-box').children().children().children().children(':eq(0)').children('span').attr('dateval',prevDate);
	$(obj).parent().children('.calendar-box').children().children().children().children(':eq(2)').children('span').attr('dateval',nextDate);
	
	$(obj).parent().children().children(':eq(1)').children().children("tr[class^='calendar-date']").remove();
	$(obj).parent().children().children(':eq(1)').append(html);
	$(obj).parent().children('.calendar-box').children().children().children().children(':eq(1)').text(calendarTitle);
	
	$(obj).parent().children().children(':eq(1)').children().children("tr[class^='calendar-date']").children().children('p').unbind('click').click(function() { 
		$(this).parents('.datepicker-box').children(':first').val($(this).attr('dateval'))
	})
	
	$(obj).unbind('keyup').keyup(function() { 
		$(this).val($(this).val().replace(/[^0-9\/]/g,''));
		if(pattern.test(obj.val())) {
			$.fn.setCalender($(this).val(),$(this));
		}
	}).unbind('blur').blur(function() { 
		if(pattern.test($(this).val())) {
			var dateVal = $(this).val().split('/');
			if(parseInt(dateVal[0])>31 || parseInt(dateVal[1])>12 || parseInt(dateVal[2])>2150) $(this).val('');
			if(parseInt(dateVal[0])<=0 || parseInt(dateVal[1])<=0 || parseInt(dateVal[2])<=1950) $(this).val('');
		} else {
			$(this).val('');
		}
	})
	
	$(obj).parent().children('.calendar-box').children().children().children().children().children('span').unbind('click').click(function() { 
		$.fn.setCalender($(this).attr('dateval'),$(this).parents('.datepicker-box').children('.datepicker-text'));
	})
	}
}(jQuery);

new function($) {
	$.fn.closeButton = function() {
	$("div[class^='popup-close'],div[class^='popup-cancel']").unbind('click').click(function() { 
		$(this).parents(':eq(1)').fadeOut(250,function() { $(this).parents(':eq(2)').remove(); });
	})
	}
}(jQuery);

new function($) {
	$.fn.setCrop = function() {
	$.Jcrop('#crop-image',{ cornerHandles: false, sideHandles: false, allowResize: false, bgOpacity: 0.2, onChange: $.fn.showCoords, setSelect: [ 0, 0, 50, 50 ], allowSelect: false, maxSize: [ 50, 50 ], minSize: [ 50, 50 ] });
	}
}(jQuery);

new function($) {
	$.fn.setKeyInput = function() {
	$(".input-text:first").focus();
	$("input:text,input:password").unbind('keypress').keypress(function(e) { 
		var n = $("input:text,input:password").length;
		if(e.which==13) {
			e.preventDefault(); //Skip default behavior of the enter key	
			var nextIndex = $('input:text,input:password').index(this) + 1;
			if(nextIndex < n) $('input:text,input:password')[nextIndex].focus();
		}
	})	
	}
}(jQuery);


new function($) {
	$.fn.eventPopup = function() {
	var pop_html = '<div class="popup-container"> \
	<div class="popup-overlay"></div> \
	<div class="popup-box"> \
	<div class="popup-main"> \
	<div class="popup-shadow"> \
	<div class="popup-header"> \
	<span>Loading</span> \
	<div class="popup-close-disabled">X</div> \
	</div> \
	<div class="popup-loading"> \
	<table><tr><td style="padding: 15px 0;" align="center">Mohon tunggu<br />mengambil halaman</td></tr></table> \
	</div> \
	</div> \
	</div> \
	</div> \
	</div>';
	
  // getPageScroll() by quirksmode.com
  function getPageScroll() {
    var xScroll, yScroll;
    if (self.pageYOffset) {
      yScroll = self.pageYOffset;
      xScroll = self.pageXOffset;
    } else if (document.documentElement && document.documentElement.scrollTop) {	 // Explorer 6 Strict
      yScroll = document.documentElement.scrollTop;
      xScroll = document.documentElement.scrollLeft;
    } else if (document.body) {// all other Explorers
      yScroll = document.body.scrollTop;
      xScroll = document.body.scrollLeft;	
    }
    return new Array(xScroll,yScroll) 
  }

  // adapter from getPageSize() by quirksmode.com
  function getPageHeight() {
    var windowHeight;
    if (self.innerHeight) {	// all except Explorer
      windowHeight = self.innerHeight;
    } else if (document.documentElement && document.documentElement.clientHeight) { // Explorer 6 Strict Mode
      windowHeight = document.documentElement.clientHeight;
    } else if (document.body) { // other Explorers
      windowHeight = document.body.clientHeight;
    }	
    return windowHeight
  }
	
	
	$("div[type^='popup']").unbind('click').click(function() { 
		sID = $(this);
		var cntSelect='';
		$('body').append(pop_html);
		var pageScroll = getPageScroll();
		var mode = $(this).attr('mode');
		
		
		
		$('.popup-main:last').css({
      		top:	pageScroll[1] + (getPageHeight() / 10.5),
    	})
		var link = $(this).attr('link');
		var parseLink = link.split('?');
		
		
		if(parseLink.length>1)
			var gid = '&gid='+parseLink[1];
		else
			var gid = '';
		
		
		
		if(mode=='4') {
			var cClass = $(this).parents(':eq(1)').children(':last').prev().attr('class')
			var idAttr = $(this).parents(':eq(1)').children(':last').prev();
			if(cClass=='ctable-box') {
				idAttr.children().children().children().each(function() { 
					if($(this).children().children("input[name^='chkbox']").attr('checked')==true) {
						cntSelect += $(this).children().children("input[name^='chkbox']").val()+'^_^';
					}
				})
			} else if(cClass=='ctable') {
				idAttr.children().children().each(function() { 
					if(typeof $(this).children().children("input[name^='chkbox']").val()!='undefined') {
						if($(this).children().children("input[name^='chkbox']").attr('checked')==true)
							cntSelect += $(this).children().children("input[name^='chkbox']").val()+'^_^';
					}
				});
			}
			cntSelect = cntSelect.substr(0,cntSelect.length-3);
			gid = '&gid='+encodeURI(cntSelect);
		}
		
		$(".popup-main:last").load(parseLink[0]+'.php?mod='+$(this).attr('mode')+gid, "",
			function(responseText, textStatus, XMLHttpRequest) {
			if(textStatus == 'success') {	
				var maxWidth = $('.popup-main:last').children('.popup-shadow:last').width();
				$(this).width(maxWidth);
				$.fn.eventTabClicked(); $.fn.closeButton(); $.fn.eventPopup();  $.fn.customDatepicker(); $.fn.eventSave(); $.fn.setChkBox(); $.fn.setMore(); $.fn.eventSearch(); $.fn.eventMainPage();
				$(this).children().removeAttr('style');
				$(this).Drags({	handler: '.popup-header' });
				$.fn.setKeyInput();
				
			} else if(textStatus == 'error') {
				$('.popup-close-disabled:last').attr('class','popup-close');
				$.fn.closeButton();
				$('.popup-header:last span').text('Error loading page.');
				$('.popup-loading:last table tr td').text('Gagal mengambil halaman.');
			}
    	});
	})
	}
}(jQuery);

new function($) {
	$.fn.eventSave = function() {
	function trim(str, chars) {
		return ltrim(rtrim(str, chars), chars);
	}
	function ltrim(str, chars) {
		chars = chars || "\\s";
		return str.replace(new RegExp("^[" + chars + "]+", "g"), "");
	}
	 
	function rtrim(str, chars) {
		chars = chars || "\\s";
		return str.replace(new RegExp("[" + chars + "]+$", "g"), "");
	}
	$("div[class^='popup-button']").unbind('click').click(function() { 
		var self = $(this);
		var mode = $(this).attr('mode');
		if(mode==6) {
			self.parent().children('.loadnimate').remove();
			self.parent().prepend('<div class="loadnimate">Mohon tunggu, menyimpan..</div>');
			self.attr('class','disabled-popup-button');	
			self.unbind('click');
			
			var action = $(this).parents(':eq(1)').children('.popup-body').children('form').attr('action');
			$(this).parents(':eq(1)').children('.popup-body').children('form').attr('action',action+'?mod='+mode).ajaxForm(function(data) { 
				data = trim(data);
				$('h4').remove();
				if(data!='') {
					self.parent().children('.loadnimate').remove();
					self.attr('class','popup-button');	
					$.fn.eventSave();
					var error = data.split('|*|');
					for(var i=0;i<error.length;i++) {
						var tmp = error[i].split(':');
						$("input[name='"+tmp[0]+"'],textarea[name='"+tmp[0]+"'],select[name='"+tmp[0]+"']").parent().append('<h4>'+tmp[1]+'</h4>');	
						if(i==0) $("input[name='"+tmp[0]+"'],textarea[name='"+tmp[0]+"'],select[name='"+tmp[0]+"']").focus();
					}
				} else {
					var link = self.attr('link');
					var parseLink = link.split('?');

					if(parseLink.length>1) {
						var elem = sID.parents('.popup-main');
						var page = elem.children("input[name^='p']").val();
						var acc = elem.children("input[name^='acc']").val();
						if(typeof page != 'undefined') { 
							page='&p='+page;	
						} else page = '';
						
						if(typeof acc != 'undefined') { 
							acc=page+'&acc='+acc;	
						} else acc = page+'';
						
						var gid = '?gid='+parseLink[1]+acc;
					} else {
						var elem = sID.parents('.sub-content');
						var page = elem.children("input[name^='p']").val();
						var acc = elem.children("input[name^='acc']").val();
						if(typeof page != 'undefined') { 
							page='?p='+page;	
						} else page = '';
						if(typeof acc != 'undefined') { 
							acc=page+'&acc='+acc;	
						} else acc = page+'';
						var gid = acc;
					}
					
					$(elem).load(parseLink[0]+'.php'+gid, "",
						function(responseText, textStatus, XMLHttpRequest) {
						if(textStatus == 'success') {	
							$(this).children().removeAttr('style');
							$(this).Drags({	handler: '.popup-header' });
							$.fn.eventPopup(); $.fn.eventTabClicked(); $.fn.closeButton(); $.fn.setChkBox(); $.fn.setMore(); $.fn.eventSearch();
							self.parents(':eq(1)').fadeOut(250,function() { $(this).parents(':eq(2)').remove(); });
						}
					});
				}
					
				self.parents(':eq(1)').children('.popup-body').children('form').attr('action',action)
				
			}).submit();
			
		} else if(mode==3 || mode==5) {
			var link = self.attr('link');
			var isRefresh = self.attr('refresh');
			var parseLink = link.split('?');
			
			if(parseLink.length>1) {
				var elem = sID.parents('.popup-main');
				var gid = '?mod='+mode+'&gid='+parseLink[1];
			} else {
				var elem = sID.parents('.sub-content');
				var gid = '';
			}
			
			$.get(parseLink[0]+'.php'+gid,function() { 
				if(typeof isRefresh != 'undefined') {
					var refreshLink = isRefresh.split('?');
					gid = '?gid='+refreshLink[1];
					$(sID.parents('.popup-main')).load(refreshLink[0]+'.php'+gid, "",
						function(responseText, textStatus, XMLHttpRequest) {
						if(textStatus == 'success') {	
							$(this).children().removeAttr('style');
							$(this).Drags({	handler: '.popup-header' });
							$.fn.eventPopup(); $.fn.eventTabClicked(); $.fn.closeButton(); $.fn.setChkBox(); $.fn.setMore(); $.fn.eventSearch();
						}
					});	
				} else {
					if(mode==3)	sID.parents('tr').remove();
					if(mode==5) {
						var cClass = sID.parents(':eq(1)').children(':last').prev().attr('class');
						var idAttr = sID.parents(':eq(1)').children(':last').prev();
						if(cClass=='ctable-box') {
							idAttr.children().children().children().each(function() { 
								if($(this).children().children("input[name^='chkbox']").attr('checked')==true) {
									$(this).children().children("input[name^='chkbox']").parents(':eq(1)').remove();
								}
							})
						} else if(cClass=='ctable') {
							idAttr.children().children().each(function() { 
								if($(this).children().children("input[name^='chkbox']").val()!='undefined') {
									if($(this).children().children("input[name^='chkbox']").attr('checked')==true)
										$(this).children().children("input[name^='chkbox']").parents(':eq(1)').remove();
								}
							});
						}
					}
				}
				self.parents(':eq(1)').fadeOut(250,function() { $(this).parents(':eq(2)').remove(); });
			})
			
		}
	})
	}
}(jQuery);

new function($) {
	$.fn.eventSearch = function() {
	$("div[class^='search-button']").unbind('click').click(function() { 
	
		var input = $(this).parent().children('.search-input').val();
		
		if(input=='Pencarian...') input = '';

		var link = $(this).attr('link');
		var parseLink = link.split('?');
			
		var tsearch='';
		if(parseLink.length>1) {
			if(input!='') {
				tsearch = '?gid='+parseLink[1]+'&search='+input;
			} else {
				tsearch = '?gid='+parseLink[1];
			}
		} else {
			if(input!='') tsearch = '?search='+input;
		}
		
		$(this).parent().parents('.sub-content, .popup-main').load(parseLink[0]+'.php'+tsearch, "",
			function(responseText, textStatus, XMLHttpRequest) {
			if(textStatus == 'success') {	
					$.fn.eventPopup(); $.fn.eventTabClicked(); $.fn.closeButton(); $.fn.setChkBox(); $.fn.setMore(); $.fn.eventSearch();
					$(this).Drags({	handler: '.popup-header' });
			}
		});
	})
	
	$("input[class^='search-input']").unbind('keyup').keyup(function(e) {  
		if(e.which==13) {
			var self = $(this);
			var input = $(this).val();
			if(input=='Pencarian...') input = '';
			
			input = encodeURI(input);
			
			var link = $(this).parent().children('.search-button').attr('link');
			var parseLink = link.split('?');
			
			var tsearch='';
			if(parseLink.length>1) {
				if(input!='') {
					tsearch = '?gid='+parseLink[1]+'&search='+input;
				} else {
					tsearch = '?gid='+parseLink[1];
				}
			} else {
				if(input!='') tsearch = '?search='+input;
			}
			
			$(this).parent().parents('.sub-content, .popup-main').load(parseLink[0]+'.php'+tsearch, "",
				function(responseText, textStatus, XMLHttpRequest) {
				if(textStatus == 'success') {	
						$.fn.eventPopup(); $.fn.eventTabClicked(); $.fn.closeButton(); $.fn.setChkBox(); $.fn.setMore(); $.fn.eventSearch();
						$(this).Drags({	handler: '.popup-header' });
						if(parseLink.length>1) {
							$(this).children().children().children(':eq(2)').children().find('.search-input').focus();
							$(this).children().children().children(':eq(2)').children().find('.search-input').setCursorPosition(input.length);
							
						} else {
							$(this).children(':eq(1)').children(':first').find('.search-input').focus();
							$(this).children(':eq(1)').children(':first').find('.search-input').setCursorPosition(input.length);
						}
				}
			});
		}
	})
	}
}(jQuery);

new function($) {
	$.fn.setMore = function() {
	$("div[class^='more']").unbind('click').click(function(e) { 
		if($(this).attr('class')!='more-selected') {
			$("div[class^='more-selected']").attr('class','more');
			$(this).attr('class','more-selected');
			$("div[class^='pop-more']").hide(function() { $(this).removeAttr('style') });
			$(this).parent().children(':eq(1)').slideToggle(250);
			$.fn.setMore()
		}
		e.stopPropagation();
	})
	
	$(document).unbind('click').click(function() { 
		if($(this).attr('class')!='more-selected') {
			$("div[class^='more-selected']").attr('class','more');
			$("div[class^='pop-more']").hide(function() { $(this).removeAttr('style') });
		}
	})
	
	$("input[class^='input-text currency']").unbind('keyup').keyup(function() { 
		 $(this).val($(this).val().replace(/[^0-9,]/g,'')); $(this).val($.fn.addCommas($(this).val(),'')); $.fn.setCount($(this));
	}).unbind('blur').blur(function() { 
		$(this).val($(this).val().replace(/[^0-9,]/g,'')); $(this).val($.fn.addCommas($(this).val(),'')); $.fn.setCount($(this));
	})
	
	$("input[class^='input-text year']").unbind('keyup').keyup(function() { 
		 $(this).val($(this).val().replace(/[^0-9/-]/g,'')); 
	}).unbind('blur').blur(function() { 
		$(this).val($(this).val().replace(/[^0-9/-]/g,'')); 
	})
	
	$("input[class^='input-text percent']").unbind('keyup').keyup(function() { 
		 $(this).val($(this).val().replace(/[^0-9.]/g,'')); 
		 $(this).val($.fn.checkPercent($(this).val()));
	}).unbind('blur').blur(function() { 
		$(this).val($(this).val().replace(/[^0-9.]/g,'')); 
		$(this).val($.fn.checkPercent($(this).val()));
	})
	
	$("div[class^='print-button']").unbind('click').click(function() { 
		var printState = $(this).attr('print');
		var self = $(this);
		$(this).parents('form').children("input[type^='submit']").remove();
		$(this).parents('form').ajaxForm(function(data) { 
			$('h4').remove();
			if(data.indexOf('|*|')!=-1) {
				var error = data.split('|*|');
				for(var i=0;i<error.length;i++) {
					var tmp = error[i].split(':');
					$("input[name='"+tmp[0]+"'],textarea[name='"+tmp[0]+"'],select[name='"+tmp[0]+"']").parent().append('<h4>'+tmp[1]+'</h4>');	
					if(i==0) $("input[name='"+tmp[0]+"'],textarea[name='"+tmp[0]+"'],select[name='"+tmp[0]+"']").focus();
				}
			} else {
				if(printState!='3') { 
				$('.box-paper').html(data).slideDown(250,function() {  
					if(printState=='1') { $.fn.setPrint(1); }
					if(printState=='2') { $.fn.setPrint(2); }
				});
				} else {
					self.parents('form').append('<input type="submit" value="" style="width:0;height: 0; position: absolute; top: -2000px;">')
					self.parents('form').children("input[type='submit']").click();	
				}
			}
		}).submit()
	})
	}
}(jQuery);

new function($) {
	$.fn.printEvent = function() {
	$("div[print^='preview'],div[print^='back']").unbind('click').click(function() { 
		var link = $(this).attr('link');
		var parseLink = link.split('?');
		if(parseLink.length>1)
			var gid = '?'+parseLink[1];
		else
			var gid = '';
			
		$(this).parents('.sub-content, .popup-main').load(parseLink[0]+'.php'+gid, "",
				function(responseText, textStatus, XMLHttpRequest) {
				if(textStatus == 'success') {	
					$.fn.eventPopup(); $.fn.eventTabClicked(); $.fn.closeButton(); $.fn.setChkBox(); $.fn.setMore(); $.fn.eventSearch(); $.fn.printEvent();
				}
			});	
	})	
	}
}(jQuery);

new function($) {
	$.fn.setChkBox = function() {
	$("input[name^='mainchk']").unbind('click').click(function() { 
		var checked = $(this).attr('checked');
		$(this).parents(':eq(2)').children().each(function() { 
			$(this).children(':eq(0)').children('input').attr('checked',checked)
			if(checked && $(this).children(':eq(0)').children('input').attr('name')=='chkbox[]') 
				$(this).attr('class','tr-selected');
			else
				if($(this).attr('class')=='tr-selected')
				$(this).removeAttr('class');
		})
	})	
	$("input[name^='chkbox']").unbind('click').click(function() { 
		if($(this).attr('checked')) 
			$(this).parents('tr').attr('class','tr-selected');
		else
			$(this).parents('tr').removeAttr('class');
	})
	$("input[class='search-input']").unbind('focus').focus(function() { 
		if($(this).val()=='Pencarian...') $(this).val('');
	}).blur(function() { 
		if($(this).val()=='') $(this).val('Pencarian...');
	})
	
	$("input[name^='is_persen']").unbind('click').click(function() {
		var realNum = $(this).parents('td').children(':first').val();
		if($(this).attr('checked')==true) {
			$(this).attr('cry',realNum);
			var val = $(this).attr('pct');
			val = val.toString().replace(/\$|\,/g,'');
			val = parseFloat(val);
			if(val>100) val = 100; 
			if(val==0) val = parseInt($(this).attr('pct'));
			if(isNaN(val)) val = 0; if(val==0) val = '';
			$(this).parents('td').children(':first').attr('class','input-text percent').val(val).focus();
		} else {
			$(this).attr('pct',realNum);
			$(this).parents('td').children(':first').attr('class','input-text currency').val($(this).attr('cry')).focus();
			
		}
		$.fn.setMore();
	})
	}
}(jQuery);

new function($) {
	$.fn.setCount = function(obj) {
	var total = 0;
	$("input[group='"+obj.attr('group')+"']").each(function() { 
		var tmp = $(this).val();
		tmp = tmp.toString().replace(/\$|\,/g,'');
		if(tmp!='') {
			total += parseInt(tmp);
		}
	})
	if(total=='') total = 0;
	$("b[group='"+obj.attr('group')+"']").text($.fn.addCommas(total,'0'));
	
	if(typeof obj.attr('own')!='undefined')
		$("input[sum='"+obj.attr('own')+"']").val(obj.val().toString().replace(/\$|\,/g,''));
	
	$("input[sum='"+obj.attr('group')+"']").val(total);
	
	$("input[set='total']").each(function() { 
		var mGroup = $(this).attr('target');
		var mRealGroup = $(this).attr('target');
		var oprator = '';
		
		for(var i=0;i<mGroup.length;i++) {
			if(mGroup[i]=='-' || mGroup[i]=='+') oprator += mGroup[i]+',';
		}
		oprator = oprator.substr(0,oprator.length-1);

		var mOprator = oprator.split(',');
		mGroup = mGroup.toString().replace(/\$|\-/g,',');
		mGroup = mGroup.toString().replace(/\$|\+/g,',');
		
		var mCount = mGroup.split(',');
		
		var grandTotal = 0;
		if(mCount.length>0) {
			var oNum = 0;
			for(var i=0;i<mCount.length;i++) {
				if(i==0) grandTotal = parseInt($("input[sum='"+mCount[i]+"']").val());
				else {
					if($("input[sum='"+mCount[i]+"']").val()!='') {
						if(mOprator[oNum]=='-') {
							grandTotal -= parseInt($("input[sum='"+mCount[i]+"']").val());
						}
						if(mOprator[oNum]=='+') {
							grandTotal += parseInt($("input[sum='"+mCount[i]+"']").val());
						}
					}
					oNum++;
				}
			}
		}	
		$(this).val(grandTotal);
		if(grandTotal<0)
		$("b[target='"+mRealGroup+"']").text('('+$.fn.addCommas(grandTotal,'0')+')');
		else 
		$("b[target='"+mRealGroup+"']").text($.fn.addCommas(grandTotal,'0'));
		
	})
	}
}(jQuery);

new function($) {
	$.fn.eventLogout = function() {
	
		var pop_html = '<div class="popup-container"> \
		<div class="popup-overlay"></div> \
		<div class="popup-box"> \
		<div class="popup-main"> \
		<div class="popup-shadow"> \
		<div class="popup-header"> \
		<span>Konfirmasi Log Out</span> \
		<div class="popup-close">X</div> \
		</div> \
		<div class="popup-body"> \
		<table><tr><td style="padding: 15px 0;" align="center">Apakah anda yakin untuk <b>Log Out</b>?</td></tr></table> \
		</div> \
		<div class="popup-footer"> \
        <div class="popup-cancel">Batal</div> \
        <a style="text-decoration: none;" class="popup-button" href="logout.php">Ya, Log Out sekarang</a> \
      	</div> \
		</div> \
		</div> \
		</div> \
		</div>';
	
		// getPageScroll() by quirksmode.com
		  function getPageScroll() {
		    var xScroll, yScroll;
		    if (self.pageYOffset) {
		      yScroll = self.pageYOffset;
		      xScroll = self.pageXOffset;
		    } else if (document.documentElement && document.documentElement.scrollTop) {	 // Explorer 6 Strict
		      yScroll = document.documentElement.scrollTop;
		      xScroll = document.documentElement.scrollLeft;
		    } else if (document.body) {// all other Explorers
		      yScroll = document.body.scrollTop;
		      xScroll = document.body.scrollLeft;	
		    }
		    return new Array(xScroll,yScroll) 
		  }
		
		  // adapter from getPageSize() by quirksmode.com
		  function getPageHeight() {
		    var windowHeight;
		    if (self.innerHeight) {	// all except Explorer
		      windowHeight = self.innerHeight;
		    } else if (document.documentElement && document.documentElement.clientHeight) { // Explorer 6 Strict Mode
		      windowHeight = document.documentElement.clientHeight;
		    } else if (document.body) { // other Explorers
		      windowHeight = document.body.clientHeight;
		    }	
		    return windowHeight
		  }
	
	
		$('.account-logout').unbind('click').click(function() { 
		
			$('body').append(pop_html);
			var pageScroll = getPageScroll();

			
			$('.popup-main:last').css({
	      		top:	pageScroll[1] + (getPageHeight() / 10.5),
	    	})
		
			$('.popup-main:last').Drags({	handler: '.popup-header' });
			$.fn.closeButton();
			
		})	
	}
}(jQuery);

new function($) {
	$.fn.eventMainPage = function() {
		$("div[class^='main-button']").unbind('click').click(function() { 
			if(typeof $(this).attr('link')!='undefined') 
				window.location = $(this).attr('link');
			else
				window.location = '';
		})
	}
}(jQuery);

jQuery(document).ready(function() {
	$.fn.eventTabClicked();
	$.fn.eventNavClicked();
	$.fn.eventPopup();
	$.fn.setChkBox();
	$.fn.eventSearch();
	$.fn.printEvent();
	$.fn.eventLogout();
	$.fn.eventMainPage();
})