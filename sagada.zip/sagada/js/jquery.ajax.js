//Fungsi ajax untuk memanggil link atau url, jika textStatus tidak sama dengan 'error' maka jalankan component.
//file php ('')
function ajaxrequest(url,ObjID) {
  $('#'+ObjID).html('<p><img src="images/loading.gif" /></p>');
  $('#'+ObjID).load(url, "",
        function(responseText, textStatus, XMLHttpRequest) {
			//jika link tidak dapat tercapai maka yg didapat textStatus == 'error'
            if(textStatus == 'error') {
                $('#'+ObjID).html('<p>There was an error to request the link!.</p>');
            }else{
			//sebaliknya jalankan komponen
				StartComponent();
			}
        }
    );
}
//Fungsi ajax untuk memanggil link atau url
//file php ('')
function cusajaxrequest(url,ObjID) {
  $('#'+ObjID).html('<p><img src="images/loading.gif" /></p>');
  $('#'+ObjID).load(url, "",
        function(responseText, textStatus, XMLHttpRequest) {
			//jika link tidak dapat tercapai maka yg didapat textStatus == 'error'
            if(textStatus == 'error') {
                $('#'+ObjID).html('<p>There was an error to request the link!.</p>');
            }
        }
    );
}
//Fungsi ajax untuk memanggil link atau url, jika textStatus tidak sama dengan 'error' maka jalankan component pada form pembayaran.
//file php ('')
function cusajaxrequest2(url,ObjID) {
  $('#'+ObjID).html('<p><img src="images/loading.gif" /><br />Please wait...<br />loading content...</p>');
  $('#'+ObjID).load(url, "",
        function(responseText, textStatus, XMLHttpRequest) {
			//jika link dapat tercapai atau 'success', jalankan komponen
            if(textStatus == 'success') {
                $(document).ready(function(arg) {
					$('#card-option').msDropDown(); 
					$('#month-option').msDropDown(); 
					$('#year-option').msDropDown(); 
				});
            }
        }
    );
}
//Fungsi ajax untuk memanggil link atau url, tanpa menampilkan gambar loading.gif untuk update order (file: 'update_order.php') dan update pembelian (file: 'update_pembelian.php')
//file php ('')
function cusajaxrequestnoimage(url,ObjID) {
  $('#'+ObjID).load(url, "",
        function(responseText, textStatus, XMLHttpRequest) {
            if(textStatus == 'error') {
                $('#'+ObjID).html('<p>There was an error to request the link!.</p>');
            }
        }
    );
}
//Fungsi ajax untuk memanggil link atau url, cek apakah username yg diinputkan sudah ada dalam database atau belum, jika ada '+OK' hasil = benar, sebaliknya hasil = salah (file: 'tambah_member.php')
//file php ('')
function CekUsername(url,ObjID) {
  $('#'+ObjID).load(url, "",
        function(responseText, textStatus, XMLHttpRequest) {
            if(textStatus == 'error') {
				return false;
            }else{
				if(responseText == '+OK'){
					return true;
				}else{
					return false;
				}
			}
        }
    );
}
//fungsi untuk validasi pembayaran kartu kredit
//file php ('')
function validate(url,ObjID,res,text,word) {
  //ambil dari pihakk bank apakah valid ato tidak
  $('#'+ObjID).load(url, "",
        function(responseText, textStatus, XMLHttpRequest) {
            if(textStatus == 'error') {
				return false;
            }else{
				//jika respon ''OK' maaka valid
				if(responseText == '+OK'){
					$('#'+ObjID).html('<div id="body-validate"><p><img src="images/loading.gif" /><br />Please wait...<br />processing...</p></div>');
					//tampilkan pesan bahwa pembayaran telah berhasil, file('val_msg.php')
					$('#'+ObjID).load(res+'&q=1');
					notification(text,word);
					cusajaxrequestnoimage('update_order.php','order_list');
					cusajaxrequestnoimage('update_pembelian.php','pembelian_list');
				}else if(responseText == '-ERR1'){
					$('#'+ObjID).html('<div id="body-validate"><p><img src="images/loading.gif" /><br />Please wait...<br />processing...</p></div>');
					$('#'+ObjID).load(res+'&q=2');
				}else if(responseText == '-ERR2'){
					$('#'+ObjID).html('<div id="body-validate"><p><img src="images/loading.gif" /><br />Please wait...<br />processing...</p></div>');
					$('#'+ObjID).load(res+'&q=3');
				}
			}
        }
    );
}
function StartComponent() 
{ 
$(document).ready(function() { $("#accordion").msAccordion({vertical:true});}); 
$(document).ready(function(arg) { $('#category').msDropDown(); }); 
$(document).ready(function(arg) { $('#gender').msDropDown(); }); 
}
function loadHome() 
{ 
ajaxrequest('admin/library/website/home/home.php','content-center');
}
function loadBeranda() 
{ 
ajaxrequest('admin/library/website/home/beranda.php','content-center');
}

function loadLogin()
{
ajaxrequest('admin/library/website/home/login.php','righncontent');
}
function loadMain()
{
ajaxrequest('admin/library/website/home/main.php','righncontent');
}
//fungsi untuk proses validasi pada Form Registrasi... file('registrasi.inc')
function formvalidator() {
	var name = document.getElementById('name');
	var nim = document.getElementById('nim');
	var email = document.getElementById('email');
	var addr = document.getElementById('address');
	var user = document.getElementById('username');
	var pass = document.getElementById('password');
	var repass = document.getElementById('repassword');

	
	//cek nama apakah min karakter tidak kurang dari 4 dan tidak lebih besar dari 50 dgn karakter yg ditentukan 0-9, a-z, A-Z, dan spasi
	if(isAlphanumeric(name,'alert1',4,50,/^[0-9a-zA-Z ]+$/)){
		if(isNumeric(nim,'alert2',5,13)){
			if(emailValidator(email,'alert3')){
				if(isAlphanumeric(addr,'alert4',4,75,/^[0-9a-zA-Z ]+$/)){
						if(isAlphanumeric(user,'alert5',4,15,/^[0-9a-zA-Z]+$/)){
							if(isAlphanumeric(pass,'alert6',4,15,/^[0-9a-zA-Z_]+$/)){
								if(isCustomAlphanumeric(repass,pass,'alert7',4,15,/^[0-9a-zA-Z_]+$/)){
										return true;
								}
							}
						
					}
				}
			}
		}
	}
	return false;
}
function formmembervalidator() {
	var name = document.getElementById('name');
	var nim = document.getElementById('nim');
	var email = document.getElementById('email');
	var addr = document.getElementById('address');
	
	//cek nama apakah min karakter tidak kurang dari 4 dan tidak lebih besar dari 50 dgn karakter yg ditentukan 0-9, a-z, A-Z, dan spasi
	if(isAlphanumeric(name,'alert1',4,50,/^[0-9a-zA-Z ]+$/)){
		if(isNumeric(nim,'alert2',5,13)){
			if(emailValidator(email,'alert3')){
				if(isAlphanumeric(addr,'alert4',4,75,/^[0-9a-zA-Z ]+$/)){
					return true;
				}
			}
		}
	}
	return false;
}



function formbarujoss() {
	var name = document.getElementById('name');
	var nim = document.getElementById('nim');
	var email = document.getElementById('email');
	var addr = document.getElementById('address');
	
	//cek nama apakah min karakter tidak kurang dari 4 dan tidak lebih besar dari 50 dgn karakter yg ditentukan 0-9, a-z, A-Z, dan spasi
	if(isAlphanumeric(name,'alert1',4,50,/^[0-9a-zA-Z ]+$/)){
		if(isNumeric(nim,'alert2',5,13)){
			if(emailValidator(email,'alert3')){
				if(isAlphanumeric(addr,'alert4',4,75,/^[0-9a-zA-Z ]+$/)){
					return true;
				}
			}
		}
	}
	return false;
}








function formpassvalidator() {
	var oldpass = document.getElementById('oldpass');
	var newpass = document.getElementById('newpass');
	var renewpass = document.getElementById('renewpass');
	
	if(isAlphanumeric(oldpass,'alert7',4,15,/^[0-9a-zA-Z_]+$/)){
		if(isAlphanumeric(newpass,'alert8',4,15,/^[0-9a-zA-Z_]+$/)){
			if(isACustomAlphanumeric(renewpass,newpass,'alert9',4,15,/^[0-9a-zA-Z_]+$/)){
				return true;
			}
		}
	}
	return false;
}
//fungsi untuk proses validasi pada Form alamat pengiriman... file('pengiriman.inc')
function gatewayvalidator(url) {
	var number = document.getElementById('cardnumber');
	var idsec = document.getElementById('idcard');
	var name = document.getElementById('name');
	var addr = document.getElementById('address');
	var city = document.getElementById('city');
	var postal = document.getElementById('postal');
	var province = document.getElementById('province');
	
	if(isNumeric(number,'alerta',12,12)){
		if(isNumeric(idsec,'alertb',3,12)){
			if(document.getElementById('alternatif').checked) {
				if(isAlphanumeric(name,'alert1',4,50,/^[0-9a-zA-Z ]+$/)){
					if(isAlphanumeric(addr,'alert2',4,75,/^[0-9a-zA-Z ]+$/)){
						if(isAlphanumeric(city,'alert3',4,25,/^[a-zA-Z ]+$/)){
							if(isNumeric(postal,'alert4',5,5)){
								if(isAlphanumeric(province,'alert5',4,25,/^[a-zA-Z ]+$/)){
									jQuery.facebox({ ajax: url });
								}
							}
						}
					}
				}
			} else {
				jQuery.facebox({ ajax: url });
			}
		}
	}	
}

function notEmpty(elem){
	if(elem.value.length == 0){
		$('#'+elem).html('<img src="images/invalid.png" />');
		return false;
	}
	$('#'+elem).html('<img src="images/valid.png" />');
	return true;
}

function isNumeric(elem,ObjID, min, max){
	var numericExpression = /^[0-9]+$/;
	var uInput = elem.value;
	if(uInput.length >= min && uInput.length <= max){
		$('#'+ObjID).html('<img src="images/valid.png" />');
		if(elem.value.match(numericExpression)){
			$('#'+ObjID).html('<img src="images/valid.png" />');
			return true;
		}else{
			$('#'+ObjID).html('<img src="images/invalid.png" />');
			elem.focus();
			return false;
		}
	}else{
		$('#'+ObjID).html('<img src="images/invalid.png" />');
		elem.focus();
		return false;
	}
}

function isAlphanumeric(elem,ObjID, min, max,pattern){
	var uInput = elem.value;
	if(uInput.length >= min && uInput.length <= max){
		$('#'+ObjID).html('<img src="/images/valid.png" />');
		if(elem.value.match(pattern)){
			$('#'+ObjID).html('<img src="images/valid.png" />');
			return true;
		}else{
			$('#'+ObjID).html('<img src="images/invalid.png" />');
			elem.focus();
			return false;
		}
	}else{
		$('#'+ObjID).html('<img src="images/invalid.png" />');
		elem.focus();
		return false;
	}
}
function isMemberAlphanumeric(elem,ObjID, min, max,pattern){
	var uInput = elem.value;
	if(uInput.length >= min && uInput.length <= max){
		$('#'+ObjID).html('<img src="/images/valid.png" />');
		if(elem.value.match(pattern)){
			$('#'+ObjID).html('<img src="images/valid.png" />');
			$("#change").submit();
			return true;
		}else{
			$('#'+ObjID).html('<img src="images/invalid.png" />');
			elem.focus();
			return false;
		}
	}else{
		$('#'+ObjID).html('<img src="images/invalid.png" />');
		elem.focus();
		return false;
	}
}
function isUserAlphanumeric(elem,url,ObjID, min, max,pattern){
	var uInput = elem.value;
	if(uInput.length >= min && uInput.length <= max){
		if(elem.value.match(pattern)){
			$('#'+ObjID).load(url+uInput, "",
        	function(responseText, textStatus, XMLHttpRequest) {
            if(textStatus == 'error') {
				return false;
            }else{
				if(responseText == '+OK'){
					$('#'+ObjID).html('<img src="images/valid.png" />');
					$("#register").submit();
					return true;
				}else{
					$('#'+ObjID).html('<img src="images/invalid.png" />');
					$("#username").focus();
					return false;
				}
			}
        }
    );
		}else{
			$('#'+ObjID).html('<img src="images/invalid.png" />');
			elem.focus();
			return false;
		}
	}else{
		$('#'+ObjID).html('<img src="images/invalid.png" />');
		elem.focus();
		return false;
	}
}

function isCustomAlphanumeric(elem,elem2,ObjID, min, max,pattern){
	var uInput = elem.value;
	var pInput = elem2.value;
	if(uInput.length >= min && uInput.length <= max){
		$('#'+ObjID).html('<img src="/images/valid.png" />');
		if(elem.value.match(pattern)){
			$('#'+ObjID).html('<img src="images/valid.png" />');
			if(uInput == pInput){
				$('#'+ObjID).html('<img src="images/valid.png" />');
				return true;
			}else{
				$('#'+ObjID).html('<img src="images/invalid.png" />');
				elem.focus();
				return false;
			}
		}else{
			$('#'+ObjID).html('<img src="images/invalid.png" />');
			elem.focus();
			return false;
		}
	}else{
		$('#'+ObjID).html('<img src="images/invalid.png" />');
		elem.focus();
		return false;
	}
}
function isACustomAlphanumeric(elem,elem2,ObjID, min, max,pattern){
	var uInput = elem.value;
	var pInput = elem2.value;
	if(uInput.length >= min && uInput.length <= max){
		$('#'+ObjID).html('<img src="/images/valid.png" />');
		if(elem.value.match(pattern)){
			$('#'+ObjID).html('<img src="images/valid.png" />');
			if(uInput == pInput){
				$('#'+ObjID).html('<img src="images/valid.png" />');
				$("#change").submit();
				return true;
			}else{
				$('#'+ObjID).html('<img src="images/invalid.png" />');
				elem.focus();
				return false;
			}
		}else{
			$('#'+ObjID).html('<img src="images/invalid.png" />');
			elem.focus();
			return false;
		}
	}else{
		$('#'+ObjID).html('<img src="images/invalid.png" />');
		elem.focus();
		return false;
	}
}
//fungsi validasi karakter untuk email, untuk menentukan apakah ada tanda '@' atau tidak
function emailValidator(elem,ObjID){
	var emailExp = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
	if(elem.value.match(emailExp)){
		$('#'+ObjID).html('<img src="images/valid.png" />');
		return true;
	}else{
		$('#'+ObjID).html('<img src="images/invalid.png" />');
		elem.focus();
		return false;
	}
}

function totalorder(val1,val2,ObjID) {
	var pr1 = val1.value;
	var pr2 = val2.value;
	
	var pr = pr1 * pr2;
	$('.'+ObjID).html('Rp. '+numberFormat(pr, ''));
}
//fungsi untuk menampilkan ',' untuk format ke bentuk uang
function numberFormat(nStr,prefix){
    var prefix = prefix || '';
    nStr += '';
    x = nStr.split('.');
    x1 = x[0];
    x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(x1))
        x1 = x1.replace(rgx, '$1' + ',' + '$2');
    return prefix + x1 + x2;
}
//fungsi untuk notifikasi....
function notification(titles,texts) {
	$.gritter.add({	title: '<p style="color: #fff; font-size: 16px;">'+titles+'</p>', text: '<p style="color: #fff;">'+texts+'</p>' });
}
/*/fungsi ajax untuk request....
function ajaxnewrequest(seturl,text,word) {
	$.ajax({
  	url: seturl,
  	success: function(data) {
		//jika proses request berhasil, maka jalankan fungsi ajax 'cusajaxrequestnoimage' untuk update order
		cusajaxrequestnoimage('update_order.php','order_list');
    	notification(text,word);
		jQuery.facebox($.facebox.close);
  	}
	});
}
*/
function ajaxnewrequest(seturl,text,word,url,ObjID) {
	$.ajax({
  	url: seturl,
  	success: function(data) {
		//jika proses request berhasil, maka jalankan fungsi ajax 'cusajaxrequestnoimage' untuk update order
		cusajaxrequestnoimage(url,ObjID);
    	notification(text,word);
		jQuery.facebox($.facebox.close);
  	}
	});
}
function ajaxnewrequest2(seturl,dest,ObjID) {
	$.ajax({
  	url: seturl,
  	success: function(data) {
		cusajaxrequest2(dest, ObjID);
  	}
	});
}
function ajaxnewrequest3(seturl,dest,update,listorder) {
	$.ajax({
  	url: seturl,
  	success: function(data) {
		cusajaxrequestnoimage(update,listorder)
		jQuery.facebox($.facebox.close);
		jQuery.facebox({ ajax: dest });
  	}
	});
}

function getalltotal(elem1,elem2,res,maxval,qty,totalqty,cost,totalcost) {
	var total=elem1.value*elem2.value;
	$('#'+res).html(numberFormat(total,''));
	
	var i=1; 
	var num1=0;
	var num2=0;
	for (i=1;i<=maxval.value;i++) {
		if (document.getElementById(qty+i).value=='' || document.getElementById(qty+i).value=='0') document.getElementById(qty+i).value=0;
		var val1=parseInt(document.getElementById(qty+i).value);
		var val2=parseInt(document.getElementById(cost+i).value);
		num1+=val1;
		num2+=(val1*val2);
		$('#'+totalqty).html(num1);
		$('#'+totalcost).html(numberFormat(num2,''));
	}
}
//fungsi untuk proses menyimpan apabila ada perubahan pada keranjang belanja, file('simpan_keranjang_detail.php')
function getarrayqty(id,nama,harga,maks) {
	var qry='';
	for (i=1;i<=maks.value;i++) {
		qry+='&pr'+i+'='+document.getElementById(id+i).value+'&q'+i+'='+document.getElementById(nama+i).value+'&p'+i+'='+document.getElementById(harga+i).value;
	}
	return qry;
}