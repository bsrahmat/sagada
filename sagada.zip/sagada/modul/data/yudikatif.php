<?php
	require_once '../../library/connectionmysql.php';
	Connected();
	
	$perm = array();
	$perm = getPermissions('21');

	if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
	if($perm[0]=='1') { require_once '../../library/error-popup.php'; die; }
	if($perm[1]=='1') { require_once '../../library/error-popup.php'; die; }
	if($perm[2]=='1') { require_once '../../library/error-popup.php'; die; }
	
	
	if(isEdit())  {
		$rs_data = mysql_query("select * from tbl_data where data_kode = '".$_GET['gid']."'");
		$rows_data=mysql_fetch_array($rs_data);
	}
//<!-- =========================================================================================================================== -->
?>

<?
//<!-- FORM TIPE MODE 0 = TAMBAH/ADD, TIPE MODE 1 = UBAH/EDIT -->
 if(isAdd() || isEdit()) { ?>
   <div class="popup-shadow" style="width: 600px;">
      <div class="popup-header">
         <span><? if(isAdd()) echo 'Tambah Data'; else echo 'Edit Data'; ?></span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/data/yudikatif.php" method="post">
      <table>
      <tr>
      <td width="25%">Kota</td>
      <td width="5%" align="center">:</td>
      <td><select name="kota_kode" class="select-text select-small">
      	<option value="">Pilih..</option>
      <? 	  
	 
	  $qry_kota = "select * from tbl_kota order by kota_name ASC;";	  
	  $rs_kota = mysql_query($qry_kota);
	  while($rows_kota=mysql_fetch_array($rs_kota)) {
	  ?>
        <option value="<? echo $rows_kota['kota_kode']?>" <? if(isEdit()) if($rows_kota['kota_kode']==$rows_data['kota_kode']) echo 'selected'; ?>><? echo $rows_kota['kota_name']; ?></option>
      <? } ?>
      </select></td>
      </tr>
      <tr>
      <td>Tahun</td>
      <td align="center">:</td>
      <td><select name="tahun_kode" class="select-text select-small">
      	<option value="">Pilih..</option>
      <? 	  
	 
	  $qry_tahun = "select * from tbl_tahun order by tahun_name ASC;";	  
	  $rs_tahun = mysql_query($qry_tahun);
	  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
	  ?>
        <option value="<? echo $rows_tahun['tahun_kode']?>" <? if(isEdit()) if($rows_tahun['tahun_kode']==$rows_data['tahun_kode']) echo 'selected'; ?>><? echo $rows_tahun['tahun_name']; ?></option>
      <? } ?>
      </select></td>
      </tr> 
      <tr>
      <td width="25%"></td>
      <td width="5%" align="center"></td>
      <td>
      <div style="float: left; width: 100%; padding: 2px 0; "><label style="width: 115px; color: black;"><input style="float: left; margin-right: 4px;" type="checkbox" name="form-jaksa" value="1" <? if(isAdd()) {?> checked <? } ?> <? if(isEdit()) if($rows_data['data_kompres'] == '1') echo'checked'; else echo'disabled'; ?>/>Jaksa</label></div>
      <script type="text/javascript">
	  	<? if(isAdd()) {?> $("tr[class^='form_jaksa']").show(); <? } ?><? if(isEdit()) if($rows_data['data_kompres'] == '1') { ?>$("tr[class^='form_jaksa']").show(); <? } ?>
      	$("input[name='form-jaksa']").unbind('click').click(function() { 
			if($(this).attr('checked')==true) {
			$("tr[class^='form_jaksa']").show();
			$(".form_jaksa:first").children('td:last').children().focus();
			} else
			$("tr[class^='form_jaksa']").hide();
		}) 
      </script>
      </td>
      </tr>  
      <tr class="form_jaksa" <? if(isAdd()) echo 'style="display: none;"'; if(isEdit()) if(!$rows_pemantauan['is_progress']) echo 'style="display: none;"'; ?>>
      <td width="25%">Laki-laki</td>
      <td width="5%" align="center">:</td>
      <td><input class="input-text currency padmin" name="jaksa_laki" type="text" value="<? if(isEdit()) echo cFormat($rows_data['data_laki'], false) ?>" /></td>
      </tr>
      <tr class="form_jaksa" <? if(isAdd()) echo 'style="display: none;"'; if(isEdit()) if(!$rows_pemantauan['is_progress']) echo 'style="display: none;"'; ?>>
      <td width="25%">Perempuan</td>
      <td width="5%" align="center">:</td>
      <td><input class="input-text currency padmin" name="jaksa_perempuan" type="text" value="<? if(isEdit()) echo cFormat($rows_data['data_perempuan'], false) ?>" /></td>
      </tr>
      <tr>
      <td width="25%"></td>
      <td width="5%" align="center"></td>
      <td>
      <div style="float: left; width: 100%; padding: 2px 0; "><label style="width: 115px; color: black;"><input style="float: left; margin-right: 4px;" type="checkbox" name="form-hakim" value="2" <? if(isEdit()) if($rows_data['data_kompres'] == '2') echo'checked'; else echo'disabled'; ?>/>Hakim</label></div>
      <script type="text/javascript">
	  <? if(isEdit()) if($rows_data['data_kompres'] == '2') { ?>$("tr[class^='form_hakim']").show(); <? } ?>
      	$("input[name='form-hakim']").unbind('click').click(function() { 
			if($(this).attr('checked')==true) {
			$("tr[class^='form_hakim']").show();
			$(".form_hakim:first").children('td:last').children().focus();
			} else
			$("tr[class^='form_hakim']").hide();
		}) 
      </script>
      </td>
      </tr>  
      <tr class="form_hakim" <? if(isAdd()) echo 'style="display: none;"'; if(isEdit()) if(!$rows_pemantauan['is_progress']) echo 'style="display: none;"'; ?>>
      <td width="25%">Laki-laki</td>
      <td width="5%" align="center">:</td>
      <td><input class="input-text currency padmin" name="hakim_laki" type="text" value="<? if(isEdit()) echo cFormat($rows_data['data_laki'], false) ?>" /></td>
      </tr>
      <tr class="form_hakim" <? if(isAdd()) echo 'style="display: none;"'; if(isEdit()) if(!$rows_pemantauan['is_progress']) echo 'style="display: none;"'; ?>>
      <td width="25%">Perempuan</td>
      <td width="5%" align="center">:</td>
      <td><input class="input-text currency padmin" name="hakim_perempuan" type="text" value="<? if(isEdit()) echo cFormat($rows_data['data_perempuan'], false) ?>" /></td>
      </tr>
      
      <tr>
      <td width="25%"></td>
      <td width="5%" align="center"></td>
      <td>
      <div style="float: left; width: 100%; padding: 2px 0; "><label style="width: 115px; color: black;"><input style="float: left; margin-right: 4px;" type="checkbox" name="form-pengacara" value="7" <? if(isEdit()) if($rows_data['data_kompres'] == '7') echo'checked'; else echo'disabled'; ?>/>Pengacara</label></div>
      <script type="text/javascript">
	  <? if(isEdit()) if($rows_data['data_kompres'] == '7') { ?>$("tr[class^='form_pengacara']").show(); <? } ?>
      	$("input[name='form-pengacara']").unbind('click').click(function() { 
			if($(this).attr('checked')==true) {
			$("tr[class^='form_pengacara']").show();
			$(".form_pengacara:first").children('td:last').children().focus();
			} else
			$("tr[class^='form_pengacara']").hide();
		}) 
      </script>
      </td>
      </tr>  
      <tr class="form_pengacara" <? if(isAdd()) echo 'style="display: none;"'; if(isEdit()) if(!$rows_pemantauan['is_progress']) echo 'style="display: none;"'; ?>>
      <td width="25%">Laki-laki</td>
      <td width="5%" align="center">:</td>
      <td><input class="input-text currency padmin" name="pengacara_laki" type="text" value="<? if(isEdit()) echo cFormat($rows_data['data_laki'], false) ?>" /></td>
      </tr>
      <tr class="form_pengacara" <? if(isAdd()) echo 'style="display: none;"'; if(isEdit()) if(!$rows_pemantauan['is_progress']) echo 'style="display: none;"'; ?>>
      <td width="25%">Perempuan</td>
      <td width="5%" align="center">:</td>
      <td><input class="input-text currency padmin" name="pengacara_perempuan" type="text" value="<? if(isEdit()) echo cFormat($rows_data['data_perempuan'], false) ?>" /></td>
      </tr>
      
      
      <tr>
      <td width="25%"></td>
      <td width="5%" align="center"></td>
      <td>
      <div style="float: left; width: 100%; padding: 2px 0; "><label style="width: 115px; color: black;"><input style="float: left; margin-right: 4px;" type="checkbox" name="form-perwiratinggi" value="3" <? if(isEdit()) if($rows_data['data_kompres'] == '3') echo'checked'; else echo'disabled'; ?>/>Polisi Perwira Tinggi</label></div>
      <script type="text/javascript">
	  <? if(isEdit()) if($rows_data['data_kompres'] == '3') { ?>$("tr[class^='form_perwiratinggi']").show(); <? } ?>
      	$("input[name='form-perwiratinggi']").unbind('click').click(function() { 
			if($(this).attr('checked')==true) {
			$("tr[class^='form_perwiratinggi']").show();
			$(".form_perwiratinggi:first").children('td:last').children().focus();
			} else
			$("tr[class^='form_perwiratinggi']").hide();
		}) 
      </script>
      </td>
      </tr>
      <tr class="form_perwiratinggi" <? if(isAdd()) echo 'style="display: none;"'; if(isEdit()) if(!$rows_pemantauan['is_progress']) echo 'style="display: none;"'; ?>>
      <td width="25%">Jabatan</td>
      <td width="5%" align="center">:</td>
      <td><select name="perwiratinggi_kode" class="select-text">
      	<option value="">Pilih..</option>
      <? 	  
	 
	  $qry_perwiratinggi = "select * from tbl_perwiratinggi order by perwiratinggi_kode ASC;";	  
	  $rs_perwiratinggi = mysql_query($qry_perwiratinggi);
	  while($rows_perwiratinggi=mysql_fetch_array($rs_perwiratinggi)) {
	  ?>
        <option value="<? echo $rows_perwiratinggi['perwiratinggi_kode']?>" <? if(isEdit()) if($rows_perwiratinggi['perwiratinggi_kode']==$rows_data['perwiratinggi_kode']) echo 'selected'; ?>><? echo $rows_perwiratinggi['perwiratinggi_name']; ?></option>
      <? } ?>
      </select></td>
      </tr> 
      <tr class="form_perwiratinggi" <? if(isAdd()) echo 'style="display: none;"'; if(isEdit()) if(!$rows_pemantauan['is_progress']) echo 'style="display: none;"'; ?>>
      <td width="25%">Laki-laki</td>
      <td width="5%" align="center">:</td>
      <td><input class="input-text currency padmin" name="perwiratinggi_laki" type="text" value="<? if(isEdit()) echo cFormat($rows_data['data_laki'], false) ?>" /></td>
      </tr>
      <tr class="form_perwiratinggi" <? if(isAdd()) echo 'style="display: none;"'; if(isEdit()) if(!$rows_pemantauan['is_progress']) echo 'style="display: none;"'; ?>>
      <td width="25%">Perempuan</td>
      <td width="5%" align="center">:</td>
      <td><input class="input-text currency padmin" name="perwiratinggi_perempuan" type="text" value="<? if(isEdit()) echo cFormat($rows_data['data_perempuan'], false) ?>" /></td>
      </tr>
      
      
      
      
      <tr>
      <td width="25%"></td>
      <td width="5%" align="center"></td>
      <td>
      <div style="float: left; width: 100%; padding: 2px 0; "><label style="width: 115px; color: black;"><input style="float: left; margin-right: 4px;" type="checkbox" name="form-perwiramenengah" value="4" <? if(isEdit()) if($rows_data['data_kompres'] == '4') echo'checked'; else echo'disabled'; ?>/>Polisi Perwira Menengah</label></div>
      <script type="text/javascript">
	  <? if(isEdit()) if($rows_data['data_kompres'] == '4') { ?>$("tr[class^='form_perwiramenengah']").show(); <? } ?>
      	$("input[name='form-perwiramenengah']").unbind('click').click(function() { 
			if($(this).attr('checked')==true) {
			$("tr[class^='form_perwiramenengah']").show();
			$(".form_perwiramenengah:first").children('td:last').children().focus();
			} else
			$("tr[class^='form_perwiramenengah']").hide();
		}) 
      </script>
      </td>
      </tr>
      <tr class="form_perwiramenengah" <? if(isAdd()) echo 'style="display: none;"'; if(isEdit()) if(!$rows_pemantauan['is_progress']) echo 'style="display: none;"'; ?>>
      <td width="25%">Jabatan</td>
      <td width="5%" align="center">:</td>
      <td><select name="perwiramenengah_kode" class="select-text">
      	<option value="">Pilih..</option>
      <? 	  
	 
	  $qry_perwiramenengah = "select * from tbl_perwiramenengah order by perwiramenengah_kode ASC;";	  
	  $rs_perwiramenengah = mysql_query($qry_perwiramenengah);
	  while($rows_perwiramenengah=mysql_fetch_array($rs_perwiramenengah)) {
	  ?>
        <option value="<? echo $rows_perwiramenengah['perwiramenengah_kode']?>" <? if(isEdit()) if($rows_perwiramenengah['perwiramenengah_kode']==$rows_data['perwiramenengah_kode']) echo 'selected'; ?>><? echo $rows_perwiramenengah['perwiramenengah_name']; ?></option>
      <? } ?>
      </select></td>
      </tr> 
      <tr class="form_perwiramenengah" <? if(isAdd()) echo 'style="display: none;"'; if(isEdit()) if(!$rows_pemantauan['is_progress']) echo 'style="display: none;"'; ?>>
      <td width="25%">Laki-laki</td>
      <td width="5%" align="center">:</td>
      <td><input class="input-text currency padmin" name="perwiramenengah_laki" type="text" value="<? if(isEdit()) echo cFormat($rows_data['data_laki'], false) ?>" /></td>
      </tr>
      <tr class="form_perwiramenengah" <? if(isAdd()) echo 'style="display: none;"'; if(isEdit()) if(!$rows_pemantauan['is_progress']) echo 'style="display: none;"'; ?>>
      <td width="25%">Perempuan</td>
      <td width="5%" align="center">:</td>
      <td><input class="input-text currency padmin" name="perwiramenengah_perempuan" type="text" value="<? if(isEdit()) echo cFormat($rows_data['data_perempuan'], false) ?>" /></td>
      </tr>
      
      
       <tr>
      <td width="25%"></td>
      <td width="5%" align="center"></td>
      <td>
      <div style="float: left; width: 100%; padding: 2px 0; "><label style="width: 115px; color: black;"><input style="float: left; margin-right: 4px;" type="checkbox" name="form-perwirapertama" value="5" <? if(isEdit()) if($rows_data['data_kompres'] == '5') echo'checked'; else echo'disabled'; ?>/>Polisi Perwira Pertama</label></div>
      <script type="text/javascript">
	  <? if(isEdit()) if($rows_data['data_kompres'] == '5') { ?>$("tr[class^='form_perwirapertama']").show(); <? } ?>
      	$("input[name='form-perwirapertama']").unbind('click').click(function() { 
			if($(this).attr('checked')==true) {
			$("tr[class^='form_perwirapertama']").show();
			$(".form_perwirapertama:first").children('td:last').children().focus();
			} else
			$("tr[class^='form_perwirapertama']").hide();
		}) 
      </script>
      </td>
      </tr>
      <tr class="form_perwirapertama" <? if(isAdd()) echo 'style="display: none;"'; if(isEdit()) if(!$rows_pemantauan['is_progress']) echo 'style="display: none;"'; ?>>
      <td width="25%">Jabatan</td>
      <td width="5%" align="center">:</td>
      <td><select name="perwirapertama_kode" class="select-text">
      	    <option value="">Pilih..</option>
      	    <? 	  
	 
	  $qry_perwirapertama = "select * from tbl_perwirapertama order by perwirapertama_kode ASC;";	  
	  $rs_perwirapertama = mysql_query($qry_perwirapertama);
	  while($rows_perwirapertama=mysql_fetch_array($rs_perwirapertama)) {
	  ?>
      	    <option value="<? echo $rows_perwirapertama['perwirapertama_kode']?>" <? if(isEdit()) if($rows_perwirapertama['perwirapertama_kode']==$rows_data['perwirapertama_kode']) echo 'selected'; ?>><? echo $rows_perwirapertama['perwirapertama_name']; ?></option>
      	    <? } ?>
   	      </select></td>
      </tr>
      
       
      <tr class="form_perwirapertama" <? if(isAdd()) echo 'style="display: none;"'; if(isEdit()) if(!$rows_pemantauan['is_progress']) echo 'style="display: none;"'; ?>>
      <td width="25%">Laki-laki</td>
      <td width="5%" align="center">:</td>
      <td><input class="input-text currency padmin" name="perwirapertama_laki" type="text" value="<? if(isEdit()) echo cFormat($rows_data['data_laki'], false) ?>" /></td>
      </tr>
      <tr class="form_perwirapertama" <? if(isAdd()) echo 'style="display: none;"'; if(isEdit()) if(!$rows_pemantauan['is_progress']) echo 'style="display: none;"'; ?>>
      <td width="25%">Perempuan</td>
      <td width="5%" align="center">:</td>
      <td><input class="input-text currency padmin" name="perwirapertama_perempuan" type="text" value="<? if(isEdit()) echo cFormat($rows_data['data_perempuan'], false) ?>" /></td>
      </tr>
      
       <tr>
      <td width="25%"></td>
      <td width="5%" align="center"></td>
      <td>
      <div style="float: left; width: 100%; padding: 2px 0; "><label style="width: 115px; color: black;"><input style="float: left; margin-right: 4px;" type="checkbox" name="form-bintara" value="2" <? if(isEdit()) if($rows_data['data_kompres'] == '6') echo'checked'; else echo'disabled'; ?>/>Bintara</label></div>
      <script type="text/javascript">
	  <? if(isEdit()) if($rows_data['data_kompres'] == '6') { ?>$("tr[class^='form_bintara']").show(); <? } ?>
      	$("input[name='form-bintara']").unbind('click').click(function() { 
			if($(this).attr('checked')==true) {
			$("tr[class^='form_bintara']").show();
			$(".form_bintara:first").children('td:last').children().focus();
			} else
			$("tr[class^='form_bintara']").hide();
		}) 
      </script>
      </td>
      </tr>  
      <tr class="form_bintara" <? if(isAdd()) echo 'style="display: none;"'; if(isEdit()) if(!$rows_pemantauan['is_progress']) echo 'style="display: none;"'; ?>>
      <td width="25%">Laki-laki</td>
      <td width="5%" align="center">:</td>
      <td><input class="input-text currency padmin" name="bintara_laki" type="text" value="<? if(isEdit()) echo cFormat($rows_data['data_laki'], false) ?>" /></td>
      </tr>
      <tr class="form_bintara" <? if(isAdd()) echo 'style="display: none;"'; if(isEdit()) if(!$rows_pemantauan['is_progress']) echo 'style="display: none;"'; ?>>
      <td width="25%">Perempuan</td>
      <td width="5%" align="center">:</td>
      <td><input class="input-text currency padmin" name="bintara_perempuan" type="text" value="<? if(isEdit()) echo cFormat($rows_data['data_perempuan'], false) ?>" /></td>
      </tr>
      
      
      </table>
      <? if(isEdit())  {?>
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="kode" value="<? echo $rows_data['data_name'] ?>" />
      <input type="hidden" name="data_kompres" value="<? echo $rows_data['data_kompres'] ?>" />
      <? }?>
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel">Batal
      	  
      	</div>
      	<div mode="6" link="library/submenu/data/yudikatif" class="popup-button">Simpan</div>
      </div>
   </div>

<? }  
//<!-- END FORM -->

//<!-- =========================================================================================================================== -->
?>

<? 
//<!-- FORM TIPE MODE 2 = CONFIRM DELETE/KONFIRMASI HAPUS, TIPE MODE 4 = CONFIRM DELETE SELECTED/KONFIRMASI HAPUS YANG DIPILIH -->
if(isConfirmDelete() || isConfirmDeleteSelected()) { ?>
<?
	if(isConfirmDelete()) {
		$rs_data = mysql_query("select * from tbl_data where data_kode = '".$_GET['gid']."'");
		$rows_data=mysql_fetch_array($rs_data);
	}
?>
   <div class="popup-shadow" style="width: 500px;">
      <div class="popup-header">
         <span>Konfirmasi Hapus</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <table>
      <tr>
      <td class="center">
      <? if(isConfirmDelete()) {?>
      		<strong>Peringatan</strong>: <br /> Data <b>Yudikatif</b> akan Dihapus, jika ada data yang terhubung!.
      		<br /><br />
      		Apakah anda yakin menghapus <br /><b style="text-decoration: underline;"><? echo $rows_data['data_name'] ?></b>?
      <? }?>
      
      <? if(isConfirmDeleteSelected()) {?>
      		<? if($_GET['gid']!='') { 
				$value = array();
				$value = generateArray($_GET['gid']); 
			?>
            	<strong>Peringatan: </strong><br /> Data <b>Yudikatif</b> akan ikut terhapus, jika ada data yang terhubung!.
      			<br /><br />
                Sebanyak <b style="text-decoration: underline;"><? echo count($value) ?> data</b> yang akan dihapus!.<br />
                Apakah anda yakin untuk menghapusnya?
            <? } else { ?>
            	Tidak ada item yang akan dihapus.<br />Silahkan anda memilih check box untuk dicentang.
            <? } ?>
      <? }?>
      </td>
      </tr>
      </table>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel"><? if($_GET['gid']!='') echo 'Batal'; else echo 'Tutup' ?></div>
        <? if(isConfirmDelete()) { ?>
      		<div mode="3" link="modul/data/yudikatif?<? echo $_GET['gid'] ?>" class="popup-button">Hapus</div>
        <? }?>
      	<? if(isConfirmDeleteSelected()) {
			if($_GET['gid']!='') {
				if(count($value)>0)
		?>
      		<div mode="5" link="modul/data/yudikatif?<? echo htmlspecialchars($_GET['gid']) ?>" class="popup-button">Hapus</div>
        <? } } ?>
      </div>
      
   </div>

<? } 

?>

<?
 if(isDelete()) { 

	mysql_query("DELETE from tbl_data where data_kode =".$_GET['gid']);
	mysql_query("DELETE from tbl_jurusan where data_kode =".$_GET['gid']);

 } ?>
 
<?
//<!-- END TIPE MODE 3 -->

//<!-- =========================================================================================================================== -->

//<!-- TIPE MODE 5 = DELETE SELECTED/HAPUS YANG DIPILIH -->
?>

<? if(isDeleteSelected()) { 
	
	$value = array();
	$value = generateArray($_GET['gid']); 

	// Taruh query ke database untuk menghapus disini...
	// Contoh :
	for($i=0;$i<count($value);$i++) {
	 	mysql_query("DELETE from tbl_data where data_kode = '".$value[$i]."'");
		mysql_query("DELETE from tbl_jurusan where data_kode = '".$value[$i]."'");
	}
	
 } 
//<!-- END TIPE MODE 5 -->

//<!-- =========================================================================================================================== -->
?>

<?
//<!-- TIPE MODE 6 = SAVE/MENYIMPAN -->
 if(isSave()) { 

$error = array();

if(!$_POST['kota_kode']) $error[] = 'kota_kode:Silahkan Pilih Kabupaten / Kota /Provinsi.';

if(!$_POST['tahun_kode']) $error[] = 'tahun_kode:Silahkan Pilih Tahun.';
if($_POST['form-perwiratinggi']) {
	if(!$_POST['perwiratinggi_kode']) $error[] = 'perwiratinggi_kode:Silahkan Pilih Jabatan Perwira Tinggi.';
}
if($_POST['form-perwiramenengah']) {
	if(!$_POST['perwiramenengah_kode']) $error[] = 'perwiramenengah_kode:Silahkan Pilih Jabatan Perwira Menengah.';
}
if($_POST['form-perwirapertama']) {
	if(!$_POST['perwirapertama_kode']) $error[] = 'perwirapertama_kode:Silahkan Pilih Jabatan Perwira Pertama.';
}
//$error[] = 'form-perwiratinggi:Silahkan Pilih Tahun.';

///if(!$_POST['data_laki']) $error[] = 'data_laki:Silahkan masukkan Jumlah Data Laki-laki.';
//if(!$_POST['data_perempuan']) $error[] = 'data_perempuan:Silahkan Masukkan Data Perempuan.';

/*
$rs_check = mysql_query("select * from tbl_data where data_name = LOWER('".$_POST['data_name']."')");
$rows_check = mysql_num_rows($rs_check);

//jika nambah data baru..
if($_POST['mod']=='0')
	if($rows_check>0) $error[] = 'data_name:Nama Kabupaten / Kota / Provinsi Sudah ada silahkan Coba Yang lain.';

//jika edit data..
if($_POST['mod']=='1') 
	if($_POST['kode']!=strtolower($_POST['data_name']))
		if($rows_check>0) $error[] = 'data_name:Nama Kabupaten / Kota / Provinsi Sudah ada silahkan Coba Yang lain.';
		
*/
if(count($error)>0) {
	//tampilkan pesan error, jika ada error.. :D
	echo generateError($error);
	
} else {
	
	if($_POST['mod']=='0') {
		if($_POST['form-jaksa']) {
			mysql_query("INSERT INTO tbl_data (submenu_kode, kota_kode, tahun_kode, data_kompres, data_laki, data_perempuan) VALUES ('16', '".$_POST['kota_kode']."', '".$_POST['tahun_kode']."', '1', ".isNull($_POST['jaksa_laki'],'CUR').", ".isNull($_POST['jaksa_perempuan'],'CUR').")");
		}
		if($_POST['form-hakim']) {
			mysql_query("INSERT INTO tbl_data (submenu_kode, kota_kode, tahun_kode, data_kompres, data_laki, data_perempuan) VALUES ('16', '".$_POST['kota_kode']."', '".$_POST['tahun_kode']."', '2', ".isNull($_POST['hakim_laki'],'CUR').", ".isNull($_POST['hakim_perempuan'],'CUR').")");
		}
		
		if($_POST['form-pengacara']) {
			mysql_query("INSERT INTO tbl_data (submenu_kode, kota_kode, tahun_kode, data_kompres, data_laki, data_perempuan) VALUES ('16', '".$_POST['kota_kode']."', '".$_POST['tahun_kode']."', '7', ".isNull($_POST['pengacara_laki'],'CUR').", ".isNull($_POST['pengacara_perempuan'],'CUR').")");
		}
		
		if($_POST['form-perwiratinggi']) {
			mysql_query("INSERT INTO tbl_data (submenu_kode, kota_kode, tahun_kode, data_kompres, perwiratinggi_kode, data_laki, data_perempuan) VALUES ('16', '".$_POST['kota_kode']."', '".$_POST['tahun_kode']."', '3', '".$_POST['perwiratinggi_kode']."', ".isNull($_POST['perwiratinggi_laki'],'CUR').", ".isNull($_POST['perwiratinggi_perempuan'],'CUR').")");
		}
		if($_POST['form-perwiramenengah']) {
			mysql_query("INSERT INTO tbl_data (submenu_kode, kota_kode, tahun_kode, data_kompres, perwiramenengah_kode, data_laki, data_perempuan) VALUES ('16', '".$_POST['kota_kode']."', '".$_POST['tahun_kode']."', '4', '".$_POST['perwiramenengah_kode']."', ".isNull($_POST['perwiramenengah_laki'],'CUR').", ".isNull($_POST['perwiramenengah_perempuan'],'CUR').")");
		}
		if($_POST['form-perwirapertama']) {
			mysql_query("INSERT INTO tbl_data (submenu_kode, kota_kode, tahun_kode, data_kompres, perwirapertama_kode, data_laki, data_perempuan) VALUES ('16', '".$_POST['kota_kode']."', '".$_POST['tahun_kode']."', '5', '".$_POST['perwirapertama_kode']."',".isNull($_POST['perwirapertama_laki'],'CUR').", ".isNull($_POST['perwirapertama_perempuan'],'CUR').")");
		}
		
		if($_POST['form-bintara']) {
			mysql_query("INSERT INTO tbl_data (submenu_kode, kota_kode, tahun_kode, data_kompres, data_laki, data_perempuan) VALUES ('16', '".$_POST['kota_kode']."', '".$_POST['tahun_kode']."', '6', ".isNull($_POST['bintara_laki'],'CUR').", ".isNull($_POST['bintara_perempuan'],'CUR').")");
		}
		
		
	}
	
	if($_POST['mod']=='1') {
		if($_POST['data_kompres'] == '1') {
			mysql_query("UPDATE tbl_data SET kota_kode = '".$_POST['kota_kode']."', tahun_kode = '".$_POST['tahun_kode']."', data_laki = ".isNull($_POST['jaksa_laki'],'CUR').", data_perempuan = ".isNull($_POST['jaksa_perempuan'],'CUR')." WHERE data_kode ='".$_POST['gid']."';");
			
		}
		if($_POST['data_kompres'] == '2') {
			mysql_query("UPDATE tbl_data SET kota_kode = '".$_POST['kota_kode']."', tahun_kode = '".$_POST['tahun_kode']."', data_laki = ".isNull($_POST['hakim_laki'],'CUR').", data_perempuan = ".isNull($_POST['hakim_perempuan'],'CUR')." WHERE data_kode ='".$_POST['gid']."';");
		}
		
		if($_POST['data_kompres'] == '7') {
			mysql_query("UPDATE tbl_data SET kota_kode = '".$_POST['kota_kode']."', tahun_kode = '".$_POST['tahun_kode']."', data_laki = ".isNull($_POST['pengacara_laki'],'CUR').", data_perempuan = ".isNull($_POST['pengacara_perempuan'],'CUR')." WHERE data_kode ='".$_POST['gid']."';");
		}
		
		
		if($_POST['data_kompres'] == '3') {			
			mysql_query("UPDATE tbl_data SET kota_kode = '".$_POST['kota_kode']."', tahun_kode = '".$_POST['tahun_kode']."', data_laki = ".isNull($_POST['perwiratinggi_laki'],'CUR').", data_perempuan = ".isNull($_POST['perwiratinggi_perempuan'],'CUR').", perwiratinggi_kode = '".$_POST['perwiratinggi_kode']."' WHERE data_kode ='".$_POST['gid']."';");			
			
		}
		if($_POST['data_kompres'] == '4') {
			mysql_query("UPDATE tbl_data SET kota_kode = '".$_POST['kota_kode']."', tahun_kode = '".$_POST['tahun_kode']."', data_laki = ".isNull($_POST['perwiramenengah_laki'],'CUR').", data_perempuan = ".isNull($_POST['perwiramenengah_perempuan'],'CUR').", perwiramenengah_kode = '".$_POST['perwiramenengah_kode']."' WHERE data_kode ='".$_POST['gid']."';");	
		}
		if($_POST['data_kompres'] == '5') {
			mysql_query("UPDATE tbl_data SET kota_kode = '".$_POST['kota_kode']."', data_brigadir = '".$brigadir."', tahun_kode = '".$_POST['tahun_kode']."', data_laki = ".isNull($_POST['perwirapertama_laki'],'CUR').", data_perempuan = ".isNull($_POST['perwirapertama_perempuan'],'CUR').", perwirapertama_kode = '".$_POST['perwirapertama_kode']."' WHERE data_kode ='".$_POST['gid']."';");	
		}
		
		if($_POST['data_kompres'] == '6') {
			mysql_query("UPDATE tbl_data SET kota_kode = '".$_POST['kota_kode']."', tahun_kode = '".$_POST['tahun_kode']."', data_laki = ".isNull($_POST['bintara_laki'],'CUR').", data_perempuan = ".isNull($_POST['bintara_perempuan'],'CUR')." WHERE data_kode ='".$_POST['gid']."';");
		}
		
		//mysql_query("UPDATE tbl_data SET kota_kode = '".$_POST['kota_kode']."', tahun_kode = '".$_POST['tahun_kode']."', parpol_kode = '".$_POST['parpol_kode']."', data_laki = ".isNull($_POST['data_laki'],'CUR').", data_perempuan = ".isNull($_POST['data_perempuan'],'CUR')." WHERE data_kode ='".$_POST['gid']."';");
	}
		
}

} 
//<!-- END TIPE MODE 6 --> 
?>

