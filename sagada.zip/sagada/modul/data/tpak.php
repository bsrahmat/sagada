<?php
	require_once '../../library/connectionmysql.php';
	Connected();
	
	$perm = array();
	$perm = getPermissions('9');

	if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
	if($perm[0]=='1') { require_once '../../library/error-popup.php'; die; }
	if($perm[1]=='1') { require_once '../../library/error-popup.php'; die; }
	if($perm[2]=='1') { require_once '../../library/error-popup.php'; die; }
	
	
	if(isEdit())  {
		$rs_data = mysql_query("select * from tbl_data where data_kode = '".$_GET['gid']."'");
		$rows_data=mysql_fetch_array($rs_data);
	}
//<!-- =========================================================================================================================== -->
?>

<?
//<!-- FORM TIPE MODE 0 = TAMBAH/ADD, TIPE MODE 1 = UBAH/EDIT -->
 if(isAdd() || isEdit()) { ?>
   <div class="popup-shadow" style="width: 600px;">
      <div class="popup-header">
         <span><? if(isAdd()) echo 'Tambah Data'; else echo 'Edit Data'; ?></span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/data/tpak.php" method="post">
      <table>
      <tr>
      <td width="25%">Kota</td>
      <td width="5%" align="center">:</td>
      <td><select name="kota_kode" class="select-text select-small">
      	<option value="">Pilih..</option>
      <? 	  
	 
	  $qry_kota = "select * from tbl_kota order by kota_name ASC;";	  
	  $rs_kota = mysql_query($qry_kota);
	  while($rows_kota=mysql_fetch_array($rs_kota)) {
	  ?>
        <option value="<? echo $rows_kota['kota_kode']?>" <? if(isEdit()) if($rows_kota['kota_kode']==$rows_data['kota_kode']) echo 'selected'; ?>><? echo $rows_kota['kota_name']; ?></option>
      <? } ?>
      </select></td>
      </tr>
      <tr>
      <td>Tahun</td>
      <td align="center">:</td>
      <td><select name="tahun_kode" class="select-text select-small">
      	<option value="">Pilih..</option>
      <? 	  
	 
	  $qry_tahun = "select * from tbl_tahun order by tahun_name ASC;";	  
	  $rs_tahun = mysql_query($qry_tahun);
	  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
	  ?>
        <option value="<? echo $rows_tahun['tahun_kode']?>" <? if(isEdit()) if($rows_tahun['tahun_kode']==$rows_data['tahun_kode']) echo 'selected'; ?>><? echo $rows_tahun['tahun_name']; ?></option>
      <? } ?>
      </select></td>
      </tr>
      <tr>
      <td>Laki-Laki</td>
      <td align="center">:</td>
      <td><input class="input-text currency padmin" name="data_laki" type="text" value="<? if(isEdit()) echo cFormat($rows_data['data_laki'], false) ?>" /></td>
      </tr>
      <tr>
      <td>Perempuan</td>
      <td align="center">:</td>
      <td><input class="input-text currency padmin" name="data_perempuan" type="text" value="<? if(isEdit()) echo cFormat($rows_data['data_perempuan'], false) ?>" /></td>
      </tr>
      
      <tr>
      <td>Sumber</td>
      <td align="center">:</td>
      <td><textarea class="input-text input-large" name="data_sumber" rows="3"><? if(isEdit()) echo $rows_data['data_sumber'] ?></textarea></td>
      </tr>
      <tr>
      <td>Operator</td>
      <td align="center">:</td>
      <td><input class="input-text input-large" name="data_operator" type="text" value="<? if(isEdit()) echo $rows_data['data_operator'] ?>" /></td>
      </tr>
      </table>
      <? if(isEdit())  {?>
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="kode" value="<? echo $rows_data['data_name'] ?>" />
      <? }?>
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/data/tpak" class="popup-button">Simpan</div>
      </div>
   </div>

<? }  
//<!-- END FORM -->

//<!-- =========================================================================================================================== -->
?>

<? 
//<!-- FORM TIPE MODE 2 = CONFIRM DELETE/KONFIRMASI HAPUS, TIPE MODE 4 = CONFIRM DELETE SELECTED/KONFIRMASI HAPUS YANG DIPILIH -->
if(isConfirmDelete() || isConfirmDeleteSelected()) { ?>
<?
	if(isConfirmDelete()) {
		$rs_data = mysql_query("select * from tbl_data where data_kode = '".$_GET['gid']."'");
		$rows_data=mysql_fetch_array($rs_data);
	}
?>
   <div class="popup-shadow" style="width: 500px;">
      <div class="popup-header">
         <span>Konfirmasi Hapus</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <table>
      <tr>
      <td class="center">
      <? if(isConfirmDelete()) {?>
      		<strong>Peringatan</strong>: <br /> Data <b>Tingkat Partisipasi Angkatan Kerja (TPAK)</b> akan Dihapus, jika ada data yang terhubung!.
      		<br /><br />
      		Apakah anda yakin menghapus <br /><b style="text-decoration: underline;"><? echo $rows_data['data_name'] ?></b>?
      <? }?>
      
      <? if(isConfirmDeleteSelected()) {?>
      		<? if($_GET['gid']!='') { 
				$value = array();
				$value = generateArray($_GET['gid']); 
			?>
            	<strong>Peringatan: </strong><br /> Data <b>Tingkat Partisipasi Angkatan Kerja (TPAK)</b> akan ikut terhapus, jika ada data yang terhubung!.
      			<br /><br />
                Sebanyak <b style="text-decoration: underline;"><? echo count($value) ?> data</b> yang akan dihapus!.<br />
                Apakah anda yakin untuk menghapusnya?
            <? } else { ?>
            	Tidak ada item yang akan dihapus.<br />Silahkan anda memilih check box untuk dicentang.
            <? } ?>
      <? }?>
      </td>
      </tr>
      </table>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel"><? if($_GET['gid']!='') echo 'Batal'; else echo 'Tutup' ?></div>
        <? if(isConfirmDelete()) { ?>
      		<div mode="3" link="modul/data/tpak?<? echo $_GET['gid'] ?>" class="popup-button">Hapus</div>
        <? }?>
      	<? if(isConfirmDeleteSelected()) {
			if($_GET['gid']!='') {
				if(count($value)>0)
		?>
      		<div mode="5" link="modul/data/tpak?<? echo htmlspecialchars($_GET['gid']) ?>" class="popup-button">Hapus</div>
        <? } } ?>
      </div>
      
   </div>

<? } 

?>

<?
 if(isDelete()) { 

	mysql_query("DELETE from tbl_data where data_kode =".$_GET['gid']);
	mysql_query("DELETE from tbl_jurusan where data_kode =".$_GET['gid']);

 } ?>
 
<?
//<!-- END TIPE MODE 3 -->

//<!-- =========================================================================================================================== -->

//<!-- TIPE MODE 5 = DELETE SELECTED/HAPUS YANG DIPILIH -->
?>

<? if(isDeleteSelected()) { 
	
	$value = array();
	$value = generateArray($_GET['gid']); 

	// Taruh query ke database untuk menghapus disini...
	// Contoh :
	for($i=0;$i<count($value);$i++) {
	 	mysql_query("DELETE from tbl_data where data_kode = '".$value[$i]."'");
		mysql_query("DELETE from tbl_jurusan where data_kode = '".$value[$i]."'");
	}
	
 } 
//<!-- END TIPE MODE 5 -->

//<!-- =========================================================================================================================== -->
?>

<?
//<!-- TIPE MODE 6 = SAVE/MENYIMPAN -->
 if(isSave()) { 

$error = array();

if(!$_POST['kota_kode']) $error[] = 'kota_kode:Silahkan Pilih Kabupaten / Kota /Provinsi.';
if(!$_POST['tahun_kode']) $error[] = 'tahun_kode:Silahkan Pilih Tahun.';
//if(!$_POST['data_laki']) $error[] = 'data_laki:Silahkan masukkan Jumlah Data Laki-laki.';
//if(!$_POST['data_perempuan']) $error[] = 'data_perempuan:Silahkan Masukkan Data Perempuan.';
if(!$_POST['data_sumber']) $error[] = 'data_sumber:Silahkan Masukkan Sumber Berita.';
if(!$_POST['data_operator']) $error[] = 'data_operator:Silahkan masukkan Nama Operator.';
/*
$rs_check = mysql_query("select * from tbl_data where data_name = LOWER('".$_POST['data_name']."')");
$rows_check = mysql_num_rows($rs_check);

//jika nambah data baru..
if($_POST['mod']=='0')
	if($rows_check>0) $error[] = 'data_name:Nama Kabupaten / Kota / Provinsi Sudah ada silahkan Coba Yang lain.';

//jika edit data..
if($_POST['mod']=='1') 
	if($_POST['kode']!=strtolower($_POST['data_name']))
		if($rows_check>0) $error[] = 'data_name:Nama Kabupaten / Kota / Provinsi Sudah ada silahkan Coba Yang lain.';
		
*/
if(count($error)>0) {
	//tampilkan pesan error, jika ada error.. :D
	echo generateError($error);
	
} else {
	
	if($_POST['mod']=='0') {
		mysql_query("INSERT INTO tbl_data (submenu_kode, kota_kode,  tahun_kode, data_laki, data_perempuan, data_sumber, data_operator) VALUES ('9', '".$_POST['kota_kode']."', '".$_POST['tahun_kode']."', ".isNull($_POST['data_laki'],'CUR').", ".isNull($_POST['data_perempuan'],'CUR').", '".$_POST['data_sumber']."', '".$_POST['data_operator']."')");
		
	}
	
	if($_POST['mod']=='1') {
		mysql_query("UPDATE tbl_data SET kota_kode = '".$_POST['kota_kode']."', tahun_kode = '".$_POST['tahun_kode']."', data_laki = ".isNull($_POST['data_laki'],'CUR').", data_perempuan = ".isNull($_POST['data_perempuan'],'CUR').", data_sumber = '".$_POST['data_sumber']."', data_operator = '".$_POST['data_operator']."' WHERE data_kode ='".$_POST['gid']."';");
	}
		
}

} 
//<!-- END TIPE MODE 6 --> 
?>

