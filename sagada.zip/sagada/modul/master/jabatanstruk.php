<?php
	require_once '../../library/connectionmysql.php';
	Connected();
	
	$perm = array();
	$perm = getPermissions('2');

	if($perm[-1]=='1') { require_once '../../library/error-popup.php'; die; }
	if($perm[0]=='1') { require_once '../../library/error-popup.php'; die; }
	if($perm[1]=='1') { require_once '../../library/error-popup.php'; die; }
	if($perm[2]=='1') { require_once '../../library/error-popup.php'; die; }
	
	
	if(isEdit())  {
		$rs_jabatanstruk = mysql_query("select * from tbl_jabatanstruk where jabatanstruk_kode = '".$_GET['gid']."'");
		$rows_jabatanstruk=mysql_fetch_array($rs_jabatanstruk);
	}
//<!-- =========================================================================================================================== -->
?>

<?
//<!-- FORM TIPE MODE 0 = TAMBAH/ADD, TIPE MODE 1 = UBAH/EDIT -->
 if(isAdd() || isEdit()) { ?>
   <div class="popup-shadow" style="width: 600px;">
      <div class="popup-header">
         <span><? if(isAdd()) echo 'Tambah Data'; else echo 'Edit Data'; ?></span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <form action="modul/master/jabatanstruk.php" method="post">
      <table>
      <tr>
      <td width="25%">Struktural Eselon</td>
      <td width="5%" align="center">:</td>
      <td><input class="input-text input-large" name="jabatanstruk_name" type="text" value="<? if(isEdit()) echo $rows_jabatanstruk['jabatanstruk_name'] ?>" /></td>
      </tr>
      </table>
      <? if(isEdit())  {?>
      <input type="hidden" name="gid" value="<? echo $_GET['gid'] ?>" />
      <input type="hidden" name="kode" value="<? echo $rows_jabatanstruk['jabatanstruk_name'] ?>" />
      <? }?>
      <input type="hidden" name="mod" value="<? echo $_GET['mod'] ?>" />
      </form>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel">Batal</div>
      	<div mode="6" link="library/submenu/master/jabatanstruk" class="popup-button">Simpan</div>
      </div>
   </div>

<? }  
//<!-- END FORM -->

//<!-- =========================================================================================================================== -->
?>

<? 
//<!-- FORM TIPE MODE 2 = CONFIRM DELETE/KONFIRMASI HAPUS, TIPE MODE 4 = CONFIRM DELETE SELECTED/KONFIRMASI HAPUS YANG DIPILIH -->
if(isConfirmDelete() || isConfirmDeleteSelected()) { ?>
<?
	if(isConfirmDelete()) {
		$rs_jabatanstruk = mysql_query("select * from tbl_jabatanstruk where jabatanstruk_kode = '".$_GET['gid']."'");
		$rows_jabatanstruk=mysql_fetch_array($rs_jabatanstruk);
	}
?>
   <div class="popup-shadow" style="width: 500px;">
      <div class="popup-header">
         <span>Konfirmasi Hapus</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <table>
      <tr>
      <td class="center">
      <? if(isConfirmDelete()) {?>
      		<strong>Peringatan</strong>: <br /> Data <b>Jabatan Struktural</b> akan Dihapus, jika ada data yang terhubung!.
      		<br /><br />
      		Apakah anda yakin menghapus <br /><b style="text-decoration: underline;">Eselon <? echo $rows_jabatanstruk['jabatanstruk_name'] ?></b>?
      <? }?>
      
      <? if(isConfirmDeleteSelected()) {?>
      		<? if($_GET['gid']!='') { 
				$value = array();
				$value = generateArray($_GET['gid']); 
			?>
            	<strong>Peringatan: </strong><br /> Data <b>Jabatan Struktural</b> akan ikut terhapus, jika ada data yang terhubung!.
      			<br /><br />
                Sebanyak <b style="text-decoration: underline;"><? echo count($value) ?> data</b> yang akan dihapus!.<br />
                Apakah anda yakin untuk menghapusnya?
            <? } else { ?>
            	Tidak ada item yang akan dihapus.<br />Silahkan anda memilih check box untuk dicentang.
            <? } ?>
      <? }?>
      </td>
      </tr>
      </table>
      </div>
      <div class="popup-footer">
      	<div class="popup-cancel"><? if($_GET['gid']!='') echo 'Batal'; else echo 'Tutup' ?></div>
        <? if(isConfirmDelete()) { ?>
      		<div mode="3" link="modul/master/jabatanstruk?<? echo $_GET['gid'] ?>" class="popup-button">Hapus</div>
        <? }?>
      	<? if(isConfirmDeleteSelected()) {
			if($_GET['gid']!='') {
				if(count($value)>0)
		?>
      		<div mode="5" link="modul/master/jabatanstruk?<? echo htmlspecialchars($_GET['gid']) ?>" class="popup-button">Hapus</div>
        <? } } ?>
      </div>
      
   </div>

<? } 

?>

<?
 if(isDelete()) { 

	mysql_query("DELETE from tbl_jabatanstruk where jabatanstruk_kode =".$_GET['gid']);
	mysql_query("DELETE from tbl_jurusan where jabatanstruk_kode =".$_GET['gid']);

 } ?>
 
<?
//<!-- END TIPE MODE 3 -->

//<!-- =========================================================================================================================== -->

//<!-- TIPE MODE 5 = DELETE SELECTED/HAPUS YANG DIPILIH -->
?>

<? if(isDeleteSelected()) { 
	
	$value = array();
	$value = generateArray($_GET['gid']); 

	// Taruh query ke database untuk menghapus disini...
	// Contoh :
	for($i=0;$i<count($value);$i++) {
	 	mysql_query("DELETE from tbl_jabatanstruk where jabatanstruk_kode = '".$value[$i]."'");
		mysql_query("DELETE from tbl_jurusan where jabatanstruk_kode = '".$value[$i]."'");
	}
	
 } 
//<!-- END TIPE MODE 5 -->

//<!-- =========================================================================================================================== -->
?>

<?
//<!-- TIPE MODE 6 = SAVE/MENYIMPAN -->
 if(isSave()) { 

$error = array();

if(!$_POST['jabatanstruk_name']) $error[] = 'jabatanstruk_name:Silahkan masukkan Nama Jabatan Struktural.';

$rs_check = mysql_query("select * from tbl_jabatanstruk where jabatanstruk_name = LOWER('".$_POST['jabatanstruk_name']."')");
$rows_check = mysql_num_rows($rs_check);

//jika nambah data baru..
if($_POST['mod']=='0')
	if($rows_check>0) $error[] = 'jabatanstruk_name:Nama Jabatan Struktural Sudah ada silahkan Coba Yang lain.';

//jika edit data..
if($_POST['mod']=='1') 
	if($_POST['kode']!=strtolower($_POST['jabatanstruk_name']))
		if($rows_check>0) $error[] = 'jabatanstruk_name:Nama Jabatan Struktural Sudah ada silahkan Coba Yang lain.';
		

if(count($error)>0) {
	//tampilkan pesan error, jika ada error.. :D
	echo generateError($error);
	
} else {
	
	if($_POST['mod']=='0') {
		mysql_query("INSERT INTO tbl_jabatanstruk (jabatanstruk_name) VALUES ('".$_POST['jabatanstruk_name']."')");
		
	}
	
	if($_POST['mod']=='1') {
		mysql_query("UPDATE tbl_jabatanstruk SET jabatanstruk_name = '".$_POST['jabatanstruk_name']."' WHERE jabatanstruk_kode ='".$_POST['gid']."';");
	}
		
}

} 
//<!-- END TIPE MODE 6 --> 
?>

