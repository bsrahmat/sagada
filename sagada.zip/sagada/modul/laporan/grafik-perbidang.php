<?php


require_once '../../library/connectionmysql.php';
Connected();
if($_SESSION['saga_posisi']=='none' || !isset($_SESSION['saga_posisi'])) { header("Location: ../../index.php"); die; }
if($_SESSION['saga_kode']=='none' || !isset($_SESSION['saga_kode'])) { header("Location: ../../index.php"); die; }


$error = array();

if(!$_POST['tahun_sampai']) $error[] = 'tahun_sampai:Silahkan Pilih Tahun Akhir.';
if(!$_POST['kota_kode']) $error[] = 'kota_kode:Silahkan Pilih Kota / Kabupaten.';
if(!$_POST['menu_kode']) $error[] = 'menu_kode:Silahkan Pilih Sektor Bidang.';


if(count($error)>0) {
	//tampilkan pesan error, jika ada error.. :D
	echo generateError($error).'|*|';	
	
	
} else {
	
	$rs_tahunsampai= mysql_query("select * from tbl_tahun WHERE tahun_kode = '".$_POST['tahun_sampai']."'");
	$rows_tahunsampai=mysql_fetch_array($rs_tahunsampai);
	
	
	$rs_kotas= mysql_query("select * from tbl_kota WHERE kota_kode  = '".$_POST['kota_kode']."'");
	$rows_kotas=mysql_fetch_array($rs_kotas);
	?>
	
    <?  
	switch($_POST['menu_kode']) {
	case '9': ?>
    <script type="text/javascript">
$(function () {
    var chart;
    $(document).ready(function() {
        chart = new Highcharts.Chart({
            chart: {
                renderTo: 'diagram-ahp',
                type: 'column'
            },
            title: {
                text: 'Angka Harapan Hidup'
            },
            subtitle: {
                text: 'Sistem Informasi Gender dan Anak Papua'
            },
            xAxis: {
                categories: [	
				<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
								echo $rows_tahun['tahun_name'].',';
				  } ?>
                ]
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Jumlah'
                }
            },
            legend: {
                layout: 'vertical',
                backgroundColor: '#FFFFFF',
                align: 'left',
                verticalAlign: 'top',
                x: 100,
                y: 70,
                floating: true,
                shadow: true
            },
            tooltip: {
                formatter: function() {
                    return ''+
                        this.x +': '+ this.y +' Orang';
                }
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0
                }
            },
                series: [{
                name: 'Laki-laki',
                data: [
				  <? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_laki=mysql_fetch_array(mysql_query("select sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '28'"));
					echo $rows_laki['data_laki'].'0,';								
		  
				  } ?>]
    
            }, {
                name: 'Perempuan',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_perem=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '28'"));
					echo $rows_perem['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }]
        });
    });
    
});
		</script>
        
        <div id="diagram-ahp" style="min-width: 680px; height: 480px; margin: 1px auto"></div>
    
    
    
    <script type="text/javascript">
$(function () {
    var chart;
    $(document).ready(function() {
        chart = new Highcharts.Chart({
            chart: {
                renderTo: 'diagram-akim',
                type: 'column'
            },
            title: {
                text: 'Jumlah Kematian Ibu Melahirkan'
            },
            subtitle: {
                text: 'Sistem Informasi Gender dan Anak Papua'
            },
            xAxis: {
                categories: [	
				<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
								echo $rows_tahun['tahun_name'].',';
				  } ?>
                ]
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Jumlah'
                }
            },
            legend: {
                layout: 'vertical',
                backgroundColor: '#FFFFFF',
                align: 'left',
                verticalAlign: 'top',
                x: 100,
                y: 70,
                floating: true,
                shadow: true
            },
            tooltip: {
                formatter: function() {
                    return ''+
                        this.x +': '+ this.y +' Orang';
                }
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0
                }
            },
                series: [{
                name: '15-19',
                data: [
				  <? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '29' AND kelumur_kode = '1'"));
					echo $rows_one['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }, {
                name: '20-24',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '29' AND kelumur_kode = '2'"));
					echo $rows_one['data_perempuan'].'0,';						
		  
				  } ?>]
    
            }, {
                name: '25-29',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '29' AND kelumur_kode = '3'"));
					echo $rows_one['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }, {
                name: '30-34',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '29' AND kelumur_kode = '4'"));
					echo $rows_one['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }, {
                name: '35-39',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '29' AND kelumur_kode = '5'"));
					echo $rows_one['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }, {
                name: '40-44',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '29' AND kelumur_kode = '6'"));
					echo $rows_one['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }, {
                name: '45+',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '29' AND kelumur_kode = '7'"));
					echo $rows_one['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }]
        });
    });
    
});
		</script>
        
        <div id="diagram-akim" style="min-width: 680px; height: 480px; margin: 1px auto"></div>
    
    
    <script type="text/javascript">
$(function () {
    var chart;
    $(document).ready(function() {
        chart = new Highcharts.Chart({
            chart: {
                renderTo: 'diagram-itih',
                type: 'column'
            },
            title: {
                text: 'Imunisasi TT pada Ibu Hamil'
            },
            subtitle: {
                text: 'Sistem Informasi Gender dan Anak Papua'
            },
            xAxis: {
                categories: [	
				<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
								echo $rows_tahun['tahun_name'].',';
				  } ?>
                ]
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Jumlah'
                }
            },
            legend: {
                layout: 'vertical',
                backgroundColor: '#FFFFFF',
                align: 'left',
                verticalAlign: 'top',
                x: 100,
                y: 70,
                floating: true,
                shadow: true
            },
            tooltip: {
                formatter: function() {
                    return ''+
                        this.x +': '+ this.y +' Orang';
                }
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0
                }
            },
                series: [{
                name: '15-19',
                data: [
				  <? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '30' AND kelumur_kode = '1'"));
					echo $rows_one['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }, {
                name: '20-24',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '30' AND kelumur_kode = '2'"));
					echo $rows_one['data_perempuan'].'0,';						
		  
				  } ?>]
    
            }, {
                name: '25-29',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '30' AND kelumur_kode = '3'"));
					echo $rows_one['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }, {
                name: '30-34',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '30' AND kelumur_kode = '4'"));
					echo $rows_one['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }, {
                name: '35-39',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '30' AND kelumur_kode = '5'"));
					echo $rows_one['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }, {

                name: '40-44',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '30' AND kelumur_kode = '6'"));
					echo $rows_one['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }, {
                name: '45+',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '30' AND kelumur_kode = '7'"));
					echo $rows_one['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }]
        });
    });
    
});
		</script>
       
         <div id="diagram-itih" style="min-width: 680px; height: 480px; margin: 1px auto"></div>
         
         
         <script type="text/javascript">
$(function () {
    var chart;
    $(document).ready(function() {
        chart = new Highcharts.Chart({
            chart: {
                renderTo: 'diagram-fe',
                type: 'column'
            },
            title: {
                text: 'Ibu Hamil yang mendapatkan tablet Zat Besi (Fe)'
            },
            subtitle: {
                text: 'Sistem Informasi Gender dan Anak Papua'
            },
            xAxis: {
                categories: [	
				<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
								echo $rows_tahun['tahun_name'].',';
				  } ?>
                ]
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Jumlah'
                }
            },
            legend: {
                layout: 'vertical',
                backgroundColor: '#FFFFFF',
                align: 'left',
                verticalAlign: 'top',
                x: 100,
                y: 70,
                floating: true,
                shadow: true
            },
            tooltip: {
                formatter: function() {
                    return ''+
                        this.x +': '+ this.y +' Orang';
                }
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0
                }
            },
                series: [{
                name: '15-19',
                data: [
				  <? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '31' AND kelumur_kode = '1'"));
					echo $rows_one['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }, {
                name: '20-24',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '31' AND kelumur_kode = '2'"));
					echo $rows_one['data_perempuan'].'0,';						
		  
				  } ?>]
    
            }, {
                name: '25-29',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '31' AND kelumur_kode = '3'"));
					echo $rows_one['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }, {
                name: '30-34',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '31' AND kelumur_kode = '4'"));
					echo $rows_one['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }, {
                name: '35-39',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '31' AND kelumur_kode = '5'"));
					echo $rows_one['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }, {
                name: '40-44',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '31' AND kelumur_kode = '6'"));
					echo $rows_one['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }, {
                name: '45+',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '31' AND kelumur_kode = '7'"));
					echo $rows_one['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }]
        });
    });
    
});
		</script>
   <div id="diagram-fe" style="min-width: 680px; height: 480px; margin: 1px auto"></div>
   
   
   <script type="text/javascript">
$(function () {
    var chart;
    $(document).ready(function() {
        chart = new Highcharts.Chart({
            chart: {
                renderTo: 'diagram-kb',
                type: 'column'
            },
            title: {
                text: 'Keluarga Berencana'
            },
            subtitle: {
                text: 'Sistem Informasi Gender dan Anak Papua'
            },
            xAxis: {
                categories: [	
				<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
								echo $rows_tahun['tahun_name'].',';
				  } ?>
                ]
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Jumlah'
                }
            },
            legend: {
                layout: 'vertical',
                backgroundColor: '#FFFFFF',
                align: 'left',
                verticalAlign: 'top',
                x: 100,
                y: 70,
                floating: true,
                shadow: true
            },
            tooltip: {
                formatter: function() {
                    return ''+
                        this.x +': '+ this.y +' Orang';
                }
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0
                }
            },
                series: [{
                name: 'Perempuan',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_perem=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '33'"));
					echo $rows_perem['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }]
        });
    });
    
});
		</script>
   <div id="diagram-kb" style="min-width: 680px; height: 480px; margin: 1px auto"></div>
   
   
    <script type="text/javascript">
$(function () {
    var chart;
    $(document).ready(function() {
        chart = new Highcharts.Chart({
            chart: {
                renderTo: 'diagram-narkoba',
                type: 'column'
            },
            title: {
                text: 'Narkoba'
            },
            subtitle: {
                text: 'Sistem Informasi Gender dan Anak Papua'
            },
            xAxis: {
                categories: [	
				<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
								echo $rows_tahun['tahun_name'].',';
				  } ?>
                ]
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Jumlah'
                }
            },
            legend: {
                layout: 'vertical',
                backgroundColor: '#FFFFFF',
                align: 'left',
                verticalAlign: 'top',
                x: 100,
                y: 70,
                floating: true,
                shadow: true
            },
            tooltip: {
                formatter: function() {
                    return ''+
                        this.x +': '+ this.y +' Orang';
                }
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0
                }
            },
                series: [{
                name: '15-19',
                data: [
				  <? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '34' AND kelumur_kode = '1'"));
					echo $rows_one['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }, {
                name: '20-24',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '34' AND kelumur_kode = '2'"));
					echo $rows_one['data_perempuan'].'0,';						
		  
				  } ?>]
    
            }, {
                name: '25-29',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '34' AND kelumur_kode = '3'"));
					echo $rows_one['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }, {
                name: '30-34',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '34' AND kelumur_kode = '4'"));
					echo $rows_one['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }, {
                name: '35-39',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '34' AND kelumur_kode = '5'"));
					echo $rows_one['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }, {
                name: '40-44',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '34' AND kelumur_kode = '6'"));
					echo $rows_one['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }, {
                name: '45+',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '34' AND kelumur_kode = '7'"));
					echo $rows_one['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }]
        });
    });
    
});
		</script>
   <div id="diagram-narkoba" style="min-width: 680px; height: 480px; margin: 1px auto"></div>
   
   
   <script type="text/javascript">
$(function () {
    var chart;
    $(document).ready(function() {
        chart = new Highcharts.Chart({
            chart: {
                renderTo: 'diagram-aids',
                type: 'column'
            },
            title: {
                text: 'Penderita AIDS'
            },
            subtitle: {
                text: 'Sistem Informasi Gender dan Anak Papua'
            },
            xAxis: {
                categories: [	
				<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
								echo $rows_tahun['tahun_name'].',';
				  } ?>
                ]
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Jumlah'
                }
            },
            legend: {
                layout: 'vertical',
                backgroundColor: '#FFFFFF',
                align: 'left',
                verticalAlign: 'top',
                x: 100,
                y: 70,
                floating: true,
                shadow: true
            },
            tooltip: {
                formatter: function() {
                    return ''+
                        this.x +': '+ this.y +' Orang';
                }
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0
                }
            },
                series: [{
                name: 'Laki-laki',
                data: [
				  <? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_laki=mysql_fetch_array(mysql_query("select sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '66'"));
					echo $rows_laki['data_laki'].'0,';								
		  
				  } ?>]
    
            }, {
                name: 'Perempuan',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_perem=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '66'"));
					echo $rows_perem['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }, {
                name: 'Tidak Diketahui',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_perem=mysql_fetch_array(mysql_query("select sum(data_nongender) AS data_nongender from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '66'"));
					echo $rows_perem['data_nongender'].'0,';								
		  
				  } ?>]
    
            }]
        });
    });
    
});
		</script>
  <div id="diagram-aids" style="min-width: 680px; height: 480px; margin: 0 auto"></div>
  
  
  <script type="text/javascript">
$(function () {
    var chart;
    $(document).ready(function() {
        chart = new Highcharts.Chart({
            chart: {
                renderTo: 'diagram-hiv',
                type: 'column'
            },
            title: {
                text: 'Penderita HIV'
            },
            subtitle: {
                text: 'Sistem Informasi Gender dan Anak Papua'
            },
            xAxis: {
                categories: [	
				<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
								echo $rows_tahun['tahun_name'].',';
				  } ?>
                ]
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Jumlah'
                }
            },
            legend: {
                layout: 'vertical',
                backgroundColor: '#FFFFFF',
                align: 'left',
                verticalAlign: 'top',
                x: 100,
                y: 70,
                floating: true,
                shadow: true
            },
            tooltip: {
                formatter: function() {
                    return ''+
                        this.x +': '+ this.y +' Orang';
                }
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0
                }
            },
                series: [{
                name: 'Laki-laki',
                data: [
				  <? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_laki=mysql_fetch_array(mysql_query("select sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '65'"));
					echo $rows_laki['data_laki'].'0,';								
		  
				  } ?>]
    
            }, {
                name: 'Perempuan',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_perem=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '65'"));
					echo $rows_perem['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }, {
                name: 'Tidak Diketahui',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_perem=mysql_fetch_array(mysql_query("select sum(data_nongender) AS data_nongender from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '65'"));
					echo $rows_perem['data_nongender'].'0,';								
		  
				  } ?>]
    
            }]
        });
    });
    
});
		</script>
  <div id="diagram-hiv" style="min-width: 680px; height: 480px; margin: 0 auto"></div>
   
   
<script src="../../js/modules/exporting.js"></script>
         
      
    
      
      
      
    <? break;  ?>
		
	<? case '4': ?>
       <script type="text/javascript">
$(function () {
    var chart;
    $(document).ready(function() {
        chart = new Highcharts.Chart({
            chart: {
                renderTo: 'diagram-apk',
                type: 'column'
            },
            title: {
                text: 'Angka Partisipasi Kasar (APK)'
            },
            subtitle: {
                text: 'Sistem Informasi Gender dan Anak Papua'
            },
            xAxis: {
                categories: [	
				<? 
				  $rs_tahun= mysql_query("select * from  tbl_jenjangpendidikan ORDER BY jenjangpendidikan_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
								echo $rows_tahun['jenjangpendidikan_name'].',';
				  } ?>
                ]
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Jumlah'
                }
            },
            legend: {
                layout: 'vertical',
                backgroundColor: '#FFFFFF',
                align: 'left',
                verticalAlign: 'top',
                x: 100,
                y: 70,
                floating: true,
                shadow: true
            },
            tooltip: {
                formatter: function() {
                    return ''+
                        this.x +': '+ this.y +' Orang';
                }
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0
                }
            },
                series: [{
                name: 'Laki-laki',
                data: [
				  <? 
				  $rs_tahun= mysql_query("select * from tbl_jenjangpendidikan ORDER BY jenjangpendidikan_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_laki=mysql_fetch_array(mysql_query("select sum(data_laki) AS data_laki from tbl_data WHERE jenjangpendidikan_kode = '".$rows_tahun['jenjangpendidikan_kode']."' AND tahun_kode = '".$_POST['tahun_sampai']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '3'"));
					echo $rows_laki['data_laki'].'0,';								
		  
				  } ?>]
    
            }, {
                name: 'Perempuan',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_perem=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE  jenjangpendidikan_kode = '".$rows_tahun['jenjangpendidikan_kode']."' AND tahun_kode = '".$_POST['tahun_sampai']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '3'"));
					echo $rows_perem['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }]
        });
    });
    
});
		</script>
        
        <div id="diagram-apk" style="min-width: 680px; height: 480px; margin: 1px auto"></div>
	<? break;  ?>
		
	<? case '5': ?>
      
     <script type="text/javascript">
$(function () {
    var chart;
    $(document).ready(function() {
        chart = new Highcharts.Chart({
            chart: {
                renderTo: 'diagram-tpak',
                type: 'column'
            },
            title: {
                text: 'Tingkat Partisipasi Angkatan Kerja (TPAK)'
            },
            subtitle: {
                text: 'Sistem Informasi Gender dan Anak Papua'
            },
            xAxis: {
                categories: [	
				<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
								echo $rows_tahun['tahun_name'].',';
				  } ?>
                ]
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Jumlah'
                }
            },
            legend: {
                layout: 'vertical',
                backgroundColor: '#FFFFFF',
                align: 'left',
                verticalAlign: 'top',
                x: 100,
                y: 70,
                floating: true,
                shadow: true
            },
            tooltip: {
                formatter: function() {
                    return ''+
                        this.x +': '+ this.y +' Orang';
                }
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0
                }
            },
                series: [{
                name: 'Laki-laki',
                data: [
				  <? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_laki=mysql_fetch_array(mysql_query("select sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '9'"));
					echo $rows_laki['data_laki'].'0,';								
		  
				  } ?>]
    
            }, {
                name: 'Perempuan',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_perem=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '9'"));
					echo $rows_perem['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }]
        });
    });
    
});
		</script>
   <div id="diagram-tpak" style="min-width: 680px; height: 480px; margin: 1px auto"></div>
    
    <script type="text/javascript">
$(function () {
    var chart;
    $(document).ready(function() {
        chart = new Highcharts.Chart({
            chart: {
                renderTo: 'diagram-puksp',
                type: 'column'
            },
            title: {
                text: 'Penduduk Usia Kerja Yang Bekerja Menurut Status Pekerjaan'
            },
            subtitle: {
                text: 'Sistem Informasi Gender dan Anak Papua'
            },
            xAxis: {
                categories: [	
				<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
								echo $rows_tahun['tahun_name'].',';
				  } ?>
                ]
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Jumlah'
                }
            },
            legend: {
                layout: 'vertical',
                backgroundColor: '#FFFFFF',
                align: 'left',
                verticalAlign: 'top',
                x: 100,
                y: 70,
                floating: true,
                shadow: true
            },
            tooltip: {
                formatter: function() {
                    return ''+
                        this.x +': '+ this.y +' Orang';
                }
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0
                }
            },
                series: [{
                name: 'Laki-laki',
                data: [
				  <? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_laki=mysql_fetch_array(mysql_query("select sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '10'"));
					echo $rows_laki['data_laki'].'0,';								
		  
				  } ?>]
    
            }, {
                name: 'Perempuan',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_perem=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '10'"));
					echo $rows_perem['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }]
        });
    });
    
});
		</script>
  <div id="diagram-puksp" style="min-width: 680px; height: 480px; margin: 1px auto"></div>
    
    <script type="text/javascript">
$(function () {
    var chart;
    $(document).ready(function() {
        chart = new Highcharts.Chart({
            chart: {
                renderTo: 'diagram-puk',
                type: 'column'
            },
            title: {
                text: 'Penduduk Usia Kerja'
            },
            subtitle: {
                text: 'Sistem Informasi Gender dan Anak Papua'
            },
            xAxis: {
                categories: [	
				<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
								echo $rows_tahun['tahun_name'].',';
				  } ?>
                ]
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Jumlah'
                }
            },
            legend: {
                layout: 'vertical',
                backgroundColor: '#FFFFFF',
                align: 'left',
                verticalAlign: 'top',
                x: 100,
                y: 70,
                floating: true,
                shadow: true
            },
            tooltip: {
                formatter: function() {
                    return ''+
                        this.x +': '+ this.y +' Orang';
                }
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0
                }
            },
                series: [{
                name: 'Laki-laki',
                data: [
				  <? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_laki=mysql_fetch_array(mysql_query("select sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '11'"));
					echo $rows_laki['data_laki'].'0,';								
		  
				  } ?>]
    
            }, {
                name: 'Perempuan',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_perem=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '11'"));
					echo $rows_perem['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }]
        });
    });
    
});
		</script>
  <div id="diagram-puk" style="min-width: 680px; height: 480px; margin: 1px auto"></div>
  
  
  <script type="text/javascript">
$(function () {
    var chart;
    $(document).ready(function() {
        chart = new Highcharts.Chart({
            chart: {
                renderTo: 'diagram-pfdi',
                type: 'column'
            },
            title: {
                text: 'Pekerja Formal dan Informal'
            },
            subtitle: {
                text: 'Sistem Informasi Gender dan Anak Papua'
            },
            xAxis: {
                categories: [	
				<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
								echo $rows_tahun['tahun_name'].',';
				  } ?>
                ]
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Jumlah'
                }
            },
            legend: {
                layout: 'vertical',
                backgroundColor: '#FFFFFF',
                align: 'left',
                verticalAlign: 'top',
                x: 100,
                y: 70,
                floating: true,
                shadow: true
            },
            tooltip: {
                formatter: function() {
                    return ''+
                        this.x +': '+ this.y +' Orang';
                }
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0
                }
            },
                series: [{
                name: 'Laki-laki',
                data: [
				  <? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_laki=mysql_fetch_array(mysql_query("select sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '12'"));
					echo $rows_laki['data_laki'].'0,';								
		  
				  } ?>]
    
            }, {
                name: 'Perempuan',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_perem=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '12'"));
					echo $rows_perem['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }]
        });
    });
    
});
		</script>
   <div id="diagram-pfdi" style="min-width: 680px; height: 480px; margin: 0 auto"></div>
   
   
   <script type="text/javascript">
$(function () {
    var chart;
    $(document).ready(function() {
        chart = new Highcharts.Chart({
            chart: {
                renderTo: 'diagram-tpt',
                type: 'column'
            },
            title: {
                text: 'Tingkat Pengangguran Terbuka ( TPT )'
            },
            subtitle: {
                text: 'Sistem Informasi Gender dan Anak Papua'
            },
            xAxis: {
                categories: [	
				<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
								echo $rows_tahun['tahun_name'].',';
				  } ?>
                ]
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Jumlah'
                }
            },
            legend: {
                layout: 'vertical',
                backgroundColor: '#FFFFFF',
                align: 'left',
                verticalAlign: 'top',
                x: 100,
                y: 70,
                floating: true,
                shadow: true
            },
            tooltip: {
                formatter: function() {
                    return ''+
                        this.x +': '+ this.y +' Orang';
                }
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0
                }
            },
                series: [{
                name: 'Laki-laki',
                data: [
				  <? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_laki=mysql_fetch_array(mysql_query("select sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '13'"));
					echo $rows_laki['data_laki'].'0,';								
		  
				  } ?>]
    
            }, {
                name: 'Perempuan',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_perem=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '13'"));
					echo $rows_perem['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }]
        });
    });
    
});
		</script>
   <div id="diagram-tpt" style="min-width: 680px; height: 480px; margin: 1px auto"></div>
   
   
   <script type="text/javascript">
$(function () {
    var chart;
    $(document).ready(function() {
        chart = new Highcharts.Chart({
            chart: {
                renderTo: 'diagram-sp',
                type: 'column'
            },
            title: {
                text: 'Setengah Pengangguran'
            },
            subtitle: {
                text: 'Sistem Informasi Gender dan Anak Papua'
            },
            xAxis: {
                categories: [	
				<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
								echo $rows_tahun['tahun_name'].',';
				  } ?>
                ]
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Jumlah'
                }
            },
            legend: {
                layout: 'vertical',
                backgroundColor: '#FFFFFF',
                align: 'left',
                verticalAlign: 'top',
                x: 100,
                y: 70,
                floating: true,
                shadow: true
            },
            tooltip: {
                formatter: function() {
                    return ''+
                        this.x +': '+ this.y +' Orang';
                }
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0
                }
            },
                series: [{
                name: 'Laki-laki',
                data: [
				  <? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_laki=mysql_fetch_array(mysql_query("select sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '14'"));
					echo $rows_laki['data_laki'].'0,';								
		  
				  } ?>]
    
            }, {
                name: 'Perempuan',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_perem=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '14'"));
					echo $rows_perem['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }]
        });
    });
    
});
		</script>
   <div id="diagram-sp" style="min-width: 680px; height: 480px; margin: 1px auto"></div>
  
    
      
      <? break;  ?>
		
	  <? case '7': ?>

      <? break;  ?>
		
	  <? case '6': ?>
      
      <table class="ctable-skpd" style="width: 100%;">
   <tr class="isi">
    <td style="width: 100%; font-size: 20px; text-align:left; font-weight:bold;">BIDANG POLITIK DAN PENGAMBILAN KEPUTUSAN</td>
	</tr>
    </table>
     <script type="text/javascript">
$(function () {
    var chart;
    $(document).ready(function() {
        chart = new Highcharts.Chart({
            chart: {
                renderTo: 'diagram-legeslatif',
                type: 'column'
            },
            title: {
                text: 'Legislatif'
            },
            subtitle: {
                text: 'Sistem Informasi Gender dan Anak Papua'
            },
            xAxis: {
                categories: [	
				<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
								echo $rows_tahun['tahun_name'].',';
				  } ?>
                ]
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Jumlah'
                }
            },
            legend: {
                layout: 'vertical',
                backgroundColor: '#FFFFFF',
                align: 'left',
                verticalAlign: 'top',
                x: 100,
                y: 70,
                floating: true,
                shadow: true
            },
            tooltip: {
                formatter: function() {
                    return ''+
                        this.x +': '+ this.y +' Orang';
                }
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0
                }
            },
                series: [{
                name: 'Laki-laki',
                data: [
				  <? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_laki=mysql_fetch_array(mysql_query("select sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '15'"));
					echo $rows_laki['data_laki'].'0,';								
		  
				  } ?>]
    
            }, {
                name: 'Perempuan',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_perem=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '15'"));
					echo $rows_perem['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }]
        });
    });
    
});
		</script>
   <div id="diagram-legeslatif" style="min-width: 680px; height: 480px; margin: 1px auto"></div>
      
      
      
      
      <script type="text/javascript">
$(function () {
    var chart;
    $(document).ready(function() {
        chart = new Highcharts.Chart({
            chart: {
                renderTo: 'diagram-camat',
                type: 'column'
            },
            title: {
                text: 'camat'
            },
            subtitle: {
                text: 'Sistem Informasi Gender dan Anak Papua'
            },
            xAxis: {
                categories: [	
				<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
								echo $rows_tahun['tahun_name'].',';
				  } ?>
                ]
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Jumlah'
                }
            },
            legend: {
                layout: 'vertical',
                backgroundColor: '#FFFFFF',
                align: 'left',
                verticalAlign: 'top',
                x: 100,
                y: 70,
                floating: true,
                shadow: true
            },
            tooltip: {
                formatter: function() {
                    return ''+
                        this.x +': '+ this.y +' Orang';
                }
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0
                }
            },
                series: [{
                name: 'Laki-laki',
                data: [
				  <? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_laki=mysql_fetch_array(mysql_query("select sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '18'"));
					echo $rows_laki['data_laki'].'0,';								
		  
				  } ?>]
    
            }, {
                name: 'Perempuan',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_perem=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '18'"));
					echo $rows_perem['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }]
        });
    });
    
});
		</script>
   <div id="diagram-camat" style="min-width: 680px; height: 480px; margin: 1px auto"></div>
   
   
   <script type="text/javascript">
$(function () {
    var chart;
    $(document).ready(function() {
        chart = new Highcharts.Chart({
            chart: {
                renderTo: 'diagram-lurah',
                type: 'column'
            },
            title: {
                text: 'lurah'
            },
            subtitle: {
                text: 'Sistem Informasi Gender dan Anak Papua'
            },
            xAxis: {
                categories: [	
				<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
								echo $rows_tahun['tahun_name'].',';
				  } ?>
                ]
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Jumlah'
                }
            },
            legend: {
                layout: 'vertical',
                backgroundColor: '#FFFFFF',
                align: 'left',
                verticalAlign: 'top',
                x: 100,
                y: 70,
                floating: true,
                shadow: true
            },
            tooltip: {
                formatter: function() {
                    return ''+
                        this.x +': '+ this.y +' Orang';
                }
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0
                }
            },
                series: [{
                name: 'Laki-laki',
                data: [
				  <? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_laki=mysql_fetch_array(mysql_query("select sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '19'"));
					echo $rows_laki['data_laki'].'0,';								
		  
				  } ?>]
    
            }, {
                name: 'Perempuan',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_perem=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '19'"));
					echo $rows_perem['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }]
        });
    });
    
});
		</script>
   <div id="diagram-lurah" style="min-width: 680px; height: 480px; margin: 1px auto"></div>
   
   
     <script type="text/javascript">
$(function () {
    var chart;
    $(document).ready(function() {
        chart = new Highcharts.Chart({
            chart: {
                renderTo: 'diagram-kk',
                type: 'column'
            },
            title: {
                text: 'Kepala Kampung'
            },
            subtitle: {
                text: 'Sistem Informasi Gender dan Anak Papua'
            },
            xAxis: {
                categories: [	
				<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
								echo $rows_tahun['tahun_name'].',';
				  } ?>
                ]
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Jumlah'
                }
            },
            legend: {
                layout: 'vertical',
                backgroundColor: '#FFFFFF',
                align: 'left',
                verticalAlign: 'top',
                x: 100,
                y: 70,
                floating: true,
                shadow: true
            },
            tooltip: {
                formatter: function() {
                    return ''+
                        this.x +': '+ this.y +' Orang';
                }
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0
                }
            },
                series: [{
                name: 'Laki-laki',
                data: [
				  <? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_laki=mysql_fetch_array(mysql_query("select sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '20'"));
					echo $rows_laki['data_laki'].'0,';								
		  
				  } ?>]
    
            }, {
                name: 'Perempuan',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_perem=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."'  AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '20'"));
					echo $rows_perem['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }]
        });
    });
    
});
		</script>
   <div id="diagram-kk" style="min-width: 680px; height: 480px; margin: 1px auto"></div>
      
      

      <? break;  ?>
		
	  <? case '8': ?>
      
      <? break;  ?>
      <?
      default:

	}
}