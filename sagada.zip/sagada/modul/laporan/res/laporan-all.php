<?php

require_once '../../library/connectionmysql.php';
Connected();
$rs_tahunsampai= mysql_query("select * from tbl_tahun WHERE tahun_kode = '".$_POST['tahun_sampai']."'");
$rows_tahunsampai=mysql_fetch_array($rs_tahunsampai);


$rs_kotas= mysql_query("select * from tbl_kota WHERE kota_kode  = '".$_POST['kota_kode']."'");
$rows_kotas=mysql_fetch_array($rs_kotas);
?>

	<table cellspacing="0" style="width: 100%; font-size: 15px; padding:15px 25px 15px 25px;">
		<tr>
			<td style="width: 15%; color: #444444; float:left;" rowspan="3"><img style="height:60px;" src="./../../images/logo.png" alt="Logo"></td>
            <td style="width: 70%; color: #444444; text-align:center; font:'Times New Roman', Times, serif; font-size:22px; font-weight:bold;">SEKRETARIAT DAERAH PROVINSI PAPUA</td>
            <td style="width: 15%; color: #444444; float:left;"></td>
        </tr>
        <tr>
            <td style="width: 70%; color: #444444; text-align:center; font:'Times New Roman', Times, serif; font-size:18px; font-weight:bold;">BIRO PEMBERDAYAAN PEREMPUAN</td>
            <td style="width: 15%; color: #444444; float:left;"></td>
        </tr>
         <tr>
            <td style="width: 70%; color: #444444; text-align:center; font:'Times New Roman', Times, serif; font-size:12px; font-weight:bold;">Alamat : Kantor Gubernur Jl. Soa Siu Dok II Jayapura</td>
            <td style="width: 15%; color: #444444; float:left;"></td>
        </tr>
        <tr style="margin-top:10px;">
			<td style="width: 100%; color: #444444; text-align:right; border-bottom:thin;" colspan="3"></td>
        </tr>
    </table>
    <table cellspacing="0" style="width: 100%; padding:0 25px 0 25px;">
    <tr>
	<td style="width: 2%; font-size: 12px; height:14px;">I.</td>
    <td style="width: 98%; font-size: 12px;">Bidang Kesehatan</td>
	</tr>
    </table>
    <table cellspacing="0" style="width: 100%; padding:0 25px 2px 25px;">
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Tabel 1</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Angka Harapan Hidup</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Kota/Kabupaten : <? echo$rows_kotas['kota_name'] ?>, Tahun : <? echo $rows_tahunsampai['tahun_name'] ?></td>
	</tr>
    </table>
    
    <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; padding:0 0 0 0;" align="center">
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 3%; height:12px;">No</td>
		<td style="width: 20%; height:12px;">Tahun</td>
		<td style="width: 20%;">Laki-laki</td>
        <td style="width: 20%;">Perempuan</td>
        <td style="width: 20%;">Jumlah</td>
	  </tr>
      <? 
	  $rs_tahun= mysql_query("select * from tbl_tahun WHERE tahun_kode <= '".$_POST['tahun_sampai']."'");
	  $no = 1;
	  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
		  $rows_laki=mysql_fetch_array(mysql_query("select sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."' AND submenu_kode = '28'"));
		  $rows_laki=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '28'"));
	  ?>
      <tr style="text-align:center; font-size:12px;">
      <td style="width: 3%; height:12px;"><? echo $no ?></td>
		<td style="width: 20%; height:12px;"><? echo $rows_tahun['tahun_name'] ?></td>
		<td style="width: 20%;"><? echo cFormat($rows_laki['data_laki'], false) ?></td>
        <td style="width: 20%;"><? echo cFormat($rows_laki['data_perempuan'], false) ?></td>
        <td style="width: 20%;"><? echo cFormat($rows_laki['data_laki']+$rows_laki['data_perempuan'], false) ?></td>
	  </tr>
      
      <? $no++; } ?>
      
      
      </table>
         
        <table cellspacing="0" style="width: 100%; padding:25px 25px 2px 25px;">
        <tr>
        <td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Tabel 2</td>
        </tr>
        <tr>
        <td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Jumlah Kematian Ibu Melahirkan</td>
        </tr>
        <tr>
        <td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Kota/Kabupaten : <? echo$rows_kotas['kota_name'] ?>, Tahun : <? echo $rows_tahunsampai['tahun_name'] ?></td>
        </tr>
        </table>
      <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; padding:0 0 0 0;" align="center">
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 3%; height:12px;" rowspan="2">No</td>
		<td style="width: 10%; height:12px;" rowspan="2">Tahun</td>
		<td style="width: 70%;"  colspan="7">Kelompok Umur (Tahun)</td>
        <td style="width: 10%;" rowspan="2">Jumlah</td>
	  </tr>
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 10%; height:12px;">15-19</td>
		<td style="width: 10%; height:12px;">20-24</td>
		<td style="width: 10%; height:12px;">25-29</td>
        <td style="width: 10%; height:12px;">30-34</td>
		<td style="width: 10%; height:12px;">35-39</td>
        <td style="width: 10%; height:12px;">40-44</td>
        <td style="width: 10%; height:12px;">45+</td>
	  </tr>
      <? 
	  $rs_tahun= mysql_query("select * from tbl_tahun WHERE tahun_kode <= '".$_POST['tahun_sampai']."'");
	  $no = 1;
	  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
		  $rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '29' AND kelumur_kode = '1'"));
		  $rows_two=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '29' AND kelumur_kode = '2'"));
		  $rows_three=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '29' AND kelumur_kode = '3'"));
		  $rows_four=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '29' AND kelumur_kode = '4'"));
		  $rows_limo=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '29' AND kelumur_kode = '5'"));
		  $rows_enem=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '29' AND kelumur_kode = '6'"));
		  $rows_pitu=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '29' AND kelumur_kode = '7'"));
		  
	  ?>
      <tr style="text-align:center; font-size:12px;">
      <td style="width: 3%; height:12px;"><? echo $no ?></td>
		<td style="width: 10%; height:12px;"><? echo $rows_tahun['tahun_name'] ?></td>
		<td style="width: 10%;"><? echo cFormat($rows_one['data_perempuan'], false) ?></td>
        <td style="width: 10%;"><? echo cFormat($rows_two['data_perempuan'], false) ?></td>
		<td style="width: 10%;"><? echo cFormat($rows_three['data_perempuan'], false) ?></td>
		<td style="width: 10%;"><? echo cFormat($rows_four['data_perempuan'], false) ?></td>
		<td style="width: 10%;"><? echo cFormat($rows_limo['data_perempuan'], false) ?></td>
		<td style="width: 10%;"><? echo cFormat($rows_enem['data_perempuan'], false) ?></td>
        <td style="width: 10%;"><? echo cFormat($rows_pitu['data_perempuan'], false) ?></td>
        <td style="width: 10%;"><? echo cFormat($rows_one['data_perempuan']+$rows_two['data_perempuan']+$rows_three['data_perempuan']+$rows_four['data_perempuan']+$rows_limo['data_perempuan']+$rows_enem['data_perempuan']+$rows_pitu['data_perempuan'], false) ?></td>
	  </tr>
      
      <? $no++; } ?>
      
      
      </table>
      
       <table cellspacing="0" style="width: 100%; padding:25px 25px 2px 25px;">
        <tr>
        <td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Tabel 3</td>
        </tr>
        <tr>
        <td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Imunisasi TT pada Ibu Hamil</td>
        </tr>
        <tr>
        <td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Kota/Kabupaten : <? echo$rows_kotas['kota_name'] ?>, Tahun : <? echo $rows_tahunsampai['tahun_name'] ?></td>
        </tr>
        </table>
      <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; padding:0 0 0 0;" align="center">
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 3%; height:12px;" rowspan="2">No</td>
		<td style="width: 10%; height:12px;" rowspan="2">Tahun</td>
		<td style="width: 70%;"  colspan="7">Kelompok Umur (Tahun)</td>
        <td style="width: 10%;" rowspan="2">Jumlah</td>
	  </tr>
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 10%; height:12px;">15-19</td>
		<td style="width: 10%; height:12px;">20-24</td>
		<td style="width: 10%; height:12px;">25-29</td>
        <td style="width: 10%; height:12px;">30-34</td>
		<td style="width: 10%; height:12px;">35-39</td>
        <td style="width: 10%; height:12px;">40-44</td>
        <td style="width: 10%; height:12px;">45+</td>
	  </tr>
      <? 
	  $rs_tahun= mysql_query("select * from tbl_tahun WHERE tahun_kode <= '".$_POST['tahun_sampai']."'");
	  $no = 1;
	  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
		  $rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '30' AND kelumur_kode = '1'"));
		  $rows_two=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '30' AND kelumur_kode = '2'"));
		  $rows_three=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '30' AND kelumur_kode = '3'"));
		  $rows_four=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '30' AND kelumur_kode = '4'"));
		  $rows_limo=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '30' AND kelumur_kode = '5'"));
		  $rows_enem=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '30' AND kelumur_kode = '6'"));
		  $rows_pitu=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '30' AND kelumur_kode = '7'"));
		  
	  ?>
      <tr style="text-align:center; font-size:12px;">
      <td style="width: 3%; height:12px;"><? echo $no ?></td>
		<td style="width: 10%; height:12px;"><? echo $rows_tahun['tahun_name'] ?></td>
		<td style="width: 10%;"><? echo cFormat($rows_one['data_perempuan'], false) ?></td>
        <td style="width: 10%;"><? echo cFormat($rows_two['data_perempuan'], false) ?></td>
		<td style="width: 10%;"><? echo cFormat($rows_three['data_perempuan'], false) ?></td>
		<td style="width: 10%;"><? echo cFormat($rows_four['data_perempuan'], false) ?></td>
		<td style="width: 10%;"><? echo cFormat($rows_limo['data_perempuan'], false) ?></td>
		<td style="width: 10%;"><? echo cFormat($rows_enem['data_perempuan'], false) ?></td>
        <td style="width: 10%;"><? echo cFormat($rows_pitu['data_perempuan'], false) ?></td>
        <td style="width: 10%;"><? echo cFormat($rows_one['data_perempuan']+$rows_two['data_perempuan']+$rows_three['data_perempuan']+$rows_four['data_perempuan']+$rows_limo['data_perempuan']+$rows_enem['data_perempuan']+$rows_pitu['data_perempuan'], false) ?></td>
	  </tr>
      
      <? $no++; } ?>
      
      
      </table>
      
      
      <table cellspacing="0" style="width: 100%; padding:25px 25px 2px 25px;">
        <tr>
        <td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Tabel 4</td>
        </tr>
        <tr>
        <td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Ibu Hamil yang mendapatkan tablet Zat Besi (Fe)</td>
        </tr>
        <tr>
        <td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Kota/Kabupaten : <? echo$rows_kotas['kota_name'] ?>, Tahun : <? echo $rows_tahunsampai['tahun_name'] ?></td>
        </tr>
        </table>
      <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; padding:0 0 0 0;" align="center">
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 3%; height:12px;" rowspan="2">No</td>
		<td style="width: 10%; height:12px;" rowspan="2">Tahun</td>
		<td style="width: 70%;"  colspan="7">Kelompok Umur (Tahun)</td>
        <td style="width: 10%;" rowspan="2">Jumlah</td>
	  </tr>
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 10%; height:12px;">15-19</td>
		<td style="width: 10%; height:12px;">20-24</td>
		<td style="width: 10%; height:12px;">25-29</td>
        <td style="width: 10%; height:12px;">30-34</td>
		<td style="width: 10%; height:12px;">35-39</td>
        <td style="width: 10%; height:12px;">40-44</td>
        <td style="width: 10%; height:12px;">45+</td>
	  </tr>
      <? 
	  $rs_tahun= mysql_query("select * from tbl_tahun WHERE tahun_kode <= '".$_POST['tahun_sampai']."'");
	  $no = 1;
	  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
		  $rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '31' AND kelumur_kode = '1'"));
		  $rows_two=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '31' AND kelumur_kode = '2'"));
		  $rows_three=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '31' AND kelumur_kode = '3'"));
		  $rows_four=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '31' AND kelumur_kode = '4'"));
		  $rows_limo=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '31' AND kelumur_kode = '5'"));
		  $rows_enem=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '31' AND kelumur_kode = '6'"));
		  $rows_pitu=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '31' AND kelumur_kode = '7'"));
		  
	  ?>
      <tr style="text-align:center; font-size:12px;">
      <td style="width: 3%; height:12px;"><? echo $no ?></td>
		<td style="width: 10%; height:12px;"><? echo $rows_tahun['tahun_name'] ?></td>
		<td style="width: 10%;"><? echo cFormat($rows_one['data_perempuan'], false) ?></td>
        <td style="width: 10%;"><? echo cFormat($rows_two['data_perempuan'], false) ?></td>
		<td style="width: 10%;"><? echo cFormat($rows_three['data_perempuan'], false) ?></td>
		<td style="width: 10%;"><? echo cFormat($rows_four['data_perempuan'], false) ?></td>
		<td style="width: 10%;"><? echo cFormat($rows_limo['data_perempuan'], false) ?></td>
		<td style="width: 10%;"><? echo cFormat($rows_enem['data_perempuan'], false) ?></td>
        <td style="width: 10%;"><? echo cFormat($rows_pitu['data_perempuan'], false) ?></td>
        <td style="width: 10%;"><? echo cFormat($rows_one['data_perempuan']+$rows_two['data_perempuan']+$rows_three['data_perempuan']+$rows_four['data_perempuan']+$rows_limo['data_perempuan']+$rows_enem['data_perempuan']+$rows_pitu['data_perempuan'], false) ?></td>
	  </tr>
      <? $no++; } ?>
      </table>
      
    
    
      
      
      <table cellspacing="0" style="width: 100%; padding:25px 25px 2px 25px;">
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Tabel 5</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Keluarga Berencana</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Kota/Kabupaten : <? echo$rows_kotas['kota_name'] ?>, Tahun : <? echo $rows_tahunsampai['tahun_name'] ?></td>
	</tr>
    </table>
    
    <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; padding:0 0 0 0;" align="center">
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 3%; height:12px;">No</td>
		<td style="width: 10%;">Tahun</td>
        <td style="width: 30%;">Uraian / Keterangan</td>
        <td style="width: 15%;">Jumlah</td>
	  </tr>
      <? 
	  $rs_tahun= mysql_query("select * from tbl_tahun WHERE tahun_kode <= '".$_POST['tahun_sampai']."'");
	  $no = 1;
	  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
		 
		  $rows_laki=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, kontrasepsi_kode from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '33'"));
		  
		  $rows_alat=mysql_fetch_array(mysql_query("select * from tbl_kontrasepsi WHERE kontrasepsi_kode = '".$rows_laki['kontrasepsi_kode']."'"));
		  
		  
	  ?>
      <tr style="text-align:center; font-size:12px;">
      <td style="width: 3%; height:12px;"><? echo $no ?></td>
		<td style="width: 10%; height:12px;"><? echo $rows_tahun['tahun_name'] ?></td>
		
      	<td style="width: 30%;"><? echo $rows_alat['kontrasepsi_name'] ?></td>
        <td style="width: 15%;"><? echo cFormat($rows_laki['data_perempuan'], false) ?></td>
	  </tr>
      
      <? $no++; } ?>
      
      
      </table>
      
      
      
      
       <table cellspacing="0" style="width: 100%; padding:25px 25px 2px 25px;">
        <tr>
        <td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Tabel 6</td>
        </tr>
        <tr>
        <td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Narkoba</td>
        </tr>
        <tr>
        <td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Kota/Kabupaten : <? echo$rows_kotas['kota_name'] ?>, Tahun : <? echo $rows_tahunsampai['tahun_name'] ?></td>
        </tr>
        </table>
      <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; padding:0 0 0 0;" align="center">
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 3%; height:12px;" rowspan="2">No</td>
		<td style="width: 10%; height:12px;" rowspan="2">Tahun</td>
		<td style="width: 70%;"  colspan="7">Kelompok Umur (Tahun)</td>
        <td style="width: 10%;" rowspan="2">Jumlah</td>
	  </tr>
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 10%; height:12px;">15-19</td>
		<td style="width: 10%; height:12px;">20-24</td>
		<td style="width: 10%; height:12px;">25-29</td>
        <td style="width: 10%; height:12px;">30-34</td>
		<td style="width: 10%; height:12px;">35-39</td>
        <td style="width: 10%; height:12px;">40-44</td>
        <td style="width: 10%; height:12px;">45+</td>
	  </tr>
      <? 
	  $rs_tahun= mysql_query("select * from tbl_tahun WHERE tahun_kode <= '".$_POST['tahun_sampai']."'");
	  $no = 1;
	  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
		  $rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '34' AND kelumur_kode = '1'"));
		  $rows_two=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '34' AND kelumur_kode = '2'"));
		  $rows_three=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '34' AND kelumur_kode = '3'"));
		  $rows_four=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '34' AND kelumur_kode = '4'"));
		  $rows_limo=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '34' AND kelumur_kode = '5'"));
		  $rows_enem=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '34' AND kelumur_kode = '6'"));
		  $rows_pitu=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '34' AND kelumur_kode = '7'"));
		  
	  ?>
      <tr style="text-align:center; font-size:12px;">
      <td style="width: 3%; height:12px;"><? echo $no ?></td>
		<td style="width: 10%; height:12px;"><? echo $rows_tahun['tahun_name'] ?></td>
		<td style="width: 10%;"><? echo cFormat($rows_one['data_perempuan'] + $rows_one['data_laki'], false) ?></td>
        <td style="width: 10%;"><? echo cFormat($rows_two['data_perempuan'] + $rows_two['data_laki'], false) ?></td>
		<td style="width: 10%;"><? echo cFormat($rows_three['data_perempuan'] + $rows_three['data_laki'], false) ?></td>
		<td style="width: 10%;"><? echo cFormat($rows_four['data_perempuan'] + $rows_four['data_laki'], false) ?></td>
		<td style="width: 10%;"><? echo cFormat($rows_limo['data_perempuan'] + $rows_limo['data_laki'], false) ?></td>
		<td style="width: 10%;"><? echo cFormat($rows_enem['data_perempuan'] + $rows_enem['data_laki'], false) ?></td>
        <td style="width: 10%;"><? echo cFormat($rows_pitu['data_perempuan'] + $rows_pitu['data_laki'], false) ?></td>
        <td style="width: 10%;"><? echo cFormat($rows_one['data_perempuan'] + $rows_two['data_perempuan']+$rows_three['data_perempuan']+$rows_four['data_perempuan']+$rows_limo['data_perempuan']+$rows_enem['data_perempuan']+$rows_pitu['data_perempuan'] + $rows_one['data_laki'] + $rows_two['data_laki']+$rows_three['data_laki']+$rows_four['data_laki']+$rows_limo['data_laki']+$rows_enem['data_laki']+$rows_pitu['data_laki'], false) ?></td>
	  </tr>
      <? $no++; } ?>
      </table>
      
      <table cellspacing="0" style="width: 100%; padding:25px 25px 2px 25px;">
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Tabel 7</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Penderita HIV</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Kota/Kabupaten : <? echo$rows_kotas['kota_name'] ?>, Tahun : <? echo $rows_tahunsampai['tahun_name'] ?></td>
	</tr>
    </table>
    
    <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; padding:0 0 0 0;" align="center">
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 3%; height:12px;">No</td>
		<td style="width: 10%;">Tahun</td>
        <td style="width: 25%;">Uraian / Keterangan</td>
		<td style="width: 10%;">Laki-laki</td>
        <td style="width: 10%;">Perempuan</td>
        <td style="width: 10%;">Tidak Diketahui (L/P)</td>
        <td style="width: 15%;">Jumlah</td>
	  </tr>
      <? 
	  $rs_tahun= mysql_query("select * from tbl_tahun WHERE tahun_kode <= '".$_POST['tahun_sampai']."'");
	  $no = 1;
	  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
		  $rows_laki=mysql_fetch_array(mysql_query("select sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '65'"));
		  $rows_perempuan=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '65'"));
		  $rows_nogender=mysql_fetch_array(mysql_query("select sum(data_nongender) AS data_nongender from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '65'"));
	  ?>
      <tr style="text-align:center; font-size:12px;">
      <td style="width: 3%; height:12px;"><? echo $no ?></td>
		<td style="width: 10%; height:12px;"><? echo $rows_tahun['tahun_name'] ?></td>
		<td style="width: 25%;">Penderita HIV</td>
         <td style="width: 10%;"><? echo cFormat($rows_laki['data_laki'], false) ?></td>
        <td style="width: 10%;"><? echo cFormat($rows_perempuan['data_perempuan'], false) ?></td>
         <td style="width: 10%;"><? echo cFormat($rows_nogender['data_nongender'], false) ?></td>
        <td style="width: 15%;"><? echo cFormat($rows_laki['data_laki']+$rows_perempuan['data_perempuan']+$rows_nogender['data_nongender'], false) ?></td>
	  </tr>
      
      <? $no++; } ?>
      
      
      </table>
      <table cellspacing="0" style="width: 100%; padding:25px 25px 2px 25px;">
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Tabel 8</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Penderita AIDS</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Kota/Kabupaten : <? echo$rows_kotas['kota_name'] ?>, Tahun : <? echo $rows_tahunsampai['tahun_name'] ?></td>
	</tr>
    </table>
    
    <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; padding:0 0 0 0;" align="center">
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 3%; height:12px;">No</td>
		<td style="width: 10%;">Tahun</td>
        <td style="width: 25%;">Uraian / Keterangan</td>
		<td style="width: 10%;">Laki-laki</td>
        <td style="width: 10%;">Perempuan</td>
        <td style="width: 10%;">Tidak Diketahui (L/P)</td>
        <td style="width: 15%;">Jumlah</td>
	  </tr>
      <? 
	  $rs_tahun= mysql_query("select * from tbl_tahun WHERE tahun_kode <= '".$_POST['tahun_sampai']."'");
	  $no = 1;
	  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
		  $rows_laki=mysql_fetch_array(mysql_query("select sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '66'"));
		  $rows_perempuan=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '66'"));
		  $rows_nogender=mysql_fetch_array(mysql_query("select sum(data_nongender) AS data_nongender from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '66'"));
	  ?>
      <tr style="text-align:center; font-size:12px;">
      <td style="width: 3%; height:12px;"><? echo $no ?></td>
		<td style="width: 10%; height:12px;"><? echo $rows_tahun['tahun_name'] ?></td>
		<td style="width: 25%;">Penderita Aids</td>
         <td style="width: 10%;"><? echo cFormat($rows_laki['data_laki'], false) ?></td>
        <td style="width: 10%;"><? echo cFormat($rows_perempuan['data_perempuan'], false) ?></td>
         <td style="width: 10%;"><? echo cFormat($rows_nogender['data_nongender'], false) ?></td>
        <td style="width: 15%;"><? echo cFormat($rows_laki['data_laki']+$rows_perempuan['data_perempuan']+$rows_nogender['data_nongender'], false) ?></td>
	  </tr>
      
      <? $no++; } ?>
      
      
      </table>
      
      
      
    
      <table cellspacing="0" style="width: 100%; padding:35px 25px 0 25px;">
    <tr>
	<td style="width: 2%; font-size: 12px; height:14px;">II.</td>
    <td style="width: 98%; font-size: 12px;">Bidang Pendidikan</td>
	</tr>
    </table>
    <table cellspacing="0" style="width: 100%; padding:25px 25px 2px 25px;">
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Tabel 1</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Angka Partisipasi Kasar (APK)</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Kota/Kabupaten : <? echo$rows_kotas['kota_name'] ?>, Tahun : <? echo $rows_tahunsampai['tahun_name'] ?></td>
	</tr>
    </table>
    <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; padding:0 0 0 0;" align="center">
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 3%; height:12px;" rowspan="2">No</td>
		<td style="width: 8%; height:12px;" rowspan="2">Tahun</td>
		<td style="width: 18%;"  colspan="2">SD</td>
        <td style="width: 18%;"  colspan="2">SMP</td>
        <td style="width: 18%;"  colspan="2">SMA</td>
        <td style="width: 18%;"  colspan="2">SARJANA</td>
        <td style="width: 10%;" rowspan="2">Jumlah</td>
	  </tr>
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 9%; height:12px;">L</td>
		<td style="width: 9%; height:12px;">P</td>
		<td style="width: 9%; height:12px;">L</td>
		<td style="width: 9%; height:12px;">P</td>
        <td style="width: 9%; height:12px;">L</td>
		<td style="width: 9%; height:12px;">P</td>
        <td style="width: 9%; height:12px;">L</td>
		<td style="width: 9%; height:12px;">P</td>
	  </tr>
      <? 
	  $rs_tahun= mysql_query("select * from tbl_tahun WHERE tahun_kode <= '".$_POST['tahun_sampai']."'");
	  $no = 1;
	  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
		  $rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '3' AND jenjangpendidikan_kode = '1'"));
		  $rows_two=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '3' AND jenjangpendidikan_kode = '2'"));
		  $rows_three=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '3' AND jenjangpendidikan_kode = '3'"));
		  $rows_four=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '3' AND jenjangpendidikan_kode = '4'"));
	
		  
	  ?>
      <tr style="text-align:center; font-size:12px;">
      <td style="width: 3%; height:12px;"><? echo $no ?></td>
		<td style="width: 10%; height:12px;"><? echo $rows_tahun['tahun_name'] ?></td>
		<td style="width: 9%;"><? echo cFormat($rows_one['data_laki'], false) ?></td>
        <td style="width: 9%;"><? echo cFormat($rows_one['data_perempuan'], false) ?></td>
        <td style="width: 9%;"><? echo cFormat($rows_two['data_laki'], false) ?></td>
        <td style="width: 9%;"><? echo cFormat($rows_two['data_perempuan'], false) ?></td>
        <td style="width: 9%;"><? echo cFormat($rows_three['data_laki'], false) ?></td>
        <td style="width: 9%;"><? echo cFormat($rows_three['data_perempuan'], false) ?></td>
        <td style="width: 9%;"><? echo cFormat($rows_four['data_laki'], false) ?></td>
        <td style="width: 9%;"><? echo cFormat($rows_four['data_perempuan'], false) ?></td>
       
        <td style="width: 10%;"><? echo cFormat($rows_one['data_perempuan'] + $rows_two['data_perempuan']+$rows_three['data_perempuan']+$rows_four['data_perempuan']+ $rows_one['data_laki'] + $rows_two['data_laki']+$rows_three['data_laki']+$rows_four['data_laki'], false) ?></td>
	  </tr>
      <? $no++; } ?>
      </table>
      <table cellspacing="0" style="width: 100%; padding:25px 25px 2px 25px;">
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Tabel 2</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Angka Partisipasi Sekolah (APS)</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Kota/Kabupaten : <? echo$rows_kotas['kota_name'] ?>, Tahun : <? echo $rows_tahunsampai['tahun_name'] ?></td>
	</tr>
    </table>
    <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; padding:0 0 0 0;" align="center">
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 3%; height:12px;" rowspan="3">No</td>
		<td style="width: 8%; height:12px;" rowspan="3">Tahun</td>
		<td style="width: 72%;"  colspan="8">Kelompok Umur</td>
        <td style="width: 10%;" rowspan="3">Jumlah</td>
	  </tr>
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 18%; height:12px;" colspan="2">6-12</td>
		<td style="width: 18%; height:12px;" colspan="2">13-15</td>
		<td style="width: 18%; height:12px;" colspan="2">16-18</td>
		<td style="width: 18%; height:12px;" colspan="2">19+</td>
        
	  </tr>
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 9%; height:12px;">L</td>
		<td style="width: 9%; height:12px;">P</td>
		<td style="width: 9%; height:12px;">L</td>
		<td style="width: 9%; height:12px;">P</td>
        <td style="width: 9%; height:12px;">L</td>
		<td style="width: 9%; height:12px;">P</td>
        <td style="width: 9%; height:12px;">L</td>
		<td style="width: 9%; height:12px;">P</td>
        
	  </tr>
      <? 
	  $rs_tahun= mysql_query("select * from tbl_tahun WHERE tahun_kode <= '".$_POST['tahun_sampai']."'");
	  $no = 1;
	  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
		  $rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '4' AND kelumur_kode = '8'"));
		  $rows_two=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '4' AND kelumur_kode = '9'"));
		  $rows_three=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '4' AND kelumur_kode = '10'"));
		  $rows_four=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '4' AND kelumur_kode = '11'"));
	
		  
	  ?>
      <tr style="text-align:center; font-size:12px;">
      <td style="width: 3%; height:12px;"><? echo $no ?></td>
		<td style="width: 10%; height:12px;"><? echo $rows_tahun['tahun_name'] ?></td>
		<td style="width: 9%;"><? echo cFormat($rows_one['data_laki'], false) ?></td>
        <td style="width: 9%;"><? echo cFormat($rows_one['data_perempuan'], false) ?></td>
        <td style="width: 9%;"><? echo cFormat($rows_two['data_laki'], false) ?></td>
        <td style="width: 9%;"><? echo cFormat($rows_two['data_perempuan'], false) ?></td>
        <td style="width: 9%;"><? echo cFormat($rows_three['data_laki'], false) ?></td>
        <td style="width: 9%;"><? echo cFormat($rows_three['data_perempuan'], false) ?></td>
        <td style="width: 9%;"><? echo cFormat($rows_four['data_laki'], false) ?></td>
        <td style="width: 9%;"><? echo cFormat($rows_four['data_perempuan'], false) ?></td>
       
        <td style="width: 10%;"><? echo cFormat($rows_one['data_perempuan'] + $rows_two['data_perempuan']+$rows_three['data_perempuan']+$rows_four['data_perempuan']+ $rows_one['data_laki'] + $rows_two['data_laki']+$rows_three['data_laki']+$rows_four['data_laki'], false) ?></td>
	  </tr>
      <? $no++; } ?>
      </table>
      <table cellspacing="0" style="width: 100%; padding:25px 25px 2px 25px;">
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Tabel 3</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Angka Partisipasi Murni ( APM )</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Kota/Kabupaten : <? echo$rows_kotas['kota_name'] ?>, Tahun : <? echo $rows_tahunsampai['tahun_name'] ?></td>
	</tr>
    </table>
    <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; padding:0 0 0 0;" align="center">
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 3%; height:12px;" rowspan="2">No</td>
		<td style="width: 8%; height:12px;" rowspan="2">Tahun</td>
		<td style="width: 18%;"  colspan="2">SD</td>
        <td style="width: 18%;"  colspan="2">SMP</td>
        <td style="width: 18%;"  colspan="2">SMA</td>
        <td style="width: 18%;"  colspan="2">SARJANA</td>
        <td style="width: 10%;" rowspan="2">Jumlah</td>
	  </tr>
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 9%; height:12px;">L</td>
		<td style="width: 9%; height:12px;">P</td>
		<td style="width: 9%; height:12px;">L</td>
		<td style="width: 9%; height:12px;">P</td>
        <td style="width: 9%; height:12px;">L</td>
		<td style="width: 9%; height:12px;">P</td>
        <td style="width: 9%; height:12px;">L</td>
		<td style="width: 9%; height:12px;">P</td>
	  </tr>
      <? 
	  $rs_tahun= mysql_query("select * from tbl_tahun WHERE tahun_kode <= '".$_POST['tahun_sampai']."'");
	  $no = 1;
	  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
		  $rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '5' AND jenjangpendidikan_kode = '1'"));
		  $rows_two=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '5' AND jenjangpendidikan_kode = '2'"));
		  $rows_three=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '5' AND jenjangpendidikan_kode = '3'"));
		  $rows_four=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '5' AND jenjangpendidikan_kode = '4'"));
	
		  
	  ?>
      <tr style="text-align:center; font-size:12px;">
      <td style="width: 3%; height:12px;"><? echo $no ?></td>
		<td style="width: 10%; height:12px;"><? echo $rows_tahun['tahun_name'] ?></td>
		<td style="width: 9%;"><? echo cFormat($rows_one['data_laki'], false) ?></td>
        <td style="width: 9%;"><? echo cFormat($rows_one['data_perempuan'], false) ?></td>
        <td style="width: 9%;"><? echo cFormat($rows_two['data_laki'], false) ?></td>
        <td style="width: 9%;"><? echo cFormat($rows_two['data_perempuan'], false) ?></td>
        <td style="width: 9%;"><? echo cFormat($rows_three['data_laki'], false) ?></td>
        <td style="width: 9%;"><? echo cFormat($rows_three['data_perempuan'], false) ?></td>
        <td style="width: 9%;"><? echo cFormat($rows_four['data_laki'], false) ?></td>
        <td style="width: 9%;"><? echo cFormat($rows_four['data_perempuan'], false) ?></td>
       
        <td style="width: 10%;"><? echo cFormat($rows_one['data_perempuan'] + $rows_two['data_perempuan']+$rows_three['data_perempuan']+$rows_four['data_perempuan']+ $rows_one['data_laki'] + $rows_two['data_laki']+$rows_three['data_laki']+$rows_four['data_laki'], false) ?></td>
	  </tr>
      <? $no++; } ?>
      </table>
      
      
      <table cellspacing="0" style="width: 100%; padding:25px 25px 2px 25px;">
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Tabel 4</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Angka Melek Huruf ( AMH )</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Kota/Kabupaten : <? echo$rows_kotas['kota_name'] ?>, Tahun : <? echo $rows_tahunsampai['tahun_name'] ?></td>
	</tr>
    </table>
    <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; padding:0 0 0 0;" align="center">
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 3%; height:12px;" rowspan="3">No</td>
		<td style="width: 8%; height:12px;" rowspan="3">Tahun</td>
		<td style="width: 70%;"  colspan="10">Kelompok Umur</td>
        <td style="width: 10%;" rowspan="3">Jumlah</td>
	  </tr>
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 14%; height:12px;" colspan="2">10-14</td>
		<td style="width: 14%; height:12px;" colspan="2">15-19</td>
		<td style="width: 14%; height:12px;" colspan="2">20-24</td>
		<td style="width: 14%; height:12px;" colspan="2">25-29</td>
        <td style="width: 14%; height:12px;" colspan="2">30-34</td>
        
	  </tr>
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 7%; height:12px;">L</td>
		<td style="width: 7%; height:12px;">P</td>
		<td style="width: 7%; height:12px;">L</td>
		<td style="width: 7%; height:12px;">P</td>
        <td style="width: 7%; height:12px;">L</td>
		<td style="width: 7%; height:12px;">P</td>
        <td style="width: 7%; height:12px;">L</td>
		<td style="width: 7%; height:12px;">P</td>
        <td style="width: 7%; height:12px;">L</td>
		<td style="width: 7%; height:12px;">P</td>
        
	  </tr>
      <? 
	  $rs_tahun= mysql_query("select * from tbl_tahun WHERE tahun_kode <= '".$_POST['tahun_sampai']."'");
	  $no = 1;
	  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
		  $rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '6' AND kelumur_kode = '12'"));
		  $rows_two=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '6' AND kelumur_kode = '13'"));
		  $rows_three=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '6' AND kelumur_kode = '14'"));
		  $rows_four=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '6' AND kelumur_kode = '15'"));
		  $rows_five=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '6' AND kelumur_kode = '16'"));
	
		  
	  ?>
      <tr style="text-align:center; font-size:12px;">
      <td style="width: 3%; height:12px;"><? echo $no ?></td>
		<td style="width: 10%; height:12px;"><? echo $rows_tahun['tahun_name'] ?></td>
		<td style="width: 7%;"><? echo cFormat($rows_one['data_laki'], false) ?></td>
        <td style="width: 7%;"><? echo cFormat($rows_one['data_perempuan'], false) ?></td>
        <td style="width: 7%;"><? echo cFormat($rows_two['data_laki'], false) ?></td>
        <td style="width: 7%;"><? echo cFormat($rows_two['data_perempuan'], false) ?></td>
        <td style="width: 7%;"><? echo cFormat($rows_three['data_laki'], false) ?></td>
        <td style="width: 7%;"><? echo cFormat($rows_three['data_perempuan'], false) ?></td>
        <td style="width: 7%;"><? echo cFormat($rows_four['data_laki'], false) ?></td>
        <td style="width: 7%;"><? echo cFormat($rows_four['data_perempuan'], false) ?></td>
        <td style="width: 7%;"><? echo cFormat($rows_five['data_laki'], false) ?></td>
        <td style="width: 7%;"><? echo cFormat($rows_five['data_perempuan'], false) ?></td>
       
        <td style="width: 10%;"><? echo cFormat($rows_one['data_perempuan'] + $rows_two['data_perempuan']+$rows_three['data_perempuan']+$rows_four['data_perempuan']+ $rows_one['data_laki'] + $rows_two['data_laki']+$rows_three['data_laki']+$rows_four['data_laki'] + $rows_five['data_laki'] + $rows_five['data_perempuan'], false) ?></td>
	  </tr>
      <? $no++; } ?>
      </table>
      
       <table cellspacing="0" style="width: 100%; padding:25px 25px 2px 25px;">
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Tabel 5</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Angka Putus Sekolah</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Kota/Kabupaten : <? echo$rows_kotas['kota_name'] ?>, Tahun : <? echo $rows_tahunsampai['tahun_name'] ?></td>
	</tr>
    </table>
    <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; padding:0 0 0 0;" align="center">
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 3%; height:12px;" rowspan="2">No</td>
		<td style="width: 8%; height:12px;" rowspan="2">Tahun</td>
		<td style="width: 18%;"  colspan="2">SD</td>
        <td style="width: 18%;"  colspan="2">SMP</td>
        <td style="width: 18%;"  colspan="2">SMA</td>
        <td style="width: 18%;"  colspan="2">SARJANA</td>
        <td style="width: 10%;" rowspan="2">Jumlah</td>
	  </tr>
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 9%; height:12px;">L</td>
		<td style="width: 9%; height:12px;">P</td>
		<td style="width: 9%; height:12px;">L</td>
		<td style="width: 9%; height:12px;">P</td>
        <td style="width: 9%; height:12px;">L</td>
		<td style="width: 9%; height:12px;">P</td>
        <td style="width: 9%; height:12px;">L</td>
		<td style="width: 9%; height:12px;">P</td>
	  </tr>
      <? 
	  $rs_tahun= mysql_query("select * from tbl_tahun WHERE tahun_kode <= '".$_POST['tahun_sampai']."'");
	  $no = 1;
	  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
		  $rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '7' AND jenjangpendidikan_kode = '1'"));
		  $rows_two=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '7' AND jenjangpendidikan_kode = '2'"));
		  $rows_three=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '7' AND jenjangpendidikan_kode = '3'"));
		  $rows_four=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '7' AND jenjangpendidikan_kode = '4'"));
	
		  
	  ?>
      <tr style="text-align:center; font-size:12px;">
      <td style="width: 3%; height:12px;"><? echo $no ?></td>
		<td style="width: 10%; height:12px;"><? echo $rows_tahun['tahun_name'] ?></td>
		<td style="width: 9%;"><? echo cFormat($rows_one['data_laki'], false) ?></td>
        <td style="width: 9%;"><? echo cFormat($rows_one['data_perempuan'], false) ?></td>
        <td style="width: 9%;"><? echo cFormat($rows_two['data_laki'], false) ?></td>
        <td style="width: 9%;"><? echo cFormat($rows_two['data_perempuan'], false) ?></td>
        <td style="width: 9%;"><? echo cFormat($rows_three['data_laki'], false) ?></td>
        <td style="width: 9%;"><? echo cFormat($rows_three['data_perempuan'], false) ?></td>
        <td style="width: 9%;"><? echo cFormat($rows_four['data_laki'], false) ?></td>
        <td style="width: 9%;"><? echo cFormat($rows_four['data_perempuan'], false) ?></td>
       
        <td style="width: 10%;"><? echo cFormat($rows_one['data_perempuan'] + $rows_two['data_perempuan']+$rows_three['data_perempuan']+$rows_four['data_perempuan']+ $rows_one['data_laki'] + $rows_two['data_laki']+$rows_three['data_laki']+$rows_four['data_laki'], false) ?></td>
	  </tr>
      <? $no++; } ?>
      </table>
      
      <table cellspacing="0" style="width: 100%; padding:25px 25px 2px 25px;">
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Tabel 6</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Rata - Rata Lama Sekolah</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Kota/Kabupaten : <? echo$rows_kotas['kota_name'] ?>, Tahun : <? echo $rows_tahunsampai['tahun_name'] ?></td>
	</tr>
    </table>
    <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; padding:0 0 0 0;" align="center">
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 3%; height:12px;" rowspan="3">No</td>
		<td style="width: 10%; height:12px;" rowspan="3">Tahun</td>
		<td style="width: 60%;"  colspan="6">Kelompok Umur</td>
        <td style="width: 10%;" rowspan="3">Jumlah</td>
	  </tr>
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 20%; height:12px;" colspan="2">6 Tahun</td>
		<td style="width: 20%; height:12px;" colspan="2">9 Tahun</td>
		<td style="width: 20%; height:12px;" colspan="2">12 Tahun</td>
        
	  </tr>
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 10%; height:12px;">L</td>
		<td style="width: 10%; height:12px;">P</td>
		<td style="width: 10%; height:12px;">L</td>
		<td style="width: 10%; height:12px;">P</td>
        <td style="width: 10%; height:12px;">L</td>
		<td style="width: 10%; height:12px;">P</td>

        
	  </tr>
      <? 
	  $rs_tahun= mysql_query("select * from tbl_tahun WHERE tahun_kode <= '".$_POST['tahun_sampai']."'");
	  $no = 1;
	  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
		  $rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '8' AND kelumur_kode = '17'"));
		  $rows_two=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '8' AND kelumur_kode = '18'"));
		  $rows_three=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '8' AND kelumur_kode = '19'"));
		  
	
		  
	  ?>
      <tr style="text-align:center; font-size:12px;">
      <td style="width: 3%; height:12px;"><? echo $no ?></td>
		<td style="width: 10%; height:12px;"><? echo $rows_tahun['tahun_name'] ?></td>
		<td style="width: 10%;"><? echo cFormat($rows_one['data_laki'], false) ?></td>
        <td style="width: 10%;"><? echo cFormat($rows_one['data_perempuan'], false) ?></td>
        <td style="width: 10%;"><? echo cFormat($rows_two['data_laki'], false) ?></td>
        <td style="width: 10%;"><? echo cFormat($rows_two['data_perempuan'], false) ?></td>
        <td style="width: 10%;"><? echo cFormat($rows_three['data_laki'], false) ?></td>
        <td style="width: 10%;"><? echo cFormat($rows_three['data_perempuan'], false) ?></td>
        
       
        <td style="width: 10%;"><? echo cFormat($rows_one['data_perempuan'] + $rows_two['data_perempuan']+$rows_three['data_perempuan']+ $rows_one['data_laki'] + $rows_two['data_laki']+$rows_three['data_laki'], false) ?></td>
	  </tr>
      <? $no++; } ?>
      </table>
      
      <table cellspacing="0" style="width: 100%; padding:25px 25px 2px 25px;">
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Tabel 7</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Jenis Pendidikan yang di tamatkan</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Kota/Kabupaten : <? echo$rows_kotas['kota_name'] ?>, Tahun : <? echo $rows_tahunsampai['tahun_name'] ?></td>
	</tr>
    </table>
    <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; padding:0 0 0 0;" align="center">
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 3%; height:12px;" rowspan="2">No</td>
		<td style="width: 8%; height:12px;" rowspan="2">Tahun</td>
		<td style="width: 18%;"  colspan="2">SD</td>
        <td style="width: 18%;"  colspan="2">SMP</td>
        <td style="width: 18%;"  colspan="2">SMA</td>
        <td style="width: 18%;"  colspan="2">SARJANA</td>
        <td style="width: 10%;" rowspan="2">Jumlah</td>
	  </tr>
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 9%; height:12px;">L</td>
		<td style="width: 9%; height:12px;">P</td>
		<td style="width: 9%; height:12px;">L</td>
		<td style="width: 9%; height:12px;">P</td>
        <td style="width: 9%; height:12px;">L</td>
		<td style="width: 9%; height:12px;">P</td>
        <td style="width: 9%; height:12px;">L</td>
		<td style="width: 9%; height:12px;">P</td>
	  </tr>
      <? 
	  $rs_tahun= mysql_query("select * from tbl_tahun WHERE tahun_kode <= '".$_POST['tahun_sampai']."'");
	  $no = 1;
	  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
		  $rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '61' AND jenjangpendidikan_kode = '1'"));
		  $rows_two=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '61' AND jenjangpendidikan_kode = '2'"));
		  $rows_three=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '61' AND jenjangpendidikan_kode = '3'"));
		  $rows_four=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '61' AND jenjangpendidikan_kode = '4'"));
	
		  
	  ?>
      <tr style="text-align:center; font-size:12px;">
      <td style="width: 3%; height:12px;"><? echo $no ?></td>
		<td style="width: 10%; height:12px;"><? echo $rows_tahun['tahun_name'] ?></td>
		<td style="width: 9%;"><? echo cFormat($rows_one['data_laki'], false) ?></td>
        <td style="width: 9%;"><? echo cFormat($rows_one['data_perempuan'], false) ?></td>
        <td style="width: 9%;"><? echo cFormat($rows_two['data_laki'], false) ?></td>
        <td style="width: 9%;"><? echo cFormat($rows_two['data_perempuan'], false) ?></td>
        <td style="width: 9%;"><? echo cFormat($rows_three['data_laki'], false) ?></td>
        <td style="width: 9%;"><? echo cFormat($rows_three['data_perempuan'], false) ?></td>
        <td style="width: 9%;"><? echo cFormat($rows_four['data_laki'], false) ?></td>
        <td style="width: 9%;"><? echo cFormat($rows_four['data_perempuan'], false) ?></td>
       
        <td style="width: 10%;"><? echo cFormat($rows_one['data_perempuan'] + $rows_two['data_perempuan']+$rows_three['data_perempuan']+$rows_four['data_perempuan']+ $rows_one['data_laki'] + $rows_two['data_laki']+$rows_three['data_laki']+$rows_four['data_laki'], false) ?></td>
	  </tr>
      <? $no++; } ?>
      </table>
      
      
      
      
      <table cellspacing="0" style="width: 100%; padding:35px 25px 0 25px;">
    <tr>
	<td style="width: 2%; font-size: 12px; height:14px;">III.</td>
    <td style="width: 98%; font-size: 12px;">Bidang Ekonomi dan Ketenagakerjaan</td>
	</tr>
    </table>
    
  
    <table cellspacing="0" style="width: 100%; padding:25px 25px 2px 25px;">
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Tabel 1</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Tingkat Partisipasi Angkatan Kerja (TPAK)</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Kota/Kabupaten : <? echo$rows_kotas['kota_name'] ?>, Tahun : <? echo $rows_tahunsampai['tahun_name'] ?></td>
	</tr>
    </table>
    
    <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; padding:0 0 0 0;" align="center">
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 3%; height:12px;">No</td>
		<td style="width: 20%; height:12px;">Tahun</td>
		<td style="width: 20%;">Laki-laki</td>
        <td style="width: 20%;">Perempuan</td>
        <td style="width: 20%;">Jumlah</td>
	  </tr>
      <? 
	  $rs_tahun= mysql_query("select * from tbl_tahun WHERE tahun_kode <= '".$_POST['tahun_sampai']."'");
	  $no = 1;
	  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
		  $rows_laki=mysql_fetch_array(mysql_query("select sum(data_laki) AS data_laki, sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '9'"));
		 
	  ?>
      <tr style="text-align:center; font-size:12px;">
      <td style="width: 3%; height:12px;"><? echo $no ?></td>
		<td style="width: 20%; height:12px;"><? echo $rows_tahun['tahun_name'] ?></td>
		<td style="width: 20%;"><? echo cFormat($rows_laki['data_laki'], false) ?></td>
        <td style="width: 20%;"><? echo cFormat($rows_laki['data_perempuan'], false) ?></td>
        <td style="width: 20%;"><? echo cFormat($rows_laki['data_laki']+$rows_laki['data_perempuan'], false) ?></td>
	  </tr>
      
      <? $no++; } ?>
      
      
      </table>
      
      
      <table cellspacing="0" style="width: 100%; padding:25px 25px 2px 25px;">
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Tabel 2</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Penduduk Usia Kerja Yang Bekerja Menurut Status Pekerjaan</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Kota/Kabupaten : <? echo$rows_kotas['kota_name'] ?>, Tahun : <? echo $rows_tahunsampai['tahun_name'] ?></td>
	</tr>
    </table>
    
    <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; padding:0 0 0 0;" align="center">
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 3%; height:12px;">No</td>
		<td style="width: 20%; height:12px;">Tahun</td>
		<td style="width: 20%;">Laki-laki</td>
        <td style="width: 20%;">Perempuan</td>
        <td style="width: 20%;">Jumlah</td>
	  </tr>
      <? 
	  $rs_tahun= mysql_query("select * from tbl_tahun WHERE tahun_kode <= '".$_POST['tahun_sampai']."'");
	  $no = 1;
	  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
		  $rows_laki=mysql_fetch_array(mysql_query("select sum(data_laki) AS data_laki, sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '10'"));
		 
	  ?>
      <tr style="text-align:center; font-size:12px;">
      <td style="width: 3%; height:12px;"><? echo $no ?></td>
		<td style="width: 20%; height:12px;"><? echo $rows_tahun['tahun_name'] ?></td>
		<td style="width: 20%;"><? echo cFormat($rows_laki['data_laki'], false) ?></td>
        <td style="width: 20%;"><? echo cFormat($rows_laki['data_perempuan'], false) ?></td>
        <td style="width: 20%;"><? echo cFormat($rows_laki['data_laki']+$rows_laki['data_perempuan'], false) ?></td>
	  </tr>
      
      <? $no++; } ?>
      
      
      </table>
      
      <table cellspacing="0" style="width: 100%; padding:25px 25px 2px 25px;">
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Tabel 3</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Penduduk Usia Kerja</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Kota/Kabupaten : <? echo$rows_kotas['kota_name'] ?>, Tahun : <? echo $rows_tahunsampai['tahun_name'] ?></td>
	</tr>
    </table>
    
    <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; padding:0 0 0 0;" align="center">
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 3%; height:12px;">No</td>
		<td style="width: 10%; height:12px;">Tahun</td>
		<td style="width: 15%;">Laki-laki</td>
        <td style="width: 15%;">Perempuan</td>
        <td style="width: 35%;">Keterangan</td>
        <td style="width: 15%;">Jumlah</td>
	  </tr>
      <? 
	  $rs_tahun= mysql_query("select * from tbl_tahun WHERE tahun_kode <= '".$_POST['tahun_sampai']."'");
	  $no = 1;
	  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
		  $rows_laki=mysql_fetch_array(mysql_query("select sum(data_laki) AS data_laki, sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '11'"));
		  $rows_keterangan=mysql_fetch_array(mysql_query("select * from tbl_data WHERE kegjob_kode = '".$rows_laki['kegjob_kode']."'"));
		 
	  ?>
      <tr style="text-align:center; font-size:12px;">
      <td style="width: 3%; height:12px;"><? echo $no ?></td>
		<td style="width: 10%; height:12px;"><? echo $rows_tahun['tahun_name'] ?></td>
		<td style="width: 15%;"><? echo cFormat($rows_laki['data_laki'], false) ?></td>
        <td style="width: 15%;"><? echo cFormat($rows_laki['data_perempuan'], false) ?></td>
        <td style="width: 35%;"><? echo cFormat($rows_keterangan['kegjob_name'], false) ?></td>
        <td style="width: 15%;"><? echo cFormat($rows_laki['data_laki']+$rows_laki['data_perempuan'], false) ?></td>
	  </tr>
      
      <? $no++; } ?>
      
      
      </table>
      
      <table cellspacing="0" style="width: 100%; padding:25px 25px 2px 25px;">
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Tabel 4</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Pekerja Formal dan Informal</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Kota/Kabupaten : <? echo$rows_kotas['kota_name'] ?>, Tahun : <? echo $rows_tahunsampai['tahun_name'] ?></td>
	</tr>
    </table>
    
    <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; padding:0 0 0 0;" align="center">
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 3%; height:12px;">No</td>
		<td style="width: 10%; height:12px;">Tahun</td>
		<td style="width: 15%;">Laki-laki</td>
        <td style="width: 15%;">Perempuan</td>
        <td style="width: 35%;">jenis Pekerjaan</td>
        <td style="width: 15%;">Jumlah</td>
	  </tr>
      <? 
	  $rs_tahun= mysql_query("select * from tbl_tahun WHERE tahun_kode <= '".$_POST['tahun_sampai']."'");
	  $no = 1;
	  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
		  $rows_laki=mysql_fetch_array(mysql_query("select sum(data_laki) AS data_laki, sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '12'"));
		  $rows_keterangan=mysql_fetch_array(mysql_query("select * from tbl_jenisjob WHERE jenisjob_kode = '".$rows_laki['jenisjob_kode']."'"));
		 
	  ?>
      <tr style="text-align:center; font-size:12px;">
      <td style="width: 3%; height:12px;"><? echo $no ?></td>
		<td style="width: 10%; height:12px;"><? echo $rows_tahun['tahun_name'] ?></td>
		<td style="width: 15%;"><? echo cFormat($rows_laki['data_laki'], false) ?></td>
        <td style="width: 15%;"><? echo cFormat($rows_laki['data_perempuan'], false) ?></td>
        <td style="width: 35%;"><? echo cFormat($rows_keterangan['jenisjob_name'], false) ?></td>
        <td style="width: 15%;"><? echo cFormat($rows_laki['data_laki']+$rows_laki['data_perempuan'], false) ?></td>
	  </tr>
      
      <? $no++; } ?>
      
      
      </table>
      
      
      <table cellspacing="0" style="width: 100%; padding:25px 25px 2px 25px;">
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Tabel 5</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Tingkat Pengangguran Terbuka ( TPT ) </td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Kota/Kabupaten : <? echo$rows_kotas['kota_name'] ?>, Tahun : <? echo $rows_tahunsampai['tahun_name'] ?></td>
	</tr>
    </table>
    
    <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; padding:0 0 0 0;" align="center">
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 3%; height:12px;">No</td>
		<td style="width: 10%; height:12px;">Tahun</td>
		<td style="width: 15%;">Laki-laki</td>
        <td style="width: 15%;">Perempuan</td>
        <td style="width: 35%;">Jam Kerja</td>
        <td style="width: 15%;">Jumlah</td>
	  </tr>
      <? 
	  $rs_tahun= mysql_query("select * from tbl_tahun WHERE tahun_kode <= '".$_POST['tahun_sampai']."'");
	  $no = 1;
	  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
		  $rows_laki=mysql_fetch_array(mysql_query("select sum(data_laki) AS data_laki, sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '13'"));
		  $rows_keterangan=mysql_fetch_array(mysql_query("select * from tbl_jobtime WHERE jobtime_kode = '".$rows_laki['jobtime_kode']."'"));
		 
	  ?>
      <tr style="text-align:center; font-size:12px;">
      <td style="width: 3%; height:12px;"><? echo $no ?></td>
		<td style="width: 10%; height:12px;"><? echo $rows_tahun['tahun_name'] ?></td>
		<td style="width: 15%;"><? echo cFormat($rows_laki['data_laki'], false) ?></td>
        <td style="width: 15%;"><? echo cFormat($rows_laki['data_perempuan'], false) ?></td>
        <td style="width: 35%;"><? echo cFormat($rows_keterangan['jobtime_name'], false) ?></td>
        <td style="width: 15%;"><? echo cFormat($rows_laki['data_laki']+$rows_laki['data_perempuan'], false) ?></td>
	  </tr>
      
      <? $no++; } ?>
      
      
      </table>
      
       <table cellspacing="0" style="width: 100%; padding:25px 25px 2px 25px;">
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Tabel 6</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Setengah Pengangguran</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Kota/Kabupaten : <? echo$rows_kotas['kota_name'] ?>, Tahun : <? echo $rows_tahunsampai['tahun_name'] ?></td>
	</tr>
    </table>
    
    <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; padding:0 0 0 0;" align="center">
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 3%; height:12px;">No</td>
		<td style="width: 20%; height:12px;">Tahun</td>
		<td style="width: 20%;">Laki-laki</td>
        <td style="width: 20%;">Perempuan</td>
        <td style="width: 20%;">Jumlah</td>
	  </tr>
      <? 
	  $rs_tahun= mysql_query("select * from tbl_tahun WHERE tahun_kode <= '".$_POST['tahun_sampai']."'");
	  $no = 1;
	  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
		  $rows_laki=mysql_fetch_array(mysql_query("select sum(data_laki) AS data_laki, sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '14'"));
		 
	  ?>
      <tr style="text-align:center; font-size:12px;">
      <td style="width: 3%; height:12px;"><? echo $no ?></td>
		<td style="width: 20%; height:12px;"><? echo $rows_tahun['tahun_name'] ?></td>
		<td style="width: 20%;"><? echo cFormat($rows_laki['data_laki'], false) ?></td>
        <td style="width: 20%;"><? echo cFormat($rows_laki['data_perempuan'], false) ?></td>
        <td style="width: 20%;"><? echo cFormat($rows_laki['data_laki']+$rows_laki['data_perempuan'], false) ?></td>
	  </tr>
      
      <? $no++; } ?>
      
      
      </table>
      
      
      
      
      
      
      <table cellspacing="0" style="width: 100%; padding:25px 25px 2px 25px;">
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Tabel 8</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Pemeriman Kredit/Pinjaman Bank</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Kota/Kabupaten : <? echo$rows_kotas['kota_name'] ?>, Tahun : <? echo $rows_tahunsampai['tahun_name'] ?></td>
	</tr>
    </table>
    
    <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; padding:0 0 0 0;" align="center">
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 3%; height:12px;">No</td>
		<td style="width: 10%; height:12px;">Tahun</td>
		<td style="width: 15%;">Laki-laki</td>
        <td style="width: 15%;">Perempuan</td>
        
        <td style="width: 15%;">Jumlah</td>
	  </tr>
      <? 
	  $rs_tahun= mysql_query("select * from tbl_tahun WHERE tahun_kode <= '".$_POST['tahun_sampai']."'");
	  $no = 1;
	  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
		  
		  $rows_laki=mysql_fetch_array(mysql_query("select sum(data_laki) AS data_laki, sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '64'"));
		  $rows_keterangan=mysql_fetch_array(mysql_query("select * from tbl_data WHERE kegjob_kode = '".$rows_laki['kegjob_kode']."'"));
		 
	  ?>
      <tr style="font-size:12px;">
      <td style="width: 3%; height:12px;"><? echo $no ?></td>
		<td style="width: 45%; height:12px;" ><b><? echo $rows_tahun['tahun_name'] ?></b></td>
		<td style="width: 15%;"></td>
        <td style="width: 15%;"></td>
        
        <td style="width: 15%;"></td>
	  </tr>
      <? 
	  $rs_jenisusaha= mysql_query("select * from tbl_jenisusaha ORDER BY jenisusaha_kode ASC");
	  $nos = 1;
	  while($rows_jenisusaha=mysql_fetch_array($rs_jenisusaha)) { 
	  
	  $rows_laki=mysql_fetch_array(mysql_query("select sum(data_laki) AS data_laki, sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '62' AND jenisusaha_kode = '".$rows_jenisusaha['jenisusaha_kode']."'"));
	  ?>
      <tr style="font-size:12px;">
      <td style="width: 3%; height:12px;"></td>
		<td style="width: 45%; height:12px;">* &nbsp; <? echo $rows_jenisusaha['jenisusaha_name'] ?></td>
		<td style="width: 15%;"><? echo cFormat($rows_laki['data_laki'], false) ?></td>
        <td style="width: 15%;"><? echo cFormat($rows_laki['data_perempuan'], false) ?></td>
        
        <td style="width: 15%;"><? echo cFormat($rows_laki['data_laki']+$rows_laki['data_perempuan'], false) ?></td>
	  </tr>
      
      <? $nos++; } ?>
      <? $no++; } ?>
      
      
      </table>
      
      
      <table cellspacing="0" style="width: 100%; padding:25px 25px 2px 25px;">
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Tabel 8</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Pemeriman Kredit/Pinjaman Bank</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Kota/Kabupaten : <? echo$rows_kotas['kota_name'] ?>, Tahun : <? echo $rows_tahunsampai['tahun_name'] ?></td>
	</tr>
    </table>
    
    <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; padding:0 0 0 0;" align="center">
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 3%; height:12px;">No</td>
		<td style="width: 10%; height:12px;">Tahun</td>
		<td style="width: 15%;">Laki-laki</td>
        <td style="width: 15%;">Perempuan</td>
        <td style="width: 35%;">Sumber</td>
        <td style="width: 15%;">Jumlah</td>
	  </tr>
      <? 
	  $rs_tahun= mysql_query("select * from tbl_tahun WHERE tahun_kode <= '".$_POST['tahun_sampai']."'");
	  $no = 1;
	  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
		  $rows_laki=mysql_fetch_array(mysql_query("select sum(data_laki) AS data_laki, sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '64'"));
		  $rows_keterangan=mysql_fetch_array(mysql_query("select * from tbl_data WHERE kegjob_kode = '".$rows_laki['kegjob_kode']."'"));
		 
	  ?>
      <tr style="text-align:center; font-size:12px;">
      <td style="width: 3%; height:12px;"><? echo $no ?></td>
		<td style="width: 10%; height:12px;"><? echo $rows_tahun['tahun_name'] ?></td>
		<td style="width: 15%;"><? echo cFormat($rows_laki['data_laki'], false) ?></td>
        <td style="width: 15%;"><? echo cFormat($rows_laki['data_perempuan'], false) ?></td>
        <td style="width: 35%;"><? echo cFormat($rows_keterangan['data_sumber'], false) ?></td>
        <td style="width: 15%;"><? echo cFormat($rows_laki['data_laki']+$rows_laki['data_perempuan'], false) ?></td>
	  </tr>
      
      <? $no++; } ?>
      
      
      </table>
      
      
      <table cellspacing="0" style="width: 100%; padding:35px 25px 0 25px;">
        <tr>
        <td style="width: 2%; font-size: 12px; height:14px;">IV.</td>
        <td style="width: 98%; font-size: 12px;">Bidang Hukum dan Sosial Budaya</td>
        </tr>
        </table>
        <table cellspacing="0" style="width: 100%; padding:0 25px 2px 25px;">
        <tr>
        <td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Tabel 1</td>
        </tr>
        <tr>
        <td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Penghuni Lembaga Pemasyarakatan</td>
        </tr>
        <tr>
        <td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Kota/Kabupaten : <? echo$rows_kotas['kota_name'] ?>, Tahun : <? echo $rows_tahunsampai['tahun_name'] ?></td>
        </tr>
        </table>
        
        <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; padding:0 0 0 0;" align="center">
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 3%; height:12px;" rowspan="3">No</td>
		<td style="width: 8%; height:12px;" rowspan="3">Tahun</td>
		<td style="width: 36%;"  colspan="4">Kelompok Umur</td>
        
        <td style="width: 10%;" rowspan="3">Jumlah</td>
	  </tr>
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 20%; height:12px;" colspan="2">13-17</td>
		<td style="width: 20%; height:12px;" colspan="2">18 Keatas</td>
		
        
	  </tr>
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 10%; height:12px;">L</td>
		<td style="width: 10%; height:12px;">P</td>
		<td style="width: 10%; height:12px;">L</td>
		<td style="width: 10%; height:12px;">P</td>
        
        
	  </tr>
      <? 
	  $rs_tahun= mysql_query("select * from tbl_tahun WHERE tahun_kode <= '".$_POST['tahun_sampai']."'");
	  $no = 1;
	  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
		  $rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '22' AND kelumur_kode = '20'"));
		  $rows_two=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '22' AND kelumur_kode = '21'"));
		 
	
		  
	  ?>
      <tr style="text-align:center; font-size:12px;">
      <td style="width: 3%; height:12px;"><? echo $no ?></td>
		<td style="width: 10%; height:12px;"><? echo $rows_tahun['tahun_name'] ?></td>
		<td style="width: 10%;"><? echo cFormat($rows_one['data_laki'], false) ?></td>
        <td style="width: 10%;"><? echo cFormat($rows_one['data_perempuan'], false) ?></td>
        <td style="width: 10%;"><? echo cFormat($rows_two['data_laki'], false) ?></td>
        <td style="width: 10%;"><? echo cFormat($rows_two['data_perempuan'], false) ?></td>
       
        
       
        <td style="width: 10%;"><? echo cFormat($rows_one['data_perempuan'] + $rows_two['data_perempuan']+$rows_three['data_perempuan']+$rows_four['data_perempuan']+ $rows_one['data_laki'] + $rows_two['data_laki']+$rows_three['data_laki']+$rows_four['data_laki'], false) ?></td>
	  </tr>
      <? $no++; } ?>
      </table>
      
      
      <table cellspacing="0" style="width: 100%; padding:0 25px 2px 25px;">
        <tr>
        <td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Tabel 2</td>
        </tr>
        <tr>
        <td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Penghuni Rumah Tahanan (Rutan)</td>
        </tr>
        <tr>
        <td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Kota/Kabupaten : <? echo$rows_kotas['kota_name'] ?>, Tahun : <? echo $rows_tahunsampai['tahun_name'] ?></td>
        </tr>
        </table>
        
        <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; padding:0 0 0 0;" align="center">
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 3%; height:12px;" rowspan="3">No</td>
		<td style="width: 8%; height:12px;" rowspan="3">Tahun</td>
		<td style="width: 36%;"  colspan="4">Kelompok Umur</td>
        
        <td style="width: 10%;" rowspan="3">Jumlah</td>
	  </tr>
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 20%; height:12px;" colspan="2">13-17</td>
		<td style="width: 20%; height:12px;" colspan="2">18 Keatas</td>
		
        
	  </tr>
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 10%; height:12px;">L</td>
		<td style="width: 10%; height:12px;">P</td>
		<td style="width: 10%; height:12px;">L</td>
		<td style="width: 10%; height:12px;">P</td>
        
        
	  </tr>
      <? 
	  $rs_tahun= mysql_query("select * from tbl_tahun WHERE tahun_kode <= '".$_POST['tahun_sampai']."'");
	  $no = 1;
	  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
		  $rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '23' AND kelumur_kode = '20'"));
		  $rows_two=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '23' AND kelumur_kode = '21'"));
		 
	
		  
	  ?>
      <tr style="text-align:center; font-size:12px;">
      <td style="width: 3%; height:12px;"><? echo $no ?></td>
		<td style="width: 10%; height:12px;"><? echo $rows_tahun['tahun_name'] ?></td>
		<td style="width: 10%;"><? echo cFormat($rows_one['data_laki'], false) ?></td>
        <td style="width: 10%;"><? echo cFormat($rows_one['data_perempuan'], false) ?></td>
        <td style="width: 10%;"><? echo cFormat($rows_two['data_laki'], false) ?></td>
        <td style="width: 10%;"><? echo cFormat($rows_two['data_perempuan'], false) ?></td>
       
        
       
        <td style="width: 10%;"><? echo cFormat($rows_one['data_perempuan'] + $rows_two['data_perempuan']+$rows_three['data_perempuan']+$rows_four['data_perempuan']+ $rows_one['data_laki'] + $rows_two['data_laki']+$rows_three['data_laki']+$rows_four['data_laki'], false) ?></td>
	  </tr>
      <? $no++; } ?>
      </table>
      
      
      
      <table cellspacing="0" style="width: 100%; padding:35px 25px 0 25px;">
        <tr>
        <td style="width: 2%; font-size: 12px; height:14px;">V.</td>
        <td style="width: 98%; font-size: 12px;">Bidang Politik dan Pengambilan Keputusan</td>
        </tr>
        </table>
        <table cellspacing="0" style="width: 100%; padding:0 25px 2px 25px;">
        <tr>
        <td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Tabel 1</td>
        </tr>
        <tr>
        <td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Legislatif</td>
        </tr>
        <tr>
        <td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Kota/Kabupaten : <? echo$rows_kotas['kota_name'] ?>, Tahun : <? echo $rows_tahunsampai['tahun_name'] ?></td>
        </tr>
        </table>
        
        <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; padding:0 0 0 0;" align="center">
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 3%; height:12px;">No</td>
		<td style="width: 20%; height:12px;">Tahun</td>
		<td style="width: 20%;">Laki-laki</td>
        <td style="width: 20%;">Perempuan</td>
        <td style="width: 20%;">Jumlah</td>
	  </tr>
      <? 
	  $rs_tahun= mysql_query("select * from tbl_tahun WHERE tahun_kode <= '".$_POST['tahun_sampai']."'");
	  $no = 1;
	  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
		  $rows_laki=mysql_fetch_array(mysql_query("select sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '15'"));
		  $rows_laki=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '15'"));
	  ?>
      <tr style="text-align:center; font-size:12px;">
      <td style="width: 3%; height:12px;"><? echo $no ?></td>
		<td style="width: 20%; height:12px;"><? echo $rows_tahun['tahun_name'] ?></td>
		<td style="width: 20%;"><? echo cFormat($rows_laki['data_laki'], false) ?></td>
        <td style="width: 20%;"><? echo cFormat($rows_laki['data_perempuan'], false) ?></td>
        <td style="width: 20%;"><? echo cFormat($rows_laki['data_laki']+$rows_laki['data_perempuan'], false) ?></td>
	  </tr>
      
      <? $no++; } ?>
      
      
      </table>
      
      
      
      <table cellspacing="0" style="width: 100%; padding:25px 25px 2px 25px;">
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Tabel 2</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Jumlah Aparat Penegak Hukum Menurut Jenis Kelamin</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Kota/Kabupaten : <? echo$rows_kotas['kota_name'] ?>, Tahun : <? echo $rows_tahunsampai['tahun_name'] ?></td>
	</tr>
    </table>
    <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; padding:0 0 0 0;" align="center">
      <tr style="text-align:center; font-size:11px; background-color:#CCFFCC;">
      	<td style="width: 3%; height:12px;" rowspan="4">No</td>
		<td style="width: 10%; height:12px;" rowspan="4">Tahun</td>
        <td style="width: 9%; height:12px;" rowspan="3" colspan="3">Hakim</td>
        <td style="width: 9%; height:12px;" rowspan="3" colspan="3">Jaksa</td>
        <td style="width: 9%; height:12px;" rowspan="3" colspan="3">Pengacara</td>
		<td style="width: 60%;"  colspan="20">Kepolisian</td>
	  </tr>
      <tr style="text-align:center; font-size:10px; background-color:#CCFFCC;">
      	<td style="width: 18%; height:12px;" colspan="6">Perwira Tinggi</td>
		<td style="width: 18%; height:12px;" colspan="6">Perwira Menengah</td>
		<td style="width: 18%; height:12px;" colspan="6">Perwira Pertama</td>
        <td style="width: 6%; height:12px;" colspan="2" rowspan="2">Bintara</td>
	  </tr>
      <tr style="text-align:center; font-size:10px; background-color:#CCFFCC;">
      	<td style="width: 6%; height:12px;" colspan="2">Jenderal Polisi</td>
		<td style="width: 6%; height:12px;" colspan="2">Inspektur Jenderal Polisi</td>
		<td style="width: 6%; height:12px;" colspan="2">Brigeder Jenderal Polisi</td>
        <td style="width: 6%; height:12px;" colspan="2">Komisaris Besar Polisi</td>
		<td style="width: 6%; height:12px;" colspan="2">Ajuk Komisaris Besar Polisi</td>
		<td style="width: 6%; height:12px;" colspan="2">Komisaris Polisi</td>
        <td style="width: 6%; height:12px;" colspan="2">Ajun Komosaris Polisi</td>
		<td style="width: 6%; height:12px;" colspan="2">Inspektur Satu Polisi</td>
		<td style="width: 6%; height:12px;" colspan="2">Inspektur Dua Polisi</td>
	  </tr>
      <tr style="text-align:center; font-size:10px; background-color:#CCFFCC;">
      	<td style="width: 3%; height:12px;">L</td>
		<td style="width: 3%; height:12px;">P</td>
		<td style="width: 3%; height:12px;">L+P</td>
		<td style="width: 3%; height:12px;">L</td>
		<td style="width: 3%; height:12px;">P</td>
		<td style="width: 3%; height:12px;">L+P</td>
        <td style="width: 3%; height:12px;">L</td>
		<td style="width: 3%; height:12px;">P</td>
		<td style="width: 3%; height:12px;">L+P</td>		
        <td style="width: 3%; height:12px;">L</td>
		<td style="width: 3%; height:12px;">P</td>
        <td style="width: 3%; height:12px;">L</td>
		<td style="width: 3%; height:12px;">P</td>
		<td style="width: 3%; height:12px;">L</td>
		<td style="width: 3%; height:12px;">P</td>
        <td style="width: 3%; height:12px;">L</td>
		<td style="width: 3%; height:12px;">P</td>
        <td style="width: 3%; height:12px;">L</td>
		<td style="width: 3%; height:12px;">P</td>
		<td style="width: 3%; height:12px;">L</td>
		<td style="width: 3%; height:12px;">P</td>
        <td style="width: 3%; height:12px;">L</td>
		<td style="width: 3%; height:12px;">P</td>
        <td style="width: 3%; height:12px;">L</td>
		<td style="width: 3%; height:12px;">P</td>
		<td style="width: 3%; height:12px;">L</td>
		<td style="width: 3%; height:12px;">P</td>
        <td style="width: 3%; height:12px;">L</td>
        <td style="width: 3%; height:12px;">P</td>
	  </tr>
      <tr style="text-align:center; font-size:10px; background-color:#CCFFCC;">
      	<td style="width: 3%; height:12px;">1</td>
		<td style="width: 3%; height:12px;">2</td>
		<td style="width: 3%; height:12px;">3</td>
		<td style="width: 3%; height:12px;">4</td>
        <td style="width: 3%; height:12px;">5</td>
		<td style="width: 3%; height:12px;">6</td>
        <td style="width: 3%; height:12px;">7</td>
		<td style="width: 3%; height:12px;">8</td>
		<td style="width: 3%; height:12px;">9</td>
		<td style="width: 3%; height:12px;">10</td>
        <td style="width: 3%; height:12px;">11</td>
		<td style="width: 3%; height:12px;">12</td>
        <td style="width: 3%; height:12px;">13</td>
		<td style="width: 3%; height:12px;">14</td>
		<td style="width: 3%; height:12px;">15</td>
		<td style="width: 3%; height:12px;">16</td>
        <td style="width: 3%; height:12px;">17</td>
		<td style="width: 3%; height:12px;">18</td>
        <td style="width: 3%; height:12px;">19</td>
		<td style="width: 3%; height:12px;">20</td>
		<td style="width: 3%; height:12px;">21</td>
		<td style="width: 3%; height:12px;">22</td>
        <td style="width: 3%; height:12px;">23</td>
		<td style="width: 3%; height:12px;">24</td>
        <td style="width: 3%; height:12px;">25</td>
		<td style="width: 3%; height:12px;">26</td>
		<td style="width: 3%; height:12px;">27</td>
		<td style="width: 3%; height:12px;">28</td>
        <td style="width: 3%; height:12px;">29</td>
        <td style="width: 3%; height:12px;">30</td>
        <td style="width: 3%; height:12px;">31</td>
	  </tr>
      <? 
	  $rs_tahun= mysql_query("select * from tbl_tahun WHERE tahun_kode <= '".$_POST['tahun_sampai']."'");
	  $no = 1;
	  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
		  $rows_jaksa=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '16' AND data_kompres = '1'"));
		  $rows_hakim=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '16' AND data_kompres = '2'"));
		   $rows_pengacara=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '16' AND data_kompres = '7'"));
		  $rows_perwiratinggi1=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '16' AND data_kompres = '3' AND perwiratinggi_kode = '1'"));
		  $rows_perwiratinggi2=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '16' AND data_kompres = '3' AND perwiratinggi_kode = '2'"));
		  $rows_perwiratinggi3=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '16' AND data_kompres = '3' AND perwiratinggi_kode = '3'"));
		  
		  $rows_perwiramenengah1=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '16' AND data_kompres = '4' AND perwiratinggi_kode = '1'"));
		  $rows_perwiramenengah2=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '16' AND data_kompres = '4' AND perwiratinggi_kode = '2'"));
		  $rows_perwiramenengah3=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '16' AND data_kompres = '4' AND perwiratinggi_kode = '3'"));
		  
		   $rows_perwirapertama1=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '16' AND data_kompres = '5' AND perwiratinggi_kode = '1'"));
		  $rows_perwirapertama2=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '16' AND data_kompres = '5' AND perwiratinggi_kode = '2'"));
		  $rows_perwirapertama3=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '16' AND data_kompres = '5' AND perwiratinggi_kode = '3'"));
		  
		  
		  $rows_bintara = mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '16' AND data_kompres = '6'"));
	  ?>
      <tr style="text-align:center; font-size:8px;">
      <td style="width: 3%; height:10px;"><? echo $no ?></td>
		<td style="width: 10%; height:12px;"><? echo $rows_tahun['tahun_name'] ?></td>
		<td style="width: 3%;"><? echo cFormat($rows_jaksa['data_laki'], false) ?></td>
        <td style="width: 3%;"><? echo cFormat($rows_jaksa['data_perempuan'], false) ?></td>
        <td style="width: 3%;"><? echo cFormat($rows_jaksa['data_laki'] + $rows_jaksa['data_perempuan'], false) ?></td>
        
        <td style="width: 3%;"><? echo cFormat($rows_hakim['data_laki'], false) ?></td>
        <td style="width: 3%;"><? echo cFormat($rows_hakim['data_perempuan'], false) ?></td>
        <td style="width: 3%;"><? echo cFormat($rows_hakim['data_laki'] + $rows_hakim['data_perempuan'], false) ?></td>

        <td style="width: 3%;"><? echo cFormat($rows_pengacara['data_laki'], false) ?></td>
        <td style="width: 3%;"><? echo cFormat($rows_pengacara['data_perempuan'], false) ?></td>
        <td style="width: 3%;"><? echo cFormat($rows_pengacara['data_laki'] + $rows_pengacara['data_perempuan'], false) ?></td>
        
        <td style="width: 3%;"><? echo cFormat($rows_perwiratinggi1['data_laki'], false) ?></td>
        <td style="width: 3%;"><? echo cFormat($rows_perwiratinggi1['data_perempuan'], false) ?></td>
        
        <td style="width: 3%;"><? echo cFormat($rows_perwiratinggi2['data_laki'], false) ?></td>
        <td style="width: 3%;"><? echo cFormat($rows_perwiratinggi2['data_perempuan'], false) ?></td>
        
        <td style="width: 3%;"><? echo cFormat($rows_perwiratinggi3['data_laki'], false) ?></td>
        <td style="width: 3%;"><? echo cFormat($rows_perwiratinggi3['data_perempuan'], false) ?></td>
        
        <td style="width: 3%;"><? echo cFormat($rows_perwiramenengah1['data_laki'], false) ?></td>
        <td style="width: 3%;"><? echo cFormat($rows_perwiramenengah1['data_perempuan'], false) ?></td>
        
        <td style="width: 3%;"><? echo cFormat($rows_perwiramenengah2['data_laki'], false) ?></td>
        <td style="width: 3%;"><? echo cFormat($rows_perwiramenengah2['data_perempuan'], false) ?></td>
        
        <td style="width: 3%;"><? echo cFormat($rows_perwiramenengah3['data_laki'], false) ?></td>
        <td style="width: 3%;"><? echo cFormat($rows_perwiramenengah3['data_perempuan'], false) ?></td>
        
        
        <td style="width: 3%;"><? echo cFormat($rows_perwirapertama1['data_laki'], false) ?></td>
        <td style="width: 3%;"><? echo cFormat($rows_perwirapertama1['data_perempuan'], false) ?></td>
        <td style="width: 3%;"><? echo cFormat($rows_perwirapertama2['data_laki'], false) ?></td>
        <td style="width: 3%;"><? echo cFormat($rows_perwirapertama2['data_perempuan'], false) ?></td>
        <td style="width: 3%;"><? echo cFormat($rows_perwirapertama3['data_laki'], false) ?></td>
        <td style="width: 3%;"><? echo cFormat($rows_perwirapertama3['data_perempuan'], false) ?></td>
        <td style="width: 3%;"><? echo cFormat($rows_bintara['data_laki'], false) ?></td>
        <td style="width: 3%;"><? echo cFormat($rows_bintara['data_perempuan'], false) ?></td>
	  </tr>
      <? $no++; } ?>
      </table>
      
      
      
      
      
      
      <table cellspacing="0" style="width: 100%; padding:25px 25px 2px 25px;">
        <tr>
        <td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Tabel 3</td>
        </tr>
        <tr>
        <td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Camat</td>
        </tr>
        <tr>
        <td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Kota/Kabupaten : <? echo$rows_kotas['kota_name'] ?>, Tahun : <? echo $rows_tahunsampai['tahun_name'] ?></td>
        </tr>
        </table>
        
        <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; padding:0 0 0 0;" align="center">
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 3%; height:12px;">No</td>
		<td style="width: 20%; height:12px;">Tahun</td>
		<td style="width: 20%;">Laki-laki</td>
        <td style="width: 20%;">Perempuan</td>
        <td style="width: 20%;">Jumlah</td>
	  </tr>
      <? 
	  $rs_tahun= mysql_query("select * from tbl_tahun WHERE tahun_kode <= '".$_POST['tahun_sampai']."'");
	  $no = 1;
	  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
		  $rows_laki=mysql_fetch_array(mysql_query("select sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '18'"));
		  $rows_laki=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '18'"));
	  ?>
      <tr style="text-align:center; font-size:12px;">
      <td style="width: 3%; height:12px;"><? echo $no ?></td>
		<td style="width: 20%; height:12px;"><? echo $rows_tahun['tahun_name'] ?></td>
		<td style="width: 20%;"><? echo cFormat($rows_laki['data_laki'], false) ?></td>
        <td style="width: 20%;"><? echo cFormat($rows_laki['data_perempuan'], false) ?></td>
        <td style="width: 20%;"><? echo cFormat($rows_laki['data_laki']+$rows_laki['data_perempuan'], false) ?></td>
	  </tr>
      
      <? $no++; } ?>
      
      
      </table>
      
      
      <table cellspacing="0" style="width: 100%; padding:25px 25px 2px 25px;">
        <tr>
        <td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Tabel 4</td>
        </tr>
        <tr>
        <td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Lurah</td>
        </tr>
        <tr>
        <td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Kota/Kabupaten : <? echo$rows_kotas['kota_name'] ?>, Tahun : <? echo $rows_tahunsampai['tahun_name'] ?></td>
        </tr>
        </table>
        
        <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; padding:0 0 0 0;" align="center">
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 3%; height:12px;">No</td>
		<td style="width: 20%; height:12px;">Tahun</td>
		<td style="width: 20%;">Laki-laki</td>
        <td style="width: 20%;">Perempuan</td>
        <td style="width: 20%;">Jumlah</td>
	  </tr>
      <? 
	  $rs_tahun= mysql_query("select * from tbl_tahun WHERE tahun_kode <= '".$_POST['tahun_sampai']."'");
	  $no = 1;
	  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
		  $rows_laki=mysql_fetch_array(mysql_query("select sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '19'"));
		  $rows_laki=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '19'"));
	  ?>
      <tr style="text-align:center; font-size:12px;">
      <td style="width: 3%; height:12px;"><? echo $no ?></td>
		<td style="width: 20%; height:12px;"><? echo $rows_tahun['tahun_name'] ?></td>
		<td style="width: 20%;"><? echo cFormat($rows_laki['data_laki'], false) ?></td>
        <td style="width: 20%;"><? echo cFormat($rows_laki['data_perempuan'], false) ?></td>
        <td style="width: 20%;"><? echo cFormat($rows_laki['data_laki']+$rows_laki['data_perempuan'], false) ?></td>
	  </tr>
      
      <? $no++; } ?>
      
      
      </table>
      
      
       <table cellspacing="0" style="width: 100%; padding:25px 25px 2px 25px;">
        <tr>
        <td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Tabel 5</td>
        </tr>
        <tr>
        <td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Kepala Kampung</td>
        </tr>
        <tr>
        <td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Kota/Kabupaten : <? echo$rows_kotas['kota_name'] ?>, Tahun : <? echo $rows_tahunsampai['tahun_name'] ?></td>
        </tr>
        </table>
        
        <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; padding:0 0 0 0;" align="center">
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 3%; height:12px;">No</td>
		<td style="width: 20%; height:12px;">Tahun</td>
		<td style="width: 20%;">Laki-laki</td>
        <td style="width: 20%;">Perempuan</td>
        <td style="width: 20%;">Jumlah</td>
	  </tr>
      <? 
	  $rs_tahun= mysql_query("select * from tbl_tahun WHERE tahun_kode <= '".$_POST['tahun_sampai']."'");
	  $no = 1;
	  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
		  $rows_laki=mysql_fetch_array(mysql_query("select sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '20'"));
		  $rows_laki=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '20'"));
	  ?>
      <tr style="text-align:center; font-size:12px;">
      <td style="width: 3%; height:12px;"><? echo $no ?></td>
		<td style="width: 20%; height:12px;"><? echo $rows_tahun['tahun_name'] ?></td>
		<td style="width: 20%;"><? echo cFormat($rows_laki['data_laki'], false) ?></td>
        <td style="width: 20%;"><? echo cFormat($rows_laki['data_perempuan'], false) ?></td>
        <td style="width: 20%;"><? echo cFormat($rows_laki['data_laki']+$rows_laki['data_perempuan'], false) ?></td>
	  </tr>
      
      <? $no++; } ?>
      
      
      </table>
      
      <table cellspacing="0" style="width: 100%; padding:25px 25px 2px 25px;">
        <tr>
        <td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Tabel 6</td>
        </tr>
        <tr>
        <td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Keanggotaan Parpol</td>
        </tr>
        <tr>
        <td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Kota/Kabupaten : <? echo$rows_kotas['kota_name'] ?>, Tahun : <? echo $rows_tahunsampai['tahun_name'] ?></td>
        </tr>
        </table>
        
        <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; padding:0 0 0 0;" align="center">
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 3%; height:12px;">No</td>
		<td style="width: 15%; height:12px;">Tahun</td>
		<td style="width: 15%;">Laki-laki</td>
        <td style="width: 15%;">Perempuan</td>
        <td style="width: 30%;">Partai Politik</td>
        <td style="width: 15%;">Jumlah</td>
	  </tr>
      <? 
	  $rs_tahun= mysql_query("select * from tbl_tahun WHERE tahun_kode <= '".$_POST['tahun_sampai']."'");
	  $no = 1;
	  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
		  $rows_laki=mysql_fetch_array(mysql_query("select sum(data_laki) AS data_laki, sum(data_perempuan) AS data_perempuan  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '20'"));
		  
		  $rows_lparpol=mysql_fetch_array(mysql_query("select *  from tbl_parpol WHERE parpol_kode = '".$rows_laki['parpol_kode']."'"));
	  ?>
      <tr style="text-align:center; font-size:12px;">
      <td style="width: 3%; height:12px;"><? echo $no ?></td>
		<td style="width: 15%; height:12px;"><? echo $rows_tahun['tahun_name'] ?></td>
		<td style="width: 15%;"><? echo cFormat($rows_laki['data_laki'], false) ?></td>
        <td style="width: 15%;"><? echo cFormat($rows_laki['data_perempuan'], false) ?></td>
        <td style="width: 30%; height:12px;"><? echo $rows_lparpol['parpol_name'] ?></td>
        <td style="width: 15%;"><? echo cFormat($rows_laki['data_laki']+$rows_laki['data_perempuan'], false) ?></td>
	  </tr>
      
      <? $no++; } ?>
      
      
      </table>

      
      <table cellspacing="0" style="width: 100%; padding:35px 25px 0 25px;">
        <tr>
        <td style="width: 2%; font-size: 12px; height:14px;">V.</td>
        <td style="width: 98%; font-size: 12px;">Kekerasan Perempuan dan Anak</td>
        </tr>
        </table>
        <table cellspacing="0" style="width: 100%; padding:25px 25px 2px 25px;">
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Tabel 1</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Korban</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Kota/Kabupaten : <? echo$rows_kotas['kota_name'] ?>, Tahun : <? echo $rows_tahunsampai['tahun_name'] ?></td>
	</tr>
    </table>
    <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; padding:0 0 0 0;" align="center">
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 3%; height:12px;" rowspan="2">No</td>
		<td style="width: 47%; height:12px;" rowspan="2">Tahun</td>
		<td style="width: 10%;"  colspan="2">SD</td>
        <td style="width: 10%;"  colspan="2">SMP</td>
        <td style="width: 10%;"  colspan="2">SMA</td>
        <td style="width: 10%;"  colspan="2">SARJANA</td>
        <td style="width: 10%;" rowspan="2">Jumlah</td>
	  </tr>
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 5%; height:12px;">L</td>
		<td style="width: 5%; height:12px;">P</td>
		<td style="width: 5%; height:12px;">L</td>
		<td style="width: 5%; height:12px;">P</td>
        <td style="width: 5%; height:12px;">L</td>
		<td style="width: 5%; height:12px;">P</td>
        <td style="width: 5%; height:12px;">L</td>
		<td style="width: 5%; height:12px;">P</td>
	  </tr>
      <? 
	  $rs_tahun= mysql_query("select * from tbl_tahun WHERE tahun_kode <= '".$_POST['tahun_sampai']."'");
	  $no = 1;
	  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
		  
	
		  
	  ?>
      <tr style="font-size:12px;">
      <td style="width: 3%; height:12px;"><? echo $no ?></td>
		<td style="width: 47%; height:12px;"><? echo $rows_tahun['tahun_name'] ?></td>
		<td style="width: 5%;"></td>
        <td style="width: 5%;"></td>
        <td style="width: 5%;"></td>
        <td style="width: 5%;"></td>
        <td style="width: 5%;"></td>
        <td style="width: 5%;"></td>
        <td style="width: 5%;"></td>
        <td style="width: 5%;"></td>
        <td style="width: 5%;"></td>
	  </tr>
      
      <? 
	  $rs_jenistindakan= mysql_query("select * from tbl_jenistindakan ORDER BY jenistindakan_kode ASC");
	  $nos = 1;
	  while($rows_jenistindakan=mysql_fetch_array($rs_jenistindakan)) { 
	  
	  		$rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '26' AND jenistindakan_kode =  '".$rows_jenistindakan['jenistindakan_kode']."' AND jenjangpendidikan_kode = '1'"));
		  $rows_two=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '26' AND jenistindakan_kode = '".$rows_jenistindakan['jenistindakan_kode']."' AND jenjangpendidikan_kode = '2'"));
		  $rows_three=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '26' AND jenistindakan_kode = '".$rows_jenistindakan['jenistindakan_kode']."' AND jenjangpendidikan_kode = '3'"));
		  $rows_four=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '26' AND jenistindakan_kode = '".$rows_jenistindakan['jenistindakan_kode']."' AND jenjangpendidikan_kode = '4'"));
	  ?>
      <tr style="font-size:12px;">
      <td style="width: 3%; height:12px;"></td>
		<td style="width: 47%; height:12px;">* <? echo $rows_jenistindakan['jenistindakan_name'] ?></td>
		<td style="width: 5%;"><? echo cFormat($rows_one['data_laki'], false) ?></td>
        <td style="width: 5%;"><? echo cFormat($rows_one['data_perempuan'], false) ?></td>
        <td style="width: 5%;"><? echo cFormat($rows_two['data_laki'], false) ?></td>
        <td style="width: 5%;"><? echo cFormat($rows_two['data_perempuan'], false) ?></td>
        <td style="width: 5%;"><? echo cFormat($rows_three['data_laki'], false) ?></td>
        <td style="width: 5%;"><? echo cFormat($rows_three['data_perempuan'], false) ?></td>
        <td style="width: 5%;"><? echo cFormat($rows_four['data_laki'], false) ?></td>
        <td style="width: 5%;"><? echo cFormat($rows_four['data_perempuan'], false) ?></td>
       
        <td style="width: 10%;"><? echo cFormat($rows_one['data_perempuan'] + $rows_two['data_perempuan']+$rows_three['data_perempuan']+$rows_four['data_perempuan']+ $rows_one['data_laki'] + $rows_two['data_laki']+$rows_three['data_laki']+$rows_four['data_laki'], false) ?></td>
	  </tr>
      
      <? $nos++; } ?>
      <? $no++; } ?>
      </table>
      
      <table cellspacing="0" style="width: 100%; padding:25px 25px 2px 25px;">
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Tabel 2</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Pelaku</td>
	</tr>
    <tr>
	<td style="width: 100%; font-size: 12px; height:14px; text-align:center;">Kota/Kabupaten : <? echo$rows_kotas['kota_name'] ?>, Tahun : <? echo $rows_tahunsampai['tahun_name'] ?></td>
	</tr>
    </table>
    <table border="0.3" cellspacing="0" style="width: 100%; border-color:#903; padding:0 0 0 0;" align="center">
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 3%; height:12px;" rowspan="2">No</td>
		<td style="width: 47%; height:12px;" rowspan="2">Tahun</td>
		<td style="width: 10%;"  colspan="2">SD</td>
        <td style="width: 10%;"  colspan="2">SMP</td>
        <td style="width: 10%;"  colspan="2">SMA</td>
        <td style="width: 10%;"  colspan="2">SARJANA</td>
        <td style="width: 10%;" rowspan="2">Jumlah</td>
	  </tr>
      <tr style="text-align:center; font-size:12px; background-color:#CCFFCC;">
      	<td style="width: 5%; height:12px;">L</td>
		<td style="width: 5%; height:12px;">P</td>
		<td style="width: 5%; height:12px;">L</td>
		<td style="width: 5%; height:12px;">P</td>
        <td style="width: 5%; height:12px;">L</td>
		<td style="width: 5%; height:12px;">P</td>
        <td style="width: 5%; height:12px;">L</td>
		<td style="width: 5%; height:12px;">P</td>
	  </tr>
      <? 
	  $rs_tahun= mysql_query("select * from tbl_tahun WHERE tahun_kode <= '".$_POST['tahun_sampai']."'");
	  $no = 1;
	  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
		  
	
		  
	  ?>
      <tr style="font-size:12px;">
      <td style="width: 3%; height:12px;"><? echo $no ?></td>
		<td style="width: 47%; height:12px;"><? echo $rows_tahun['tahun_name'] ?></td>
		<td style="width: 5%;"></td>
        <td style="width: 5%;"></td>
        <td style="width: 5%;"></td>
        <td style="width: 5%;"></td>
        <td style="width: 5%;"></td>
        <td style="width: 5%;"></td>
        <td style="width: 5%;"></td>
        <td style="width: 5%;"></td>
        <td style="width: 5%;"></td>
	  </tr>
      
      <? 
	  $rs_hk= mysql_query("select * from tbl_hk ORDER BY hk_kode ASC");
	  $nos = 1;
	  while($rows_hk=mysql_fetch_array($rs_hk)) { 
	  
	  		$rows_one=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '27' AND hk_kode =  '".$rows_hk['hk_kode']."' AND jenjangpendidikan_kode = '1'"));
		  $rows_two=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '27' AND hk_kode = '".$rows_hk['hk_kode']."' AND jenjangpendidikan_kode = '2'"));
		  $rows_three=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '27' AND hk_kode = '".$rows_hk['hk_kode']."' AND jenjangpendidikan_kode = '3'"));
		  $rows_four=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan, sum(data_laki) AS data_laki  from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND kota_kode = '".$_POST['kota_kode']."'  AND submenu_kode = '27' AND hk_kode = '".$rows_hk['hk_kode']."' AND jenjangpendidikan_kode = '4'"));
	  ?>
      <tr style="font-size:12px;">
      <td style="width: 3%; height:12px;"></td>
		<td style="width: 47%; height:12px;">* <? echo $rows_hk['hk_name'] ?></td>
		<td style="width: 5%;"><? echo cFormat($rows_one['data_laki'], false) ?></td>
        <td style="width: 5%;"><? echo cFormat($rows_one['data_perempuan'], false) ?></td>
        <td style="width: 5%;"><? echo cFormat($rows_two['data_laki'], false) ?></td>
        <td style="width: 5%;"><? echo cFormat($rows_two['data_perempuan'], false) ?></td>
        <td style="width: 5%;"><? echo cFormat($rows_three['data_laki'], false) ?></td>
        <td style="width: 5%;"><? echo cFormat($rows_three['data_perempuan'], false) ?></td>
        <td style="width: 5%;"><? echo cFormat($rows_four['data_laki'], false) ?></td>
        <td style="width: 5%;"><? echo cFormat($rows_four['data_perempuan'], false) ?></td>
       
        <td style="width: 10%;"><? echo cFormat($rows_one['data_perempuan'] + $rows_two['data_perempuan']+$rows_three['data_perempuan']+$rows_four['data_perempuan']+ $rows_one['data_laki'] + $rows_two['data_laki']+$rows_three['data_laki']+$rows_four['data_laki'], false) ?></td>
	  </tr>
      
      <? $nos++; } ?>
      <? $no++; } ?>
      </table>
      
