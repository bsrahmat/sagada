<?php


require_once '../../library/connectionmysql.php';
Connected();
if($_SESSION['saga_posisi']=='none' || !isset($_SESSION['saga_posisi'])) { header("Location: ../../index.php"); die; }
if($_SESSION['saga_kode']=='none' || !isset($_SESSION['saga_kode'])) { header("Location: ../../index.php"); die; }


$error = array();

if(!$_POST['tahun_sampai']) $error[] = 'tahun_sampai:Silahkan Pilih Tahun Akhir.';
if(!$_POST['kota_kode']) $error[] = 'kota_kode:Silahkan Pilih Kota / Kabupaten.';
if(!$_POST['menu_kode']) $error[] = 'menu_kode:Silahkan Pilih Sektor Bidang.';


if(count($error)>0) {
	//tampilkan pesan error, jika ada error.. :D
	echo generateError($error).'|*|';	
	
	
} else {
    ob_start();
	
	include(dirname(__FILE__).'/res/laporan-perbidang.php');
	$name = 'LAPORAN-SAGA';
		
    
    $content = ob_get_clean();

    // convert in PDF
    require_once(dirname(__FILE__).'/html2pdf/html2pdf.class.php');
    try
    {
        $html2pdf = new HTML2PDF($_POST['tahun_bentuk'], $_POST['kertas_bentuk'], 'fr');
//      $html2pdf->setModeDebug();
        $html2pdf->setDefaultFont('Arial');
        $html2pdf->writeHTML($content, isset($_GET['vuehtml']));
        $filename = $name.'-'.date('YmdHis').'.pdf';
        $html2pdf->Output($filename);
    }
    catch(HTML2PDF_exception $e) {
        echo $e;
        exit;
    }

}