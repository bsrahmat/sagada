		<?
			require_once 'library/connectionmysql.php';
			Connected();
			$rs_user=mysql_query("select * from tbl_user where user_kode = '".$_SESSION['saga_kode']."'");
			$rows_user=mysql_fetch_array($rs_user);
			
			$userName = $rows_user['user_full_name'];
	
			if($rows_user['user_photo_small']) {
				if(file_exists('photo/small/'.$rows_user['user_photo_small'])) {
					list($width, $height) = getimagesize('photo/small/'.$rows_user['user_photo_small']);
					$photo_small = 'photo/small/'.$rows_user['user_photo_small'];
				} else{	
					if($rows_user['user_gender']=='1') {
						$photo_small = 'photo/small/cew.gif';
					}elseif($rows_user['user_gender']=='0') {
						$photo_small = 'photo/small/cow.gif';
					}
				}
			} else{
				if($rows_user['user_gender']=='1') {
					$photo_small = 'photo/small/cew.gif';
				}elseif($rows_user['user_gender']=='0') {
					$photo_small = 'photo/small/cow.gif';
				}
			}
		?>
		
		<div class="nav-box">
            	<div class="info"><font style=" font-size:18px; color:#000;"><? echo indonesian_date (); ?></font><br /><font style="font-size:32px; color:#FF0;"><div id="clockbox"></div></font> 
                
                
                </div>
                
                 
            	<div class="sub-nav-box">
					<ul class="sub-nav-button">
                    	 
                      <?php 
						$qry_menu = ''; $qry_access = "";
						$qry_menu = "select * from tbl_menu order by menu_kode";
												
						$rs_menu = mysql_query($qry_menu);
						$i = 0;
						
						while($rows_menu=mysql_fetch_array($rs_menu)) {
						if($_SESSION['saga_type']=='0') {
							$qry_submenu = "select * from tbl_submenu where menu_kode = '".$rows_menu['menu_kode']."' order by submenu_kode ASC";
						} else {
							$qry_submenu = "select * from tbl_submenu where menu_kode = '".$rows_menu['menu_kode']."' order by submenu_kode ASC";
							//$qry_submenu = "select * from tbl_submenu where units_kode = '".$_SESSION['saga_unit']."' and menu_kode = '".$rows_menu['menu_kode']."'";
						}
						
						$rs_access = mysql_query("select * from  tbl_permissions where user_kode = '".$_SESSION['saga_kode']."' and menu_kode = '".$rows_menu['menu_kode']."'");
						$rows_access=mysql_fetch_array($rs_access);
						$rs_submenu = mysql_query($qry_submenu);
						$cnt_submenu = mysql_num_rows($rs_submenu);
						
						if($rows_access['permissions_view']!='1') {
						if($cnt_submenu>0) { 
						?>
                      	<li>
                            <div class="<? if($i==0) echo 'nav-ul'; else echo 'nav-ul'; ?>" link="<? echo $rows_menu['menu_link'] ?>"><? echo $rows_menu['menu_name'] ?></div>
                            <ul class="sub-nav-menu">
                            <?php
							if($_SESSION['saga_type']=='0')
								$qry_submenus = "select * from tbl_submenu where menu_kode = '".$rows_menu['menu_kode']."' order by submenu_kode ASC";
							else 
								$qry_submenus = "select * from tbl_submenu where menu_kode = '".$rows_menu['menu_kode']."' order by submenu_kode ASC";
								
							$rs_submenu = mysql_query($qry_submenus);
							$cnt_submenu = mysql_num_rows($rs_submenu);
							if($cnt_submenu>0) {
							while($rows_submenu=mysql_fetch_array($rs_submenu)) {
								
							$qry_subaccess = "select * from  tbl_permissions where user_kode = '".$_SESSION['saga_kode']."' and submenu_kode = '".$rows_submenu['submenu_kode']."'";
							$rs_sub_access = mysql_query($qry_subaccess);
							$rows_sub_access=mysql_fetch_array($rs_sub_access);
							if($rows_sub_access['permissions_view']!='1') {
								if($i==0) { $link = $rows_submenu['menusub_link']; $selected = '-selected'; } else $selected = '';
							?>
                                <li  title="<? echo $rows_submenu['submenu_name'] ?>"><div class="tab<? echo $selected?>" link="<? echo $rows_submenu['menusub_link'] ?>?<? echo $rows_submenu['submenu_kode'] ?>"><? echo $rows_submenu['submenu_name'] ?></div></li>
                             <?php
							$i++;
							}
							}
							}
							?>   
                            </ul>   
                        </li>
                        <?php
						$i++;
						}
						}
						}
						?> 
                        <li><div class="account-logout" link="<? echo URL_DIRECT?>">Logout</div></li>  
                    </ul>
        		</div>
           </div>
            	<div class="body">
                    <div class="sub-content">
                        <?php if($link) require_once($link.'.php') ?>
                    </div>
            	</div> 