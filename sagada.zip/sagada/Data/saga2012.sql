-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 13, 2012 at 01:48 PM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `puslit_saga`
--

-- --------------------------------------------------------

--
-- Table structure for table `data_grafik`
--

CREATE TABLE IF NOT EXISTS `data_grafik` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `anak_anak` int(5) NOT NULL,
  `remaja` int(5) NOT NULL,
  `dewasa` int(5) NOT NULL,
  `bulan` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `data_grafik`
--

INSERT INTO `data_grafik` (`id`, `anak_anak`, `remaja`, `dewasa`, `bulan`) VALUES
(1, 2, 3, 4, 1),
(2, 4, 5, 2, 2),
(3, 7, 4, 9, 3),
(4, 23, 45, 23, 4),
(5, 12, 65, 34, 5),
(6, 43, 23, 54, 6),
(7, 4, 9, 10, 7),
(8, 4, 23, 6, 8),
(9, 23, 76, 34, 9),
(10, 23, 4, 1, 10),
(11, 25, 63, 12, 11),
(12, 12, 64, 43, 12);

-- --------------------------------------------------------

--
-- Table structure for table `sensus`
--

CREATE TABLE IF NOT EXISTS `sensus` (
  `negara` varchar(20) NOT NULL DEFAULT '',
  `tahun` varchar(4) NOT NULL DEFAULT '',
  `jmlpria` int(11) DEFAULT NULL,
  `jmlwanita` int(11) DEFAULT NULL,
  PRIMARY KEY (`negara`,`tahun`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sensus`
--

INSERT INTO `sensus` (`negara`, `tahun`, `jmlpria`, `jmlwanita`) VALUES
('A', '1990', 20, 31),
('A', '1991', 41, 17),
('A', '1992', 52, 35),
('B', '1990', 30, 42),
('B', '1991', 24, 32),
('B', '1992', 12, 22),
('C', '1990', 32, 16),
('C', '1991', 34, 17),
('C', '1992', 34, 34);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_data`
--

CREATE TABLE IF NOT EXISTS `tbl_data` (
  `data_kode` int(15) NOT NULL AUTO_INCREMENT,
  `submenu_kode` int(5) DEFAULT NULL,
  `kota_kode` int(15) DEFAULT NULL,
  `jenjangpendidikan_kode` int(15) DEFAULT NULL,
  `kelumur_kode` int(15) DEFAULT NULL,
  `statusjob_kode` int(15) DEFAULT NULL,
  `kegjob_kode` int(15) DEFAULT NULL,
  `jenisjob_kode` int(15) DEFAULT NULL,
  `jobtime_kode` int(15) DEFAULT NULL,
  `kontrasepsi_kode` int(15) DEFAULT NULL,
  `narkoba_kode` int(15) DEFAULT NULL,
  `hk_kode` int(15) DEFAULT NULL,
  `jenisakt_kode` int(15) DEFAULT NULL,
  `jenissakit_kode` int(15) DEFAULT NULL,
  `jenistindakan_kode` int(15) DEFAULT NULL,
  `kasusjahat_kode` int(15) DEFAULT NULL,
  `parpol_kode` int(15) DEFAULT NULL,
  `tahun_kode` int(15) DEFAULT NULL,
  `perwiramenengah_kode` int(15) DEFAULT NULL,
  `perwirapertama_kode` int(15) DEFAULT NULL,
  `data_brigadir` char(1) DEFAULT NULL,
  `perwiratinggi_kode` int(15) DEFAULT NULL,
  `jabatanstruk_kode` int(15) DEFAULT NULL,
  `panggol_kode` int(15) DEFAULT NULL,
  `jenisusaha_kode` int(15) DEFAULT NULL,
  `data_kompres` tinyint(1) DEFAULT NULL,
  `data_laki` decimal(10,2) DEFAULT NULL,
  `data_perempuan` decimal(10,2) DEFAULT NULL,
  `data_nongender` decimal(10,2) DEFAULT NULL,
  `data_sumber` text,
  `data_operator` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`data_kode`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `tbl_data`
--

INSERT INTO `tbl_data` (`data_kode`, `submenu_kode`, `kota_kode`, `jenjangpendidikan_kode`, `kelumur_kode`, `statusjob_kode`, `kegjob_kode`, `jenisjob_kode`, `jobtime_kode`, `kontrasepsi_kode`, `narkoba_kode`, `hk_kode`, `jenisakt_kode`, `jenissakit_kode`, `jenistindakan_kode`, `kasusjahat_kode`, `parpol_kode`, `tahun_kode`, `perwiramenengah_kode`, `perwirapertama_kode`, `data_brigadir`, `perwiratinggi_kode`, `jabatanstruk_kode`, `panggol_kode`, `jenisusaha_kode`, `data_kompres`, `data_laki`, `data_perempuan`, `data_nongender`, `data_sumber`, `data_operator`) VALUES
(1, 16, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 10.00, 10.00, NULL, NULL, NULL),
(2, 16, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 7, 15.00, 12.00, NULL, NULL, NULL),
(3, 16, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL),
(4, 16, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, 1, NULL, NULL, NULL, 3, 20.00, 20.00, NULL, NULL, NULL),
(5, 16, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, 2, NULL, NULL, NULL, 3, 15.00, 12.00, NULL, NULL, NULL),
(6, 16, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, 3, NULL, NULL, NULL, 3, 12.00, 58.00, NULL, NULL, NULL),
(7, 61, 4, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1250.00, 1250.00, NULL, 'asd', 'asd'),
(9, 62, 7, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 15200.00, 125000.00, NULL, 'sdf', 'sdf'),
(10, 14, 7, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1520.00, 12540.00, NULL, 'sd', 'asd'),
(12, 32, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 100.00, 200.00, 300.00, 'sdf', 'sdf'),
(14, 65, 7, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 34.00, 234.00, 23.00, '423', '234'),
(15, 28, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1500.00, 2540.00, NULL, 'sdf', 'sdfsdf'),
(16, 3, 4, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 150.00, 254.00, NULL, 'sdf', 'sdf'),
(17, 3, 4, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 23.00, 234.00, NULL, '234', '234');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_headers`
--

CREATE TABLE IF NOT EXISTS `tbl_headers` (
  `header_kode` int(25) NOT NULL AUTO_INCREMENT,
  `header_photo_crop` varchar(255) DEFAULT NULL,
  `header_photo_small` varchar(255) DEFAULT NULL,
  `header_photo_large` varchar(255) DEFAULT NULL,
  `header_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`header_kode`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_hk`
--

CREATE TABLE IF NOT EXISTS `tbl_hk` (
  `hk_kode` int(15) NOT NULL AUTO_INCREMENT,
  `hk_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`hk_kode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_jabatanfung`
--

CREATE TABLE IF NOT EXISTS `tbl_jabatanfung` (
  `jabatanfung_kode` int(15) NOT NULL AUTO_INCREMENT,
  `jabatanfung_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`jabatanfung_kode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_jabatanstruk`
--

CREATE TABLE IF NOT EXISTS `tbl_jabatanstruk` (
  `jabatanstruk_kode` int(15) NOT NULL AUTO_INCREMENT,
  `jabatanstruk_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`jabatanstruk_kode`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_jabatanstruk`
--

INSERT INTO `tbl_jabatanstruk` (`jabatanstruk_kode`, `jabatanstruk_name`) VALUES
(1, 'Eselon I'),
(2, 'Eselon II'),
(3, 'Eselon III');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_jenisakt`
--

CREATE TABLE IF NOT EXISTS `tbl_jenisakt` (
  `jenisakt_kode` int(15) NOT NULL AUTO_INCREMENT,
  `jenisakt_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`jenisakt_kode`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_jenisakt`
--

INSERT INTO `tbl_jenisakt` (`jenisakt_kode`, `jenisakt_name`) VALUES
(1, 'asdasd');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_jenisjob`
--

CREATE TABLE IF NOT EXISTS `tbl_jenisjob` (
  `jenisjob_kode` int(15) NOT NULL AUTO_INCREMENT,
  `jenisjob_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`jenisjob_kode`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_jenisjob`
--

INSERT INTO `tbl_jenisjob` (`jenisjob_kode`, `jenisjob_name`) VALUES
(1, 'sapi'),
(2, 'we');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_jenissakit`
--

CREATE TABLE IF NOT EXISTS `tbl_jenissakit` (
  `jenissakit_kode` int(15) NOT NULL AUTO_INCREMENT,
  `jenissakit_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`jenissakit_kode`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_jenissakit`
--

INSERT INTO `tbl_jenissakit` (`jenissakit_kode`, `jenissakit_name`) VALUES
(1, 'asdasd');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_jenistindakan`
--

CREATE TABLE IF NOT EXISTS `tbl_jenistindakan` (
  `jenistindakan_kode` int(15) NOT NULL AUTO_INCREMENT,
  `jenistindakan_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`jenistindakan_kode`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_jenisusaha`
--

CREATE TABLE IF NOT EXISTS `tbl_jenisusaha` (
  `jenisusaha_kode` int(15) NOT NULL AUTO_INCREMENT,
  `jenisusaha_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`jenisusaha_kode`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_jenisusaha`
--

INSERT INTO `tbl_jenisusaha` (`jenisusaha_kode`, `jenisusaha_name`) VALUES
(1, 'asdasd sdf');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_jenjangpendidikan`
--

CREATE TABLE IF NOT EXISTS `tbl_jenjangpendidikan` (
  `jenjangpendidikan_kode` int(15) NOT NULL AUTO_INCREMENT,
  `jenjangpendidikan_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`jenjangpendidikan_kode`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_jenjangpendidikan`
--

INSERT INTO `tbl_jenjangpendidikan` (`jenjangpendidikan_kode`, `jenjangpendidikan_name`) VALUES
(1, 'SD'),
(2, 'SMP'),
(3, 'SMA'),
(4, 'SARJANA');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_jobtime`
--

CREATE TABLE IF NOT EXISTS `tbl_jobtime` (
  `jobtime_kode` int(15) NOT NULL AUTO_INCREMENT,
  `jobtime_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`jobtime_kode`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_jobtime`
--

INSERT INTO `tbl_jobtime` (`jobtime_kode`, `jobtime_name`) VALUES
(1, 'pagi'),
(2, 'sa');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kasusjahat`
--

CREATE TABLE IF NOT EXISTS `tbl_kasusjahat` (
  `kasusjahat_kode` int(15) NOT NULL AUTO_INCREMENT,
  `kasusjahat_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`kasusjahat_kode`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `tbl_kasusjahat`
--

INSERT INTO `tbl_kasusjahat` (`kasusjahat_kode`, `kasusjahat_name`) VALUES
(1, 'Kepemilikan Senjata Tajam,'),
(2, ' Narkoba,'),
(3, ' Pemerkosaan/Pencabulan'),
(4, 'Pengeroyokan'),
(5, 'Pembunuhan'),
(6, 'Penganiyaan'),
(7, 'Lakalantas Fatal'),
(8, 'Pencurian'),
(9, 'Pemerasan'),
(10, 'Penggelapan'),
(11, ' Penadah hasil kejahatan'),
(12, 'Tindak pidana lainnya');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kegjob`
--

CREATE TABLE IF NOT EXISTS `tbl_kegjob` (
  `kegjob_kode` int(15) NOT NULL AUTO_INCREMENT,
  `kegjob_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`kegjob_kode`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_kegjob`
--

INSERT INTO `tbl_kegjob` (`kegjob_kode`, `kegjob_name`) VALUES
(1, 'asss');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kelumur`
--

CREATE TABLE IF NOT EXISTS `tbl_kelumur` (
  `kelumur_kode` int(15) NOT NULL AUTO_INCREMENT,
  `kelumur_dari` varchar(15) DEFAULT NULL,
  `kelumur_status` int(1) DEFAULT NULL,
  PRIMARY KEY (`kelumur_kode`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `tbl_kelumur`
--

INSERT INTO `tbl_kelumur` (`kelumur_kode`, `kelumur_dari`, `kelumur_status`) VALUES
(1, '15-19', 1),
(2, '20-24', 1),
(3, '25-29', 1),
(4, '30-34', 1),
(5, '35-39', 1),
(6, '40-44', 1),
(7, '45+', 1),
(8, '6-12', 2),
(9, '13-15', 2),
(10, '16-18', 2),
(11, '19+', 2),
(12, '10-14', 3),
(13, '15-19', 3),
(14, '20-24', 3),
(15, '25-29', 3),
(16, '30-34', 3),
(17, '6 Tahun', 4),
(18, '9 Tahun', 4),
(19, '12 Tahun', 4),
(20, '13 th – 17 th', 5),
(21, '18thn Keatas', 5);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kontrasepsi`
--

CREATE TABLE IF NOT EXISTS `tbl_kontrasepsi` (
  `kontrasepsi_kode` int(15) NOT NULL AUTO_INCREMENT,
  `kontrasepsi_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`kontrasepsi_kode`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_kontrasepsi`
--

INSERT INTO `tbl_kontrasepsi` (`kontrasepsi_kode`, `kontrasepsi_name`) VALUES
(1, 'Pil KB');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kota`
--

CREATE TABLE IF NOT EXISTS `tbl_kota` (
  `kota_kode` int(15) NOT NULL AUTO_INCREMENT,
  `kota_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`kota_kode`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `tbl_kota`
--

INSERT INTO `tbl_kota` (`kota_kode`, `kota_name`) VALUES
(1, 'Jayapura'),
(2, 'Intan Jaya'),
(3, 'Dogiyai'),
(4, 'Deiyai'),
(5, 'Boven Digoel'),
(6, 'Biak Numfor'),
(7, 'Asmat');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_menu`
--

CREATE TABLE IF NOT EXISTS `tbl_menu` (
  `menu_kode` int(5) NOT NULL AUTO_INCREMENT,
  `menu_name` varchar(255) DEFAULT NULL,
  `menu_view` text,
  `menu_icon` varchar(255) DEFAULT NULL,
  `menu_link` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`menu_kode`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=152 ;

--
-- Dumping data for table `tbl_menu`
--

INSERT INTO `tbl_menu` (`menu_kode`, `menu_name`, `menu_view`, `menu_icon`, `menu_link`) VALUES
(1, 'Home', NULL, 'nav-master', 'library/menu/home'),
(2, 'Master', NULL, 'nav-data', 'library/menu/Master'),
(3, 'Data', NULL, 'nav-pengumuman', 'library/menu/data'),
(4, 'Bidang Pendidikan', NULL, 'nav-biddik', 'library/menu/biddik'),
(27, 'Management User', NULL, 'nav-user', 'library/menu/user'),
(5, 'Bidang  Ekonomi  dan Tenaga Kerja', NULL, 'nav-bidek', 'library/menu/bidek'),
(6, 'Bidang Politik & Ambil Keputusan', NULL, 'nav-bidek', 'library/menu/bidek'),
(7, 'Bidang Hukum dan Sosial Budaya', NULL, 'nav-bidek', 'library/menu/bidek'),
(8, 'Kekerasan Perempuan dan Anak', NULL, 'nav-bidek', 'library/menu/bidek'),
(9, 'Bidang Kesehatan', NULL, 'nav-bidek', 'library/menu/bidek'),
(10, 'Laporan Angka', NULL, 'nav-bidek', 'library/menu/laporan'),
(28, 'Management System', NULL, 'nav-user', 'library/menu/user'),
(11, 'Laporan Grafik', NULL, 'nav-bidek', 'library/menu/laporan');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_modul`
--

CREATE TABLE IF NOT EXISTS `tbl_modul` (
  `modul_kode` int(5) NOT NULL AUTO_INCREMENT,
  `modul_name` varchar(100) DEFAULT NULL,
  `modul_header` text,
  PRIMARY KEY (`modul_kode`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_modul`
--

INSERT INTO `tbl_modul` (`modul_kode`, `modul_name`, `modul_header`) VALUES
(1, 'administrator system', 'Administrator\r\nMINU Plus Islamiyah\r\nSistem Informasi Murid dan Pegawai\r\n\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_narkoba`
--

CREATE TABLE IF NOT EXISTS `tbl_narkoba` (
  `narkoba_kode` int(15) NOT NULL AUTO_INCREMENT,
  `narkoba_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`narkoba_kode`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_narkoba`
--

INSERT INTO `tbl_narkoba` (`narkoba_kode`, `narkoba_name`) VALUES
(1, 'Sabu-sabu');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_panggol`
--

CREATE TABLE IF NOT EXISTS `tbl_panggol` (
  `panggol_kode` int(15) NOT NULL AUTO_INCREMENT,
  `panggol_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`panggol_kode`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_panggol`
--

INSERT INTO `tbl_panggol` (`panggol_kode`, `panggol_name`) VALUES
(1, 'Gol I');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_parpol`
--

CREATE TABLE IF NOT EXISTS `tbl_parpol` (
  `parpol_kode` int(15) NOT NULL AUTO_INCREMENT,
  `parpol_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`parpol_kode`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_parpol`
--

INSERT INTO `tbl_parpol` (`parpol_kode`, `parpol_name`) VALUES
(1, 'golkar');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_permissions`
--

CREATE TABLE IF NOT EXISTS `tbl_permissions` (
  `permissions_kode` int(5) NOT NULL AUTO_INCREMENT,
  `user_kode` int(5) DEFAULT NULL,
  `menu_kode` int(5) DEFAULT NULL,
  `submenu_kode` int(5) DEFAULT NULL,
  `permissions_view` varchar(5) DEFAULT NULL,
  `permissions_add` varchar(5) DEFAULT NULL,
  `permissions_edit` varchar(5) DEFAULT NULL,
  `permissions_delete` varchar(5) DEFAULT NULL,
  `permissions_grant` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`permissions_kode`),
  KEY `fk_reference_1` (`user_kode`),
  KEY `fk_reference_5` (`menu_kode`),
  KEY `fk_reference_6` (`submenu_kode`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_permissions`
--

INSERT INTO `tbl_permissions` (`permissions_kode`, `user_kode`, `menu_kode`, `submenu_kode`, `permissions_view`, `permissions_add`, `permissions_edit`, `permissions_delete`, `permissions_grant`) VALUES
(1, 59882, 27, NULL, '1', NULL, NULL, NULL, NULL),
(2, 59882, NULL, 9, '1', '1', '1', '1', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_perwiramenengah`
--

CREATE TABLE IF NOT EXISTS `tbl_perwiramenengah` (
  `perwiramenengah_kode` int(15) NOT NULL AUTO_INCREMENT,
  `perwiramenengah_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`perwiramenengah_kode`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_perwiramenengah`
--

INSERT INTO `tbl_perwiramenengah` (`perwiramenengah_kode`, `perwiramenengah_name`) VALUES
(1, 'Komisaris Besar Polisi'),
(2, 'Ajuk Komisaris Besar Polisi'),
(3, 'Komisaris Polisi s');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_perwirapertama`
--

CREATE TABLE IF NOT EXISTS `tbl_perwirapertama` (
  `perwirapertama_kode` int(15) NOT NULL AUTO_INCREMENT,
  `perwirapertama_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`perwirapertama_kode`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_perwirapertama`
--

INSERT INTO `tbl_perwirapertama` (`perwirapertama_kode`, `perwirapertama_name`) VALUES
(1, 'Ajun Komosaris Polisi'),
(2, 'Inspektur Satu Polisi'),
(3, 'Inspektur Dua Polisi');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_perwiratinggi`
--

CREATE TABLE IF NOT EXISTS `tbl_perwiratinggi` (
  `perwiratinggi_kode` int(15) NOT NULL AUTO_INCREMENT,
  `perwiratinggi_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`perwiratinggi_kode`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_perwiratinggi`
--

INSERT INTO `tbl_perwiratinggi` (`perwiratinggi_kode`, `perwiratinggi_name`) VALUES
(1, 'Jenderal Polisi'),
(2, 'Inspektur Jenderal Polisi'),
(3, 'Brigeder Jenderal Polisi sd');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_priodejabatan`
--

CREATE TABLE IF NOT EXISTS `tbl_priodejabatan` (
  `priodejabatan_kode` int(15) NOT NULL AUTO_INCREMENT,
  `priodejabatan_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`priodejabatan_kode`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_priodejabatan`
--

INSERT INTO `tbl_priodejabatan` (`priodejabatan_kode`, `priodejabatan_name`) VALUES
(2, 'asdasdasdasdasdas');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_statusjob`
--

CREATE TABLE IF NOT EXISTS `tbl_statusjob` (
  `statusjob_kode` int(15) NOT NULL AUTO_INCREMENT,
  `statusjob_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`statusjob_kode`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_statusjob`
--

INSERT INTO `tbl_statusjob` (`statusjob_kode`, `statusjob_name`) VALUES
(1, 'kontrak'),
(2, 'Karyawan');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_submenu`
--

CREATE TABLE IF NOT EXISTS `tbl_submenu` (
  `submenu_kode` int(5) NOT NULL AUTO_INCREMENT,
  `modul_kode` int(5) DEFAULT NULL,
  `menu_kode` int(5) DEFAULT NULL,
  `submenu_name` varchar(255) DEFAULT NULL,
  `submenu_icon` varchar(255) DEFAULT NULL,
  `menusub_link` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`submenu_kode`),
  KEY `fk_reference_3` (`modul_kode`),
  KEY `fk_reference_4` (`menu_kode`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=72 ;

--
-- Dumping data for table `tbl_submenu`
--

INSERT INTO `tbl_submenu` (`submenu_kode`, `modul_kode`, `menu_kode`, `submenu_name`, `submenu_icon`, `menusub_link`) VALUES
(1, 1, 1, 'Gambaran System', 'home', 'library/submenu/home/index'),
(2, 1, 2, 'Kab/Kota/Provinsi', 'home', 'library/submenu/master/kota'),
(3, 1, 4, 'Angka Partisipasi Kasar (APK)', 'home', 'library/submenu/data/apk'),
(4, 1, 4, 'Angka Partisipasi Sekolah (APS)', 'home', 'library/submenu/data/aps'),
(5, 1, 4, 'Angka Partisipasi Murni ( APM )', 'home', 'library/submenu/data/apm'),
(6, 1, 4, 'Angka Melek Huruf ( AMH )', 'home', 'library/submenu/data/amh'),
(7, 1, 4, 'Angka Putus Sekolah', 'home', 'library/submenu/data/apsk'),
(8, 1, 4, 'Rata - Rata Lama Sekolah', 'home', 'library/submenu/data/rls'),
(9, 1, 5, 'Tingkat  Partisipasi  Angkatan Kerja  (TPAK)', 'home', 'library/submenu/data/tpak'),
(10, 1, 5, 'Penduduk  Usia  Kerja Yang  Bekerja  Menurut  Status  Pekerjaan', 'home', 'library/submenu/data/puksp'),
(11, 1, 5, 'Penduduk  Usia  Kerja', 'home', 'library/submenu/data/puk'),
(12, 1, 5, 'Pekerja  Formal  dan  Informal ', 'home', 'library/submenu/data/pfdi'),
(13, 1, 5, 'Tingkat Pengangguran Terbuka ( TPT )', 'home', 'library/submenu/data/tpt'),
(14, 1, 5, 'Setengah  Pengangguran', 'home', 'library/submenu/data/sp'),
(15, 1, 6, 'Legislatif', 'home', 'library/submenu/data/legislatif'),
(16, 1, 6, 'Yudikatif', 'home', 'library/submenu/data/yudikatif'),
(17, 1, 6, 'Eksekutif', 'home', 'library/submenu/data/eksekutif'),
(18, 1, 6, 'Camat', 'home', 'library/submenu/data/camat'),
(19, 1, 6, 'Lurah', 'home', 'library/submenu/data/lurah'),
(20, 1, 6, 'Kepala Kampung', 'home', 'library/submenu/data/kakampung'),
(21, 1, 6, 'Keanggotaan Parpol', 'home', 'library/submenu/data/parpol'),
(22, 1, 7, 'Penghuni Lemb Pemasyarakatan', 'home', 'library/submenu/data/plp'),
(23, 1, 7, 'Penghuni Rumah Tahanan (Rutan) ', 'home', 'library/submenu/data/rutan'),
(24, 1, 7, 'Penduduk Lansia', 'home', 'library/submenu/data/pl'),
(25, 1, 7, 'Penyandang Catat', 'home', 'library/submenu/data/pc'),
(26, 1, 8, 'Korban', 'home', 'library/submenu/data/korban'),
(27, 1, 8, 'Pelaku', 'home', 'library/submenu/data/pelaku'),
(28, 1, 9, 'Angka Harapan Hidup', 'home', 'library/submenu/data/ahp'),
(29, 1, 9, 'Angka Kematian Ibu Melahirkan', 'home', 'library/submenu/data/akim'),
(30, 1, 9, 'Imunisasi TT pada Ibu Hamil', 'home', 'library/submenu/data/ittih'),
(31, 1, 9, 'Ibu Hamil yang mendapatkan tablet Zat Besi (Fe)', 'home', 'library/submenu/data/fe'),
(67, 1, 28, 'Header System', 'home', 'library/submenu/web/header-system'),
(33, 1, 9, 'Keluarga Berencana', 'home', 'library/submenu/data/kb'),
(34, 1, 9, 'Narkoba', 'home', 'library/submenu/data/narkoba'),
(35, 1, 2, 'Tahun', 'home', 'library/submenu/master/tahun'),
(36, 1, 2, 'Jenjang Pendidikan', 'home', 'library/submenu/master/jenjangpendidikan'),
(37, 1, 9000, 'Kelompok Umur', 'home', 'library/submenu/master/kelumur'),
(38, 1, 2, 'Status Pekerjaan', 'home', 'library/submenu/master/statusjob'),
(39, 1, 2, 'Jenis Pekerjaan', 'home', 'library/submenu/master/jenisjob'),
(40, 1, 2, 'Jam Kerja', 'home', 'library/submenu/master/jobtime'),
(42, 1, 2, 'Partai Politik', 'home', 'library/submenu/master/parpol'),
(41, 1, 2, 'Kegiatan Kerja', 'home', 'library/submenu/master/kegjob'),
(44, 1, 2, 'Priode Jabatan', 'home', 'library/submenu/master/priodejabatan'),
(45, 1, 2, 'Jabatan Struktural', 'home', 'library/submenu/master/jabatanstruk'),
(46, 1, 2, 'Jabatan Fungsional', 'home', 'library/submenu/master/jabatanfung'),
(47, 1, 2, 'Pangkat Gol', 'home', 'library/submenu/master/panggol'),
(48, 1, 2, 'Kasus Kejahatan', 'home', 'library/submenu/master/kasusjahat'),
(49, 1, 2, 'Jenis Aktifitas', 'home', 'library/submenu/master/jenisakt'),
(50, 1, 2, 'Jenis Sakit', 'home', 'library/submenu/master/jenissakit'),
(51, 1, 2, 'Jenis Tindakan', 'home', 'library/submenu/master/jenistindakan'),
(52, 1, 27, 'Management User', 'home', 'library/submenu/user/daftar-user'),
(53, 1, 2, 'Hubungan Keluarga', 'home', 'library/submenu/master/hk'),
(54, 1, 2, 'Jenis Kontrasepsi', 'home', 'library/submenu/master/kontrasepsi'),
(55, 1, 2, 'Jenis Narkoba', 'home', 'library/submenu/master/narkoba'),
(56, 1, 2, 'Perwira Tinggi', 'home', 'library/submenu/master/perwiratinggi'),
(57, 1, 2, 'Perwira Menangah', 'home', 'library/submenu/master/perwiramenengah'),
(58, 1, 2, 'Perwira Pertama', 'home', 'library/submenu/master/perwirapertama'),
(59, 1, 10, 'Laporan Per Bidang', 'home', 'library/submenu/data/laporan-perbidang'),
(60, 1, 11, 'Grafik Per Bidang', 'home', 'library/submenu/data/grafik-perbidang'),
(61, 1, 4, 'Jenis Pendidikan yang di tamatkan ', 'home', 'library/submenu/data/pmjpyd'),
(62, 1, 5, 'Usaha Mikro dan Kecil ( UMK)', 'home', 'library/submenu/data/umk'),
(63, 1, 2, 'Jenis Usaha', 'home', 'library/submenu/master/jenisusaha'),
(64, 1, 5, 'Pemeriman Kredit/Pinjaman Bank', 'home', 'library/submenu/data/pkpb'),
(65, 1, 9, 'Penderita HIV', 'home', 'library/submenu/data/hiv'),
(66, 1, 9, 'Penderita Aids', 'home', 'library/submenu/data/aids'),
(70, 1, 10, 'Laporan Semua Bidang', 'home', 'library/submenu/data/laporan-all'),
(69, 1, 28, 'Gambaran System', 'home', 'library/submenu/web/gambaran-system'),
(71, 1, 11, 'Grafik Semua Bidang', 'home', 'library/submenu/data/grafik-all');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tahun`
--

CREATE TABLE IF NOT EXISTS `tbl_tahun` (
  `tahun_kode` int(15) NOT NULL AUTO_INCREMENT,
  `tahun_name` int(4) DEFAULT NULL,
  PRIMARY KEY (`tahun_kode`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `tbl_tahun`
--

INSERT INTO `tbl_tahun` (`tahun_kode`, `tahun_name`) VALUES
(1, 2007),
(2, 2008),
(3, 2009),
(4, 2010),
(5, 2011),
(6, 2012),
(7, 2013);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `user_kode` int(25) NOT NULL AUTO_INCREMENT,
  `modul_kode` int(5) DEFAULT NULL,
  `user_full_name` varchar(100) DEFAULT NULL,
  `user_alamat` varchar(100) DEFAULT NULL,
  `user_tempat_lahir` varchar(255) DEFAULT NULL,
  `user_tgl_lahir` date DEFAULT NULL,
  `user_gender` char(1) DEFAULT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `user_phone` varchar(15) DEFAULT NULL,
  `user_photo_crop` varchar(255) DEFAULT NULL,
  `user_photo_small` varchar(255) DEFAULT NULL,
  `user_photo_large` varchar(255) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `user_pass` varchar(255) DEFAULT NULL,
  `user_type` char(1) DEFAULT NULL,
  PRIMARY KEY (`user_kode`),
  KEY `fk_relationship_23` (`modul_kode`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2147483648 ;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`user_kode`, `modul_kode`, `user_full_name`, `user_alamat`, `user_tempat_lahir`, `user_tgl_lahir`, `user_gender`, `user_email`, `user_phone`, `user_photo_crop`, `user_photo_small`, `user_photo_large`, `user_name`, `user_pass`, `user_type`) VALUES
(1, 1, 'ADMIN SAGA', 'saga', 'saga', '2012-05-02', '0', 'puslit.indonesia@yahoo.com', '081357938303', 'd13dd8c0bef644a75d48e18129b5b9d9.jpg', 'a8a8718e692af86dbaae8be3f67eec4f.jpg', 'd13dd8c0bef644a75d48e18129b5b9d9.jpg', 'admin', 'c9e023417fa66e852e4d1f920c051017', '0'),
(59882, 1, 'contoh', 'coba', 'coba', NULL, '0', 'coba@test.com', '0123456789', NULL, NULL, NULL, 'sdf', 'd58e3582afa99040e27b92b13c8f2280', '2');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
