<script type="text/javascript">
 $(document).ready(function(){
   $(".ctable tr").mouseover(function(){$(this).addClass("over");}).mouseout(function(){$(this).removeClass("over");});
   $(".ctable tr:even").addClass("alt");
 });
 </script>
 <?php
/////// konfigurasi
///// query untuk paging

if(file_exists('../../connectionmysql.php')) {
	require_once '../../connectionmysql.php';
	Connected();	
}

$perm = array();
$perm = getPermissions('17');

if(file_exists('../../error-menu.php')) if($perm[-1]=='1') { require_once '../../error-menu.php'; die; }

?>
 
                    <div class="sub-content-title sub-apk">Laporan Saga</div>
                    
                	<div class="cboxtable">
                    	<div class="sub-content-bar">
                        <form action="modul/laporan/laporan-all.php"  method="post">
                        <table width="100%">
                        <tr>
                        <td valign="top" width="15%"><div style="margin-top:4px;">Kertas</div></td>
                        <td valign="top" width="1%" align="center"><div style="margin-top:4px;">:</div></td>
                        <td valign="top">
                        	<select name="kertas_bentuk" class="select-text">
                            <option value="A4">A4</option>
                            <option value="legal">Legal</option>
							
                          </select>                          
                        </td>
                        </tr>
                        
                        <tr>
                        <td valign="top" width="15%"><div style="margin-top:4px;">Bentuk</div></td>
                        <td valign="top" width="1%" align="center"><div style="margin-top:4px;">:</div></td>
                        <td valign="top">
                        	<select name="tahun_bentuk" class="select-text">
                            <option value="L">Landscape</option>
                            <option value="P">Portrait</option>
							
                          </select>                          
                        </td>
                        </tr>
                        <tr>
                          <td width="25%">Kota/Kabupaten</td>
                          <td width="5%" align="center">:</td>
                          <td><select name="kota_kode" class="select-text select-small">
                            <option value="">Pilih..</option>
                          <? 	  
                         
                          $qry_kota = "select * from tbl_kota order by kota_name ASC;";	  
                          $rs_kota = mysql_query($qry_kota);
                          while($rows_kota=mysql_fetch_array($rs_kota)) {
                          ?>
                            <option value="<? echo $rows_kota['kota_kode']?>"><? echo $rows_kota['kota_name']; ?></option>
                          <? } ?>
                          </select></td>
                        </tr>
                        <tr>
                        <td valign="top" width="15%"><div style="margin-top:4px;">Sampai Tahun</div></td>
                        <td valign="top" width="1%" align="center"><div style="margin-top:4px;">:</div></td>
                        <td valign="top">
                        	<select name="tahun_sampai" class="select-text">
                            <option value="">Pilih..</option>
							<? 
                              $rs_tahunsampai= mysql_query("select * from tbl_tahun Order BY tahun_name ASC");
                              while($rows_tahunsampai=mysql_fetch_array($rs_tahunsampai)) {
                            ?>
                            <option value="<? echo $rows_tahunsampai['tahun_kode']?>" ><? echo $rows_tahunsampai['tahun_name']; ?></option>
                          	<? } ?>
                          </select>
                          <div print="3" style="margin-left: 7px;" class="print-button">Cetak PDF</div>
                          
                        </td>
                        </tr>
                        </table>
						</form>
                        
                        </div>
						
                    	
                        
                        
                    </div>

