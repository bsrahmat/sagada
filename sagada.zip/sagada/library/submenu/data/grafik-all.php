<script type="text/javascript">
 $(document).ready(function(){
   $(".ctable tr").mouseover(function(){$(this).addClass("over");}).mouseout(function(){$(this).removeClass("over");});
   $(".ctable tr:even").addClass("alt");
 });
 </script>
 <?php
/////// konfigurasi
///// query untuk paging

if(file_exists('../../connectionmysql.php')) {
	require_once '../../connectionmysql.php';
	Connected();	
}

$perm = array();
$perm = getPermissions('60');

if(file_exists('../../error-menu.php')) if($perm[-1]=='1') { require_once '../../error-menu.php'; die; }

?>
 
                   <div class="sub-content-title">Grafik Bidang Kesehatan</div>
                    <div class="cboxtable"> 
                        <div class="sub-content-bar">
                            <div class="cview-button" title="Grafik" link="library/submenu/data/detail/ahp">Angka Harapan Hidup</div>
                            <div class="cview-button" title="Grafik" link="library/submenu/data/detail/akim">Jumlah Kematian Ibu Melahirkan</div>
                            <div class="cview-button" title="Grafik" link="library/submenu/data/detail/itih">Imunisasi TT pada Ibu Hamil</div>
                            
                        </div>
                         <div class="sub-content-bar">                            
                            <div class="cview-button" title="Grafik" link="library/submenu/data/detail/fe">Ibu Hamil yang mendapatkan tablet Zat Besi (Fe)</div>
                            <div class="cview-button" title="Grafik" link="library/submenu/data/detail/aids">Penderita HIV/AIDS</div>
                        </div>
                        <div class="sub-content-bar">                            
                            <div class="cview-button" title="Grafik" link="library/submenu/data/detail/kb">Keluarga Berencana</div>
                            <div class="cview-button" title="Grafik" link="library/submenu/data/detail/narkoba">Narkoba</div>
                        </div>
                    </div>
                                         
                     
                    <div class="sub-content-title">Grafik Bidang Ekonomi dan Ketenagakerjaan</div>
                    <div class="cboxtable"> 
                        <div class="sub-content-bar">
                            <div class="cview-button" title="Grafik" link="library/submenu/data/detail/tpak">Tingkat Partisipasi Angkatan Kerja (TPAK)</div>
                            <div class="cview-button" title="Grafik" link="library/submenu/data/detail/puksp">Penduduk Usia Kerja Yang Bekerja Menurut Status Pekerjaan</div>
                            
                        </div>
                         <div class="sub-content-bar">                            
                            <div class="cview-button" title="Grafik" link="library/submenu/data/detail/puk">Penduduk Usia Kerja</div>
                            <div class="cview-button" title="Grafik" link="library/submenu/data/detail/pfdi">Pekerja Formal dan Informal</div>
                        </div>
                        <div class="sub-content-bar">                            
                            <div class="cview-button" title="Grafik" link="library/submenu/data/detail/tpt">Tingkat Pengangguran Terbuka ( TPT )</div>
                            <div class="cview-button" title="Grafik" link="library/submenu/data/detail/sp">Setengah Pengangguran</div>
                        </div>
                    </div>       

