<?php
/////// konfigurasi
///// query untuk paging
if(file_exists('../../../connectionmysql.php')) {
	require_once '../../../connectionmysql.php';
	Connected();
}

$perm = array();
$perm = getPermissions('60');

if(file_exists('../../error-menu.php')) if($perm[-1]=='1') { require_once '../../error-menu.php'; die;}
//BAGIAN INPUTAN PENCARIAN
//Fungsi STRIPSTRING berfungsi hanya karakter a-z, A-Z, dan angka 0-9 yang diperbolehkan.

/////////////// ending konfigurasi
////////////// process
?>
 
                   
<div class="sub-content-title"  id="sub-master">Pekerja Formal dan Informal</div>
<div class="cboxtable">
	<?php
	
		
	?> 
   <script type="text/javascript">
$(function () {
    var chart;
    $(document).ready(function() {
        chart = new Highcharts.Chart({
            chart: {
                renderTo: 'diagram-saga',
                type: 'column'
            },
            title: {
                text: 'Pekerja Formal dan Informal'
            },
            subtitle: {
                text: 'Sistem Informasi Gender dan Anak Papua'
            },
            xAxis: {
                categories: [	
				<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
								echo $rows_tahun['tahun_name'].',';
				  } ?>
                ]
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Jumlah'
                }
            },
            legend: {
                layout: 'vertical',
                backgroundColor: '#FFFFFF',
                align: 'left',
                verticalAlign: 'top',
                x: 100,
                y: 70,
                floating: true,
                shadow: true
            },
            tooltip: {
                formatter: function() {
                    return ''+
                        this.x +': '+ this.y +' Orang';
                }
            },
            plotOptions: {
                column: {
                    pointPadding: 0.2,
                    borderWidth: 0
                }
            },
                series: [{
                name: 'Laki-laki',
                data: [
				  <? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_laki=mysql_fetch_array(mysql_query("select sum(data_laki) AS data_laki from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND submenu_kode = '12'"));
					echo $rows_laki['data_laki'].'0,';								
		  
				  } ?>]
    
            }, {
                name: 'Perempuan',
                data: [<? 
				  $rs_tahun= mysql_query("select * from tbl_tahun ORDER BY tahun_kode ASC");
				  while($rows_tahun=mysql_fetch_array($rs_tahun)) {
					$rows_perem=mysql_fetch_array(mysql_query("select sum(data_perempuan) AS data_perempuan from tbl_data WHERE tahun_kode = '".$rows_tahun['tahun_kode']."' AND submenu_kode = '12'"));
					echo $rows_perem['data_perempuan'].'0,';								
		  
				  } ?>]
    
            }]
        });
    });
    
});
		</script>
   <div class="box-papers"><div id="diagram-saga" style="min-width: 680px; height: 480px; margin: 0 auto"></div></div>
	<script src="js/modules/exporting.js"></script>
		</div>