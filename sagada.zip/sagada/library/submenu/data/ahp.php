<script type="text/javascript">
 $(document).ready(function(){
   $(".ctable tr").mouseover(function(){$(this).addClass("over");}).mouseout(function(){$(this).removeClass("over");});
   $(".ctable tr:even").addClass("alt");
 });
 </script>
 <?php
/////// konfigurasi
///// query untuk paging

if(file_exists('../../connectionmysql.php')) {
	require_once '../../connectionmysql.php';
	Connected();	
}

$perm = array();
$perm = getPermissions('28');

if(file_exists('../../error-menu.php')) if($perm[-1]=='1') { require_once '../../error-menu.php'; die; }

//BAGIAN INPUTAN PENCARIAN
//Fungsi STRIPSTRING berfungsi hanya karakter a-z, A-Z, dan angka 0-9 yang diperbolehkan.
$get_search = '';
$search = '';
$search_name = 'Pencarian...';
$year = date('Y');

if(isset($_GET['search'])) {
	$_GET['search'] = stripString($_GET['search']);
	$search_name = $_GET['search'];
	
	if($_GET['search'] || $_GET['search'] != 'Pencarian...' || $_GET['search'] != '') {
		$search = "AND LOWER(tbl_data.data_name) LIKE '%".strtolower($_GET['search'])."%'";
		$get_search = '&search='.strtolower($_GET['search']);
	}
}

$rs_count = mysql_query("select * from tbl_data JOIN tbl_submenu ON (tbl_data.submenu_kode = tbl_submenu.submenu_kode) JOIN tbl_kota ON (tbl_data.kota_kode = tbl_kota.kota_kode) JOIN tbl_tahun ON (tbl_data.tahun_kode = tbl_tahun.tahun_kode) WHERE tbl_data.submenu_kode = '28' ".$search);
$count  = mysql_num_rows($rs_count);

// variabel paging
$acc = 3;
$page  = (isset($_GET['p']))?( (is_numeric($_GET['p']))?( $page = $_GET['p']): $page = 1 ): $page = 1;
$limit = 20;
$start = $limit * ($page - 1);

$pager = new pagination();
$pager->currentPage 	= $page;
$pager->total			= $count;
$pager->limit			= $limit;
$pager->baseLink		= 'library/submenu/data/ahp?p=';
$pager->getHalaman(); 
/// output variabel paging
$selPrev = ($page==$pager->PagePrev )?"-selected":'';
$PevLink = 'link="'. $pager->LinkPrev.$get_search.'"';

$selNext	= ($page==$pager->PageNext )?"-selected":'';
$NextLink	= 'link="'. $pager->LinkNext.$get_search.'"';

//query untuk isi
$rs_data = mysql_query("select * from tbl_data JOIN tbl_submenu ON (tbl_data.submenu_kode = tbl_submenu.submenu_kode) JOIN tbl_kota ON (tbl_data.kota_kode = tbl_kota.kota_kode) JOIN tbl_tahun ON (tbl_data.tahun_kode = tbl_tahun.tahun_kode) WHERE tbl_data.submenu_kode = '28' ".$search." order by tbl_data.data_kode DESC limit $limit offset $start;");

/////////////// ending konfigurasi
////////////// process
?>
 
                    <div class="sub-content-title sub-apk">Angka Harapan Hidup</div>
                    
                	<div class="cboxtable">
                    	<div class="sub-content-bar">
                        	<? if($perm[0]!='1') { ?>
                        	<div class="input-button" type="popup" mode="0" link="modul/data/ahp?acc=<? echo $_GET['acc'] ?>">Tambah Baru</div>
                            <? } else { ?>
                            <div class="disabled-input-button">Tambah Baru</div>
                            <? } ?>
                            
                            <? if($perm[2]!='1') { $disabled = ''; ?>
                            <div class="input-button" type="popup" mode="4" link="modul/data/ahp">Hapus</div>
                            <? } else { $disabled='disabled'; ?>
                            <div class="disabled-input-button">Hapus</div>
                            <? } ?>                           
                            
                                                      
                            <div class="search-button" link="library/submenu/data/ahp">Cari</div>
                            <input id="foc-now" class="search-input" type="text" value="<? echo $search_name; ?>"  />

                        </div>
                    
                    	                        
                    	<table class="ctable">
                        <tr class="ctableheader">
                            <td width="1%"><input name="mainchk" type="checkbox" value="" <? echo $disabled ?> /></td>                           
                            <td>Kota</td>
                            <td width="10%">Tahun</td>
                            <td width="10%">Laki-laki</td>
                            <td width="10%">Perempuan</td>
                            
                            <td align="center" width="2%">Actions</td>
                            
                          
                        </tr>
                        <?php
							$no= $start+1;
							while($rows_data=mysql_fetch_array($rs_data)) {
									
						?>
                        <tr>
                          <td align="center"><input name="chkbox[]" type="checkbox" value="<? echo $rows_data['data_kode'] ?>" <? echo $disabled ?> /></td>
                            <td class="ltext" valign="top"><? echo $rows_data['kota_name'] ?></td>
                            <td valign="top"><? echo $rows_data['tahun_name'] ?></td>
                            <td class="rtext" valign="top"><? echo cFormat($rows_data['data_laki'], false) ?></td>
                            <td class="rtext" valign="top"><? echo cFormat($rows_data['data_perempuan'], false) ?></td>
                            
                           <td>
                            	<div class="cactions two">
                                <? if($perm[1]!='1') { ?>
                            	<div class="cedit" type="popup" mode="1" title="Edit" link="modul/data/ahp?<? echo $rows_data['data_kode'] ?>&acc=<? echo $_GET['acc'] ?>"></div>
                                <? } else { ?>
                            	<div class="disabled-cedit"></div>
                            	<? } ?>
                                <? if($perm[2]!='1') { ?>
                                <div link="modul/data/ahp?<? echo $rows_data['data_kode'] ?>" title="Hapus" mode="2" type="popup" class="cdelete"></div>
                            	<? } else { ?>
                            	<div class="disabled-cdelete"></div>
                            	<? } ?>
                                </div>
                            </td>
                      
                        </tr>
						<?php
							}
						?>
                        </table>
                        
                        <div class="ctablefooter">
                        
                        	
                        
                        	<ul class="paginationbox">
                            <li><div class="pagination-button<?php echo $selPrev?>" <?php echo $PevLink?>>Sebelumnya</div></li>
    
                            <?php
                            for ($numPage=0;$numPage<count($pager->PageNumber);$numPage++){
							$selNnum	= ($page==$pager->PageNumber[$numPage] )?"-selected":'';
							$link		= 'link="'.$pager->LinkNumber[$numPage].$get_search.'"';
							echo	'<li><div class="pagination-button'. $selNnum .'" '.$link.'>'.$pager->PageNumber[$numPage].'</div></li>';
                            }
                            ?>
                            <li><div class="pagination-button<?php echo $selNext?>" <?php echo $NextLink?>>Selanjutnya</div></li>
                            </ul>
                        
                        </div>
                        
                    </div>
                    <input name="p" type="hidden" value="<? echo $page ?>" />
                    <input name="acc" type="hidden" value="<? echo $acc ?>" />

