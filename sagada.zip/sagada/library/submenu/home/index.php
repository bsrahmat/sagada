<p class=MsoNormal align=center style='text-align:center'><b style='mso-bidi-font-weight:
normal'><span style='font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:
115%'>SISTEM INFORMASI MANAJEMEN GENDER DAN ANAK (SAGA)<o:p></o:p></span></b></p>

<p class=MsoListParagraphCxSpFirst style='margin-left:19.5pt;mso-add-space:
auto;text-align:justify;text-indent:-18.0pt;mso-list:l0 level1 lfo1'><![if !supportLists]><span
style='mso-fareast-font-family:Calibri;mso-bidi-font-family:Calibri'><span
style='mso-list:Ignore'>A.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span></span><![endif]>LATAR BELAKANG.</p>

<p class=MsoListParagraphCxSpMiddle style='margin-left:19.5pt;mso-add-space:
auto;text-align:justify'><span class=SpellE><span class=GramE>Ketersediaan</span></span><span
class=GramE> Data Gender <span class=SpellE>dan</span> <span class=SpellE>Anak</span>
<span class=SpellE>secara</span> <span class=SpellE>terpilah</span> yang <span
class=SpellE>dirinci</span> <span class=SpellE>menurut</span> <span
class=SpellE>jenis</span> <span class=SpellE>kelamin</span> <span class=SpellE>dan</span>
<span class=SpellE>keLompok</span> <span class=SpellE>umur</span>, <span
class=SpellE>sangat</span> <span class=SpellE>penting</span> <span
class=SpellE>dalam</span> <span class=SpellE>perencanaan</span>, <span
class=SpellE>peganggaran</span>, <span class=SpellE>pemantauan</span> <span
class=SpellE>dan</span> <span class=SpellE>evaluasi</span> <span class=SpellE>pelaksanaan</span>
<span class=SpellE>kebijakan</span> program <span class=SpellE>dan</span> <span
class=SpellE>kegiatan</span> yang <span class=SpellE>responsife</span> gender.</span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-left:19.5pt;mso-add-space:
auto;text-align:justify'><span class=SpellE>Dalam</span> <span class=SpellE><span
class=GramE>Penyelenggaraan</span></span><span class=GramE><span
style='mso-spacerun:yes'>  </span>Data</span> Gender <span class=SpellE>dan</span>
<span class=SpellE>Anak</span>,<span style='mso-spacerun:yes'>  </span><span
class=SpellE>sesuai</span> <span class=SpellE>perundangan</span> yang <span
class=SpellE>berlaku</span> <span class=SpellE>Pemerintah</span> Daerah <span
class=SpellE>Provinsi</span> <span class=SpellE>Kabupaten</span>/Kota <span
class=SpellE>perlu</span> <span style='mso-spacerun:yes'> </span><span
class=SpellE>menyediakan</span> : <span class=SpellE>Sumberdaya</span> <span
class=SpellE>manusia</span>, <span class=SpellE>Sarana</span> <span
class=SpellE>Prasarana</span> <span class=SpellE>pengelolaan</span> data <span
class=SpellE>dan</span> <span class=SpellE>penyusunan</span> <span
class=SpellE>sistem</span> <span class=SpellE>Adapun</span> Data Gender <span
class=SpellE>dan</span> <span class=SpellE>Anak</span> <span
style='mso-spacerun:yes'> </span><span class=SpellE>adalah</span> <span
class=SpellE>sebagai</span> <span class=SpellE>berikut</span><span
style='mso-spacerun:yes'>  </span>:</p>

<p class=MsoListParagraphCxSpMiddle style='margin-left:19.5pt;mso-add-space:
auto;text-align:justify'><o:p>&nbsp;</o:p></p>

<p class=MsoListParagraphCxSpMiddle style='margin-left:55.5pt;mso-add-space:
auto;text-align:justify;text-indent:-36.0pt;mso-list:l3 level1 lfo2'><![if !supportLists]><span
style='mso-fareast-font-family:Calibri;mso-bidi-font-family:Calibri'><span
style='mso-list:Ignore'>I.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span></span><![endif]><span class=SpellE><b style='mso-bidi-font-weight:
normal'>Bidang</b></span><b style='mso-bidi-font-weight:normal'> <span
class=SpellE><span class=GramE>Kesehatan</span></span></b><span class=GramE> :</span>
<span class=SpellE>Angka</span> <span class=SpellE>harapan</span> <span
class=SpellE>Hidup</span>, <span class=SpellE>Angka</span> <span class=SpellE>Kematian</span>
<span class=SpellE>Ibu</span> <span class=SpellE>melahirkan</span>, <span
class=SpellE>Imunisasi</span> Tetanus <span class=SpellE>Toxoid</span>(TT) <span
class=SpellE>pada</span> <span class=SpellE>Ibu</span> <span class=SpellE>Hamil</span>,
<span class=SpellE>Ibu</span> <span class=SpellE>Hamil</span> yang <span
class=SpellE>mendapat</span> tablet <span class=SpellE>zat</span> <span
class=SpellE>besi</span>(FE), <span class=SpellE>Penderita</span> HIV/AIDS, <span
class=SpellE>Keluarga</span> <span class=SpellE>Berencana</span> <span
class=SpellE>dan</span> <span class=SpellE>Penggunaan</span> <span
class=SpellE>Narkotika</span>.</p>

<p class=MsoListParagraphCxSpMiddle style='margin-left:55.5pt;mso-add-space:
auto;text-align:justify;text-indent:-36.0pt;mso-list:l3 level1 lfo2'><![if !supportLists]><span
style='mso-fareast-font-family:Calibri;mso-bidi-font-family:Calibri'><span
style='mso-list:Ignore'>II.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;
</span></span></span><![endif]><span class=SpellE><b style='mso-bidi-font-weight:
normal'>Bidang</b></span><b style='mso-bidi-font-weight:normal'> <span
class=SpellE>Pendidikan</span> </b>: <span class=SpellE><u>Angka</u></span><u> <span
class=SpellE>Partisipasi</span> <span class=SpellE>Kasar</span>(APK)</u> <span
class=SpellE>menurut</span> <span class=SpellE>jenjang</span> <span
class=SpellE>pendidikan</span> SD,SLTP <span class=SpellE>dan</span> SLTA, <span
class=SpellE><u>Angka</u></span><u> <span class=SpellE>Partisipasi</span> <span
class=SpellE>Sekolah</span> (APS)</u>, <span class=SpellE>menurut</span> <span
class=SpellE>kelompok</span> <span class=SpellE>umur</span> (7-12, 13-15 <span
class=SpellE>dan</span> 16-18 <span class=SpellE>tahun</span>), <span
class=SpellE><u>Angka</u></span><u> <span class=SpellE>Melek</span> <span
class=SpellE>Huruf</span>(AMH)</u> <span class=SpellE>menurut</span> <span
class=SpellE>kelompok</span> <span class=SpellE>umur</span> : 15-19 <span
class=SpellE>tahun</span>, 20-24 <span class=SpellE>tahun</span>, 25-29 <span
class=SpellE>tahun</span>, 30-34 <span class=SpellE>tahun</span>, 35-39 <span
class=SpellE>tahun</span>, 40-44 <span class=SpellE>tahun</span>, 45-49 <span
class=SpellE>tahun</span>, 50-54 <span class=SpellE>tahun</span>, 55-59 <span
class=SpellE>tahun</span> <span class=SpellE>dan</span> 60 <span class=SpellE>tahun</span>
<span class=SpellE>keatas</span>. <span class=SpellE><u>Angka</u></span><u> <span
class=SpellE>Putus</span> <span class=SpellE>Sekolah</span></u> <span
class=SpellE>menurut</span> <span class=SpellE>jenjang</span> <span
class=SpellE>pendidikan</span> SD, SLTP <span class=SpellE>dan</span> SLTA.</p>

<p class=MsoListParagraphCxSpMiddle style='margin-left:55.5pt;mso-add-space:
auto;text-align:justify;text-indent:-36.0pt;mso-list:l3 level1 lfo2'><![if !supportLists]><span
style='mso-fareast-font-family:Calibri;mso-bidi-font-family:Calibri'><span
style='mso-list:Ignore'>III.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;
</span></span></span><![endif]><span class=SpellE><b style='mso-bidi-font-weight:
normal'>Bidang</b></span><b style='mso-bidi-font-weight:normal'> <span
class=SpellE>Ekonomi</span> <span class=SpellE>dan</span> <span class=SpellE><span
class=GramE>Ketenagakerjaan</span></span><span class=GramE> :</span> </b>Tingkat
<span class=SpellE>Partisipasi</span> <span class=SpellE>Angkatan</span> <span
class=SpellE>Kerja</span>(TPAK), <span class=SpellE>Jumlah</span> <span
class=SpellE>penduduk</span> <span class=SpellE>usia</span> <span class=SpellE>kerja</span>,
<span class=SpellE>Penduduk</span> <span class=SpellE>usia</span> <span
class=SpellE>kerja</span> yang <span class=SpellE>bekerja</span> <span
class=SpellE>menurut</span> status <span class=SpellE>pekerjaan</span>, <span
class=SpellE>Pekerja</span> formal <span class=SpellE>dan</span> informal, Tingkat
<span class=SpellE>pegangguran</span> <span class=SpellE>terbuka</span>, <span
class=SpellE>Setengah</span> <span class=SpellE>pegangguran</span>.</p>

<p class=MsoListParagraphCxSpMiddle style='margin-left:55.5pt;mso-add-space:
auto;text-align:justify;text-indent:-36.0pt;mso-list:l3 level1 lfo2'><![if !supportLists]><span
style='mso-fareast-font-family:Calibri;mso-bidi-font-family:Calibri'><span
style='mso-list:Ignore'>IV.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;
</span></span></span><![endif]><span class=SpellE><b style='mso-bidi-font-weight:
normal'>Bidang</b></span><b style='mso-bidi-font-weight:normal'> <span
class=SpellE>Hukum</span> <span class=SpellE>dan</span> <span class=SpellE>Sosial</span>
<span class=SpellE><span class=GramE>Budaya</span></span><span class=GramE> :</span></b>
<span class=SpellE>Penghuni</span> <span class=SpellE>lembaga</span><span
style='mso-spacerun:yes'>   </span><span class=SpellE>Pemasyarakatan</span>(<span
class=SpellE>Lapas</span>),<span class=SpellE>Penghuni</span> <span
class=SpellE>Rumah</span> <span class=SpellE>tanahan</span> (<span
class=SpellE>Rutan</span>), <span class=SpellE>Penduduk</span> <span
class=SpellE>Lanjut</span> <span class=SpellE>Usia</span> : <span class=SpellE>Penduduk</span>
<span class=SpellE>Lansia</span> <span class=SpellE>menurut</span> <span
class=SpellE>pendidikan</span> yang <span class=SpellE>ditamatkan</span>, <span
class=SpellE>Penduduk</span> <span class=SpellE>Lansia</span> <span
class=SpellE>menurut</span> <span class=SpellE>aktivitas</span> yang <span
class=SpellE>dilakukan</span>, <span class=SpellE>angka</span> <span
class=SpellE>kesakitan</span><span style='mso-spacerun:yes'>  </span><span
class=SpellE>Lansia</span>(<span class=SpellE>Morbiditas</span>), <span
class=SpellE>Penyandang</span> <span class=SpellE>cacat</span> (<span
class=SpellE>Penca</span>) : <span class=SpellE>Penca</span> <span
class=SpellE>menurut</span> <span class=SpellE>pendidikan</span> yang <span
class=SpellE>ditamatkan</span> ,<span class=SpellE>Penca</span> <span
class=SpellE>menurut</span> <span class=SpellE>aktivitas</span> yang <span
class=SpellE>dilakukan</span>.<span style='mso-tab-count:1'>          </span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-left:55.5pt;mso-add-space:
auto;text-align:justify;text-indent:-36.0pt;line-height:150%;mso-list:l3 level1 lfo2'><![if !supportLists]><span
style='mso-fareast-font-family:Calibri;mso-bidi-font-family:Calibri'><span
style='mso-list:Ignore'>V.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;
</span></span></span><![endif]><span class=SpellE><b style='mso-bidi-font-weight:
normal'>Kekerasan</b></span><b style='mso-bidi-font-weight:normal'> <span
class=SpellE>Terhadap</span> <span class=SpellE>Perempuan</span> :</b> 1. <span
class=SpellE><u>Korban</u></span> : <span class=SpellE>a.Umur</span> : <span
class=SpellE>Anak</span>(0&lt;18 <span class=SpellE>tahun</span>), <span
class=SpellE>Remaja</span>(18,25 <span class=SpellE>tahun</span>), <span
class=SpellE>dan</span> 25 <span class=SpellE>tahun</span> <span class=SpellE>keatas</span>),
b. Tingkat <span class=SpellE>pendidikan</span>, c. Status <span class=SpellE>Pekerjaan</span>,
d. Status <span class=SpellE>Perkawinan</span>, e. <span class=SpellE>Jenis</span>
<span class=SpellE>Kekerasan</span>, f. <span class=SpellE>Tempat</span> <span
class=SpellE>kejadian</span>, g. <span class=SpellE>Jenis</span> <span
class=SpellE>pelayanan</span> yang <span class=SpellE>diberikan</span>, <span
style='mso-spacerun:yes'> </span>h. <span class=SpellE>Frekuensi</span> <span
class=SpellE>kekerasan</span>.</p>

<p class=MsoListParagraphCxSpMiddle style='margin-left:55.5pt;mso-add-space:
auto;text-align:justify'>2. <span class=SpellE><span class=GramE><u>Pelaku</u></span></span><span
class=GramE><u> </u>:</span> <span class=SpellE>a.Tingkat</span> <span
class=SpellE>Pendidikan</span>, b. Status <span class=SpellE>Pekerjaan</span>, c.
<span class=SpellE>Hubungan</span> <span class=SpellE>dengan</span> <span
class=SpellE>Korban</span>,<span style='mso-spacerun:yes'>  </span>d. <span
class=SpellE>Kebangsaan</span>.</p>

<p class=MsoListParagraphCxSpLast style='margin-left:27.0pt;mso-add-space:auto;
text-align:justify;text-indent:28.5pt'><span style='mso-spacerun:yes'>     
</span></p>

<p class=MsoNormal style='text-align:justify;line-height:150%'><span
style='mso-spacerun:yes'>          </span><span class=SpellE>Dengan</span> <span
class=SpellE>adanya</span> <span class=SpellE>sistim</span> <span class=SpellE>aplikasi</span>
data gender <span class=SpellE>diharapkan</span> <span class=SpellE>Pemerintah</span>
<span class=SpellE>Provinsi</span> <span class=SpellE>papua</span> <span
class=SpellE>dalam</span> <span class=SpellE>hal</span> <span class=SpellE>ini</span>
Biro <span class=SpellE>Pemberdayaan</span> <span class=SpellE>Perempuan</span>
<span class=SpellE>Setda</span> <span class=SpellE>Provinsi</span> <span
class=SpellE>papua</span> <span class=SpellE>dapat</span> <span class=SpellE>menyediakan</span>
data <span class=SpellE>dalam</span> <span style='mso-spacerun:yes'> </span><span
class=SpellE>pelaksanaan</span> <span class=SpellE>kebijakan</span>, program <span
class=SpellE>dan</span> <span class=SpellE>kegiatan</span> <span class=SpellE>diharapkan</span>
<span class=SpellE>dapat</span> <span class=SpellE>tepat</span> <span
class=SpellE>sasaran</span> <span class=SpellE>dan</span> <span class=SpellE>tepa</span>
<span class=SpellE>guna</span> <span class=SpellE>sehingga</span> <span
class=SpellE>memberikan</span> <span class=SpellE>dampak</span> yang <span
class=SpellE>setara</span> <span class=SpellE>bagi</span> <span class=SpellE>perempuan</span>
<span class=SpellE>dan</span> <span class=SpellE>laki-laki</span>. </p>

<p class=MsoNormal style='text-align:justify;line-height:150%'><span
style='mso-spacerun:yes'> </span><span class=SpellE>Demikian</span> pula <span
class=SpellE>dengan</span> <span class=SpellE>dengan</span> <span class=SpellE>ketersediaan</span>
data <span class=SpellE>anak</span> <span class=SpellE>akan</span> <span
class=SpellE>mempermudah</span> <span class=SpellE>Proses</span> <span
class=SpellE>pengarusutamaan</span> <span class=SpellE>Hak</span> <span
class=SpellE><span class=GramE>Anak</span></span><span class=GramE>(</span>PUHA)
<span class=SpellE>dalam</span> <span class=SpellE>kebijakan</span>, program, <span
class=SpellE>dan</span><span style='mso-spacerun:yes'>  </span><span
class=SpellE>kegiatan</span> <span class=SpellE>pembangunan</span> Daerah.</p>

<p class=MsoNormal style='text-align:justify;line-height:150%'><span
style='mso-tab-count:1'>                </span><span class=SpellE>Dalam</span>
Era <span class=SpellE>Otonomi</span> <span class=SpellE>Khusus</span> <span
class=SpellE>sekarang</span> <span class=SpellE>ini</span>, <span class=SpellE>sebagian</span>
<span class=SpellE>besar</span> <span class=SpellE>proses</span> <span
class=SpellE>pembangunan</span> <span class=SpellE>berada</span> <span
class=SpellE>ditangan</span> <span class=SpellE>pemerintah</span> <span
class=SpellE>daerah</span>. <span class=SpellE>Oleh</span> <span class=SpellE>sebab</span>
<span class=SpellE>itu</span> <span class=SpellE>pemahaman</span> <span
class=SpellE>tentang</span> <span class=SpellE>kondisi</span> <span
class=SpellE>daerah</span> <span class=SpellE>sangatlah</span> <span
class=SpellE>diperlukan</span> , <span class=SpellE>khususnya</span> <span
class=SpellE>dalam</span> <span class=SpellE>upaya</span> <span class=SpellE>pembangunan</span>
<span class=SpellE>pemberdayaan</span> <span class=SpellE>perempuan</span>, <span
class=SpellE>melalui</span> <span class=SpellE>penyediaan</span> <span
class=SpellE>aplikasi</span> data gender <span class=SpellE>dan</span> <span
class=SpellE>anak</span> <span class=SpellE>secara</span> <span class=SpellE>terpilah</span>
<span class=SpellE>menurut</span> <span class=SpellE>jenis</span> <span
class=SpellE>kelamin</span> <span class=SpellE>dan</span> <span class=SpellE>kelompok</span>
<span class=SpellE>umur</span> <span class=SpellE>diberbagai</span> <span
class=SpellE>bidang</span> <span class=SpellE>dengan</span> <span class=SpellE>sendirinya</span>
<span class=SpellE>menggambarkan</span> <span class=SpellE>isu</span> gender
yang <span class=SpellE>masih</span> <span class=SpellE>terabaikan</span> <span
class=SpellE>atau</span> <span class=SpellE>belum</span> <span class=SpellE>dikerjakan</span>
<span class=SpellE>secara</span> optimal.</p>

<p class=MsoNormal style='text-align:justify;line-height:150%'><span
style='mso-tab-count:1'>                </span><span class=SpellE>Dalam</span> <span
class=SpellE>sistem</span> <span class=SpellE>perencanaan</span>, <span
class=SpellE>isu-isu</span> Gender <span class=SpellE>dan</span> <span
class=SpellE>Anak</span> <span class=SpellE>di</span> Daerah <span
class=SpellE>juga</span> <span class=SpellE>menggambarkan</span> <span
class=SpellE><span class=GramE>permasalahan</span></span><span class=GramE><span
style='mso-spacerun:yes'>  </span>yang</span> <span class=SpellE>harus</span> <span
class=SpellE>ditindaklanjuti</span> <span class=SpellE>secara</span> <span
class=SpellE>komprehensif</span> <span class=SpellE>dan</span> <span
class=SpellE>berkesinambungan</span> <span class=SpellE>oleh</span> Daerah. <span
class=SpellE>Oleh</span> <span class=SpellE>karena</span> <span class=SpellE>itu</span>
<span class=SpellE>Sistim</span> <span class=SpellE>Aplikasi</span> <span
class=SpellE>bagi</span> Biro <span class=SpellE>Pemberdayaan</span> <span
class=SpellE>Perempuan</span> <span class=SpellE>Setda</span> <span
class=SpellE>Provinsi</span> Papua <span class=SpellE>Tahun</span> <span
class=GramE>2012 <span style='mso-spacerun:yes'> </span><span class=SpellE>perlu</span></span>
<span class=SpellE>karena</span> <span class=SpellE>akan</span> <span
class=SpellE>menjadi</span> input yang <span class=SpellE>sangat</span> <span
class=SpellE>berharga</span> <span class=SpellE>dalam</span> <span
class=SpellE>penyusunan</span> <span class=SpellE>perencanaan</span> <span
class=SpellE>pembangunan</span>.</p>

<p class=MsoNormal style='text-align:justify;line-height:150%'><span
class=SpellE><span class=GramE>Selain</span></span><span class=GramE> <span
class=SpellE>itu</span>, <span class=SpellE>dapat</span> <span class=SpellE>diketahui</span>
<span class=SpellE>tentang</span> data <span class=SpellE>dan</span> <span
class=SpellE>informasi</span> <span class=SpellE>kesenjangan</span> gender yang
<span class=SpellE>dapat</span> <span class=SpellE>digunakan</span> <span
class=SpellE>untuk</span> <span class=SpellE>mengintegrasikan</span> gender <span
class=SpellE>kedalam</span> <span class=SpellE>berbagai</span> sector <span
class=SpellE>pembangunan</span> <span class=SpellE>sebagaimana</span> <span
class=SpellE>beberapa</span> <span class=SpellE>bidang</span> yang <span
class=SpellE>telah</span> <span class=SpellE>disebutkan</span> <span
class=SpellE>diatas</span>.</span> <span class=SpellE>Ketersediaan</span> <span
class=SpellE><span class=GramE>fakta</span></span><span class=GramE> ,</span> data
<span class=SpellE>dan</span> <span class=SpellE>informasi</span> <span
class=SpellE>kesejangan</span><span style='mso-spacerun:yes'>  </span>gender <span
class=SpellE>secara</span> <span class=SpellE>cepat</span> <span class=SpellE>dan</span>
<span class=SpellE>tepat</span> <span class=SpellE>diberbagai</span> sector <span
class=SpellE>pembangunan</span> <span class=SpellE>juga</span> <span
class=SpellE>sangat</span> <span class=SpellE>dibutuhkan</span> <span
class=SpellE>karena</span> <span class=SpellE>dapat</span> <span class=SpellE>memberikan</span>
<span class=SpellE>gambaran</span> yang <span class=SpellE>jelas</span> <span
class=SpellE>tentang</span> <span class=SpellE>kondisi</span> <span
class=SpellE>dan</span> <span class=SpellE>posisi</span> <span class=SpellE>laki-laki</span>
<span class=SpellE>serta</span> <span class=SpellE>perempuan</span>.</p>

<p class=MsoNormal style='text-align:justify;line-height:150%'><span
class=SpellE>Kegiatan</span> <span class=SpellE>sistem</span> <span
class=SpellE>Aplikasi</span> Data Gender <span class=SpellE>dan</span> <span
class=SpellE><span class=GramE>Anak</span></span><span class=GramE> <span
style='mso-spacerun:yes'> </span><span class=SpellE>oleh</span></span> Biro <span
class=SpellE>Pemberdayaan</span> <span class=SpellE>Perempuan</span> <span
class=SpellE>Setda</span> <span class=SpellE>Provinsi</span> Papua <span
class=SpellE>Tahun</span> 2012 <span style='mso-spacerun:yes'> </span><span
class=SpellE>diharapkan</span> <span class=SpellE>dapat</span> <span
class=SpellE>menjawab</span> <span class=SpellE>permasalahan</span> <span
class=SpellE>sebagaimana</span> <span class=SpellE>tersebut</span> <span
class=SpellE>diatas</span>.</p>

<p class=MsoListParagraphCxSpFirst style='margin-left:19.5pt;mso-add-space:
auto;text-align:justify;text-indent:-18.0pt;mso-list:l0 level1 lfo1'><![if !supportLists]><span
style='mso-fareast-font-family:Calibri;mso-bidi-font-family:Calibri'><span
style='mso-list:Ignore'>B.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span></span><![endif]>TUJUAN.</p>

<p class=MsoListParagraphCxSpMiddle style='margin-left:19.5pt;mso-add-space:
auto;text-align:justify;line-height:150%'><span class=SpellE>Adapun</span> <span
class=SpellE>tujuan</span> <span class=SpellE>dari</span> <span class=SpellE>kegiatan</span>
<span class=SpellE>Sistim</span> <span class=SpellE>Aplikasi</span> Data Gender
<span class=SpellE>dan</span> <span class=SpellE>Anak</span> <span
class=SpellE>adalah</span> <span class=SpellE>sebagai</span> <span
class=SpellE><span class=GramE>berikut</span></span><span class=GramE><span
style='mso-spacerun:yes'>  </span>:</span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-left:37.5pt;mso-add-space:
auto;text-align:justify;text-indent:-18.0pt;line-height:150%;mso-list:l1 level1 lfo4'><![if !supportLists]><span
style='mso-fareast-font-family:Calibri;mso-bidi-font-family:Calibri'><span
style='mso-list:Ignore'>1.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span></span><![endif]><span class=SpellE>Tersedianya</span> <span
class=SpellE>suatu</span> <span class=SpellE>sistem</span> <span class=SpellE><span
class=GramE>Aplikasi</span></span><span class=GramE> <span
style='mso-spacerun:yes'> </span>Data</span> Gender <span class=SpellE>dan</span>
<span class=SpellE>Anak</span> <span class=SpellE>secara</span> <span
style='mso-spacerun:yes'> </span><span class=SpellE>terpilah</span> <span
class=SpellE>menurut</span> <span class=SpellE>jenis</span> <span class=SpellE>kelamin</span>,
<span class=SpellE>kelompok</span> <span class=SpellE>umur</span>, <span
class=SpellE>jenjang</span> <span class=SpellE>pendidikan</span>, <span
class=SpellE>dan</span> <span class=SpellE>isu-isu</span> <span class=SpellE>prioritas</span>
<span class=SpellE>lainnya</span> <span style='mso-spacerun:yes'> </span><span
class=SpellE>dengan</span> <span class=SpellE>cepat</span> <span class=SpellE>dan</span><span
style='mso-spacerun:yes'>  </span><span class=SpellE>tepat</span>.</p>

<p class=MsoListParagraphCxSpMiddle style='margin-left:37.5pt;mso-add-space:
auto;text-align:justify;text-indent:-18.0pt;line-height:150%;mso-list:l1 level1 lfo4'><![if !supportLists]><span
style='mso-fareast-font-family:Calibri;mso-bidi-font-family:Calibri'><span
style='mso-list:Ignore'>2.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span></span><![endif]><span style='mso-spacerun:yes'> </span><span
class=SpellE>Melalui</span> <span class=SpellE>Sistim</span> <span
class=SpellE>Aplikasi</span> Data Gender <span class=SpellE>dan</span> <span
class=SpellE><span class=GramE>Anak</span></span><span class=GramE> ,</span><span
style='mso-spacerun:yes'>  </span><span class=SpellE>dapat</span> <span
class=SpellE>mengirim</span> <span class=SpellE>laporan</span> <span
class=SpellE>kepada</span> <span class=SpellE>Menteri</span> <span
class=SpellE>Dalam</span> <span class=SpellE>Negeri</span> <span class=SpellE>dan</span>
<span class=SpellE>Menteri</span> <span class=SpellE>Pemberdayaan</span> <span
class=SpellE>Perempuan</span> <span class=SpellE>setiap</span> <span
class=SpellE>akhir</span> <span class=SpellE>tahun</span> <span class=SpellE>Anggaran</span>.
<span style='mso-spacerun:yes'> </span></p>


<p class=MsoListParagraphCxSpMiddle style='margin-left:19.5pt;mso-add-space:
auto;text-align:justify;text-indent:-18.0pt;mso-list:l0 level1 lfo1'><![if !supportLists]><span
style='mso-fareast-font-family:Calibri;mso-bidi-font-family:Calibri'><span
style='mso-list:Ignore'>C.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span></span><![endif]>SASARAN.</p>

<p class=MsoListParagraphCxSpMiddle style='margin-left:19.5pt;mso-add-space:
auto;text-align:justify;line-height:150%'><span class=SpellE>Sasaran</span> <span
class=SpellE>kegiatan</span><span style='mso-spacerun:yes'>  </span><span
class=SpellE>Sistem</span> <span class=SpellE>Aplikasi</span> Data Gender <span
class=SpellE>dan</span> <span class=SpellE>Anak</span> <span class=SpellE>adalah</span>
<span class=SpellE>adanya</span> <span class=SpellE>sistim</span> <span
class=SpellE>Aplikasi</span> Data Gender <span class=SpellE>dan</span> <span
class=SpellE>Anak</span> yang <span class=SpellE>meliputi</span><span
style='mso-spacerun:yes'>  </span>Data <span class=SpellE>Bidang</span> <span
class=SpellE>Kesehatan</span>, <span class=SpellE>Pendidikan</span>, <span
class=SpellE>Ekonomi</span> <span class=SpellE>dan</span> <span class=SpellE>Ketenagakerjaan</span>,
<span class=SpellE>Politik</span> <span class=SpellE>dan</span> <span
class=SpellE>Pengambilan</span> <span class=SpellE>Keputusan</span>, <span
class=SpellE>Hukum</span> <span class=SpellE>dan</span> <span class=SpellE>Sosial</span>
<span class=SpellE>Budaya</span> <span class=SpellE>serta</span> <span
class=SpellE>kekerasan</span> <span class=SpellE>terhadap</span> <span
class=SpellE>Perempuan</span> <span class=SpellE>dan</span> <span class=SpellE>Anak</span>
<span class=SpellE>untuk</span> <span class=SpellE>Provinsi</span> Papua <span
class=SpellE>dan</span> <span class=SpellE>Kabupaten</span>/Kota. </p>

<p class=MsoListParagraphCxSpMiddle style='margin-left:19.5pt;mso-add-space:
auto;text-align:justify;line-height:150%'><o:p>&nbsp;</o:p></p>

<p class=MsoListParagraphCxSpLast style='margin-left:19.5pt;mso-add-space:auto;
text-align:justify;line-height:150%'><o:p>&nbsp;</o:p></p>