<script type="text/javascript">
 $(document).ready(function(){
   $(".ctable tr").mouseover(function(){$(this).addClass("over");}).mouseout(function(){$(this).removeClass("over");});
   $(".ctable tr:even").addClass("alt");
 });
 </script>
 <?php
/////// konfigurasi
///// query untuk paging

if(file_exists('../../connectionmysql.php')) {
	require_once '../../connectionmysql.php';
	Connected();	
}

$perm = array();
$perm = getPermissions('47');

if(file_exists('../../error-menu.php')) if($perm[-1]=='1') { require_once '../../error-menu.php'; die; }

//BAGIAN INPUTAN PENCARIAN
//Fungsi STRIPSTRING berfungsi hanya karakter a-z, A-Z, dan angka 0-9 yang diperbolehkan.
$get_search = '';
$search = '';
$search_name = 'Pencarian...';
$year = date('Y');

if(isset($_GET['search'])) {
	$_GET['search'] = stripString($_GET['search']);
	$search_name = $_GET['search'];
	
	if($_GET['search'] || $_GET['search'] != 'Pencarian...' || $_GET['search'] != '') {
		$search = "WHERE LOWER(tbl_panggol.panggol_name) LIKE '%".strtolower($_GET['search'])."%'";
		$get_search = '&search='.strtolower($_GET['search']);
	}
}

$rs_count = mysql_query("select * from tbl_panggol ".$search);
$count  = mysql_num_rows($rs_count);

// variabel paging
$page  = (isset($_GET['p']))?( (is_numeric($_GET['p']))?( $page = $_GET['p']): $page = 1 ): $page = 1;
$limit = 20;
$start = $limit * ($page - 1);

$pager = new pagination();
$pager->currentPage 	= $page;
$pager->total			= $count;
$pager->limit			= $limit;
$pager->baseLink		= 'library/submenu/master/panggol?p=';
$pager->getHalaman(); 
/// output variabel paging
$selPrev = ($page==$pager->PagePrev )?"-selected":'';
$PevLink = 'link="'. $pager->LinkPrev.$get_search.'"';

$selNext	= ($page==$pager->PageNext )?"-selected":'';
$NextLink	= 'link="'. $pager->LinkNext.$get_search.'"';

//query untuk isi
$rs_panggol = mysql_query("select * from tbl_panggol ".$search." order by panggol_kode DESC limit $limit offset $start;");

/////////////// ending konfigurasi
////////////// process
?>
 
                    <div class="sub-content-title sub-panggol">Data Pangkat Golongan</div>
                    
                	<div class="cboxtable">
                    	<div class="sub-content-bar">
                        	<? if($perm[0]!='1') { ?>
                        	<div class="input-button" type="popup" mode="0" link="modul/master/panggol">Tambah Baru</div>
                            <? } else { ?>
                            <div class="disabled-input-button">Tambah Baru</div>
                            <? } ?>
                            
                            <? if($perm[2]!='1') { $disabled = ''; ?>
                            <div class="input-button" type="popup" mode="4" link="modul/master/panggol">Hapus</div>
                            <? } else { $disabled='disabled'; ?>
                            <div class="disabled-input-button">Hapus</div>
                            <? } ?>                           
                            
                                                      
                            <div class="search-button" link="library/submenu/master/panggol">Cari</div>
                            <input id="foc-now" class="search-input" type="text" value="<? echo $search_name; ?>"  />

                        </div>
                    
                    	                        
                    	<table class="ctable">
                        <tr class="ctableheader">
                            <td width="1%"><input name="mainchk" type="checkbox" value="" <? echo $disabled ?> /></td>                           
                            <td>Nama Pangkat Golongan</td>
                            <td align="center" width="2%">Actions</td>
                            
                          
                        </tr>
                        <?php
							$no= $start+1;
							while($rows_panggol=mysql_fetch_array($rs_panggol)) {
									
						?>
                        <tr>
                          <td align="center"><input name="chkbox[]" type="checkbox" value="<? echo $rows_panggol['panggol_kode'] ?>" <? echo $disabled ?> /></td>
                            <td class="ltext" valign="top"><? echo $rows_panggol['panggol_name'] ?></td>
                           <td>
                            	<div class="cactions two">
                                <? if($perm[1]!='1') { ?>
                            	<div class="cedit" type="popup" mode="1" title="Edit" link="modul/master/panggol?<? echo $rows_panggol['panggol_kode'] ?>"></div>
                                <? } else { ?>
                            	<div class="disabled-cedit"></div>
                            	<? } ?>
                                <? if($perm[2]!='1') { ?>
                                <div link="modul/master/panggol?<? echo $rows_panggol['panggol_kode'] ?>" title="Hapus" mode="2" type="popup" class="cdelete"></div>
                            	<? } else { ?>
                            	<div class="disabled-cdelete"></div>
                            	<? } ?>
                                </div>
                            </td>
                      
                        </tr>
						<?php
							}
						?>
                        </table>
                        
                        <div class="ctablefooter">
                        
                        	
                        
                        	<ul class="paginationbox">
                            <li><div class="pagination-button<?php echo $selPrev?>" <?php echo $PevLink?>>Sebelumnya</div></li>
    
                            <?php
                            for ($numPage=0;$numPage<count($pager->PageNumber);$numPage++){
							$selNnum	= ($page==$pager->PageNumber[$numPage] )?"-selected":'';
							$link		= 'link="'.$pager->LinkNumber[$numPage].$get_search.'"';
							echo	'<li><div class="pagination-button'. $selNnum .'" '.$link.'>'.$pager->PageNumber[$numPage].'</div></li>';
                            }
                            ?>
                            <li><div class="pagination-button<?php echo $selNext?>" <?php echo $NextLink?>>Selanjutnya</div></li>
                            </ul>
                        
                        </div>
                        
                    </div>
                    <input name="p" type="hidden" value="<? echo $page ?>" />

