   <div class="popup-shadow" style="width: 500px;">
      <div class="popup-header">
         <span>Akses Halaman Ditolak</span>
         <div class="popup-close">X</div>
      </div>
      <div class="popup-body">
      <table>
      <tr>
      <td align="center">
                        <div style="width: 400px; text-align:left; line-height: 19px;">
                        Tidak dapat mengakses halaman. Dikarenakan hal-hal sebagai berikut :<br /><br />
                        • Anda sudah <b style="text-decoration:underline;">Log Out</b> dari program.<br />
                        • Anda tidak mempunyai <b style="text-decoration:underline;">Hak Akses</b> untuk membuka halaman ini.
                       <br /><br />
                    	Apabila anda sudah <b style="text-decoration:underline;">Log Out</b>, silahkan menekan tombol di bawah ini.
                        <br />
                        </div>
                        <div class="main-button" link="<? echo URL_DIRECT?>">Kembali ke halaman utama</div>
                        </td>
      </tr>
      </table>
      </div>
      <div class="popup-footer">
        <div class="popup-cancel">Tutup</div>
        
      </div>
      
   </div>