 
                    <div class="sub-content-title sub-dana">Akses Halaman Ditolak</div>
                    
                    <form action="" method="post">
                	<div class="cboxtable">
                    
                    	<div class="ctabletitle">Akses Halaman Ditolak</div>
                        
                        <div class="ctable-box">
                    	<table class="ctable" height="200">
                        
                        <tr>
                        <td align="center">
                        <div style="width: 390px; text-align:left; line-height: 19px;">
                        Tidak dapat mengakses halaman. Dikarenakan hal-hal sebagai berikut :<br />
                        • Anda sudah <b>Log Out dari program.</b><br />
                        • Anda tidak mempunyai <b>Hak Akses</b> untuk membuka halaman ini.
                       <br /><br />
                    	Apabila anda sudah <b>Log Out</b>, silahkan menekan tombol di bawah ini.
                        <br />
                        </div>
                        <div class="main-button" link="<? echo URL_DIRECT?>">Kembali ke halaman utama</div>
                        </td>
                        </tr>

                        </table>
                        </div>
                                                
                    </div>
                    </form>

