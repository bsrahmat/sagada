<?php
error_reporting(0);
require_once 'paging.php';

define('URL_DIRECT','index.php');

// fungsi untuk koneksi ke database;
function connecting($servername,$dbname,$dbuser,$dbpassword)
{
	global $link;
	$link=mysql_connect ("$servername","$dbuser","$dbpassword");
	if(!$link) die("Cannot Open Database!.");
	mysql_select_db("$dbname",$link) or die ("Failed to Open Database!. Please Contact your Administrator.".mysql_error());
}
function Connected()
{
	if(!isset($_SESSION)) 
		{ 
			session_start(); 
		} 
	$servername='localhost';    // Your MySql Server Name or IP address here
	$dbusername='ristekom_root';         // Login user here
	$dbpassword='bismillah123';             // Login password here
	$dbname='ristekom_egender';		// nama database...
	
//	$servername='localhost';    // Your MySql Server Name or IP address here
//	$dbusername='puslit_root';         // Login user here
//	$dbpassword='bismillah123';             // Login password here
//	$dbname='puslit_saga';		// nama database...


	global $link;
	connecting($servername,$dbname,$dbusername,$dbpassword);
}


function headerSlice($string,$cond=true) {
	if($cond) {
		$str = preg_split ('/$\R?^/m', $string);
		$char = $str[0].'<br /><span class="sub">'.$str[1].'</span><br /><span class="lastsub">'.$str[2].'</span>';	
	} else
		$char = '<span class="sub">Sistem Informasi Manajemen</span><br /><span class="lastsub">SAGA</span>';	
		
	return $char;	
}

function indonesian_date ($timestamp = '', $date_format = 'l, j F Y ') {
	if (trim ($timestamp) == '')
	{
			$timestamp = time ();
	}
	elseif (!ctype_digit ($timestamp))
	{
		$timestamp = strtotime ($timestamp);
	}
	# remove S (st,nd,rd,th) there are no such things in indonesia :p
	$date_format = preg_replace ("/S/", "", $date_format);
	$pattern = array (
		'/Mon[^day]/','/Tue[^sday]/','/Wed[^nesday]/','/Thu[^rsday]/',
		'/Fri[^day]/','/Sat[^urday]/','/Sun[^day]/','/Monday/','/Tuesday/',
		'/Wednesday/','/Thursday/','/Friday/','/Saturday/','/Sunday/',
		'/Jan[^uary]/','/Feb[^ruary]/','/Mar[^ch]/','/Apr[^il]/','/May/',
		'/Jun[^e]/','/Jul[^y]/','/Aug[^ust]/','/Sep[^tember]/','/Oct[^ober]/',
		'/Nov[^ember]/','/Dec[^ember]/','/January/','/February/','/March/',
		'/April/','/June/','/July/','/August/','/September/','/October/',
		'/November/','/December/',
	);
	$replace = array ( 'Sen','Sel','Rab','Kam','Jum','Sab','Min',
		'Senin','Selasa','Rabu','Kamis','Jumat','Sabtu','Minggu',
		'Jan','Feb','Mar','Apr','Mei','Jun','Jul','Ags','Sep','Okt','Nov','Des',
		'Januari','Februari','Maret','April','Juni','Juli','Agustus','Sepember',
		'Oktober','November','Desember',
	);
	$date = date ($date_format, $timestamp);
	$date = preg_replace ($pattern, $replace, $date);
	$date = "{$date}";
	return $date;
} 

function Clock(){
	    // Ambil waktu server terkini
    $dat_server = mktime(date("G"), date("i"), date("s"), date("n"), date("j"), date("Y"));
    $server = date("H:i:s", $dat_server);
     
    // Ambil perbedaan waktu server dengan GMT
    $diff_gmt = substr(date("O",$dat_server),1,2);
    // karena perbedaan waktu adalah dalam jam, maka kita jadikan detik
    $datdif_gmt = 60 * 60 * $diff_gmt;
     
    // Hitung perbedaannya
    if (substr(date("O",$dat),0,1) == '+') {
    $dat_gmt = $dat_server - $datdif_gmt;
    } else {
    $dat_gmt = $dat_server + $datdif_gmt;
    }
    $gmt = date("H:i:s", $dat_gmt);
    // Hitung perbedaan GMT dengan waktu Indonesia (GMT+7)
    // karena perbedaan waktu adalah dalam jam, maka kita jadikan detik
    $datdif_id = 60 * 60 * 7;
    $dat_id = $dat_gmt + $datdif_id;
    $indonesia = date("H:i:s", $dat_id);
	
	return $indonesia;
}



function setID($seq,$type="mysql") {
	if($type=='mysql')
		return 'NULL';
	else
		return "nextval('".$seq."'::regclass)";
}

function getUserName($code) {
	$rs_user = mysql_query("select * from tbl_user where user_kode = '".$code."'");
	$cnt_user = mysql_num_rows($rs_user);
	$rows_user = mysql_fetch_array($rs_user);
	if($cnt_user>0)
		return $rows_user['user_full_name'];
	else
		return 'Unknown';
}

//fungsi untuk ngecek tambah data baru sama dgn if($_GET['mod']=='0') echo 'blah.. blah..';
function isAdd() {
	if($_GET['mod']=='0') return true;	
}

//fungsi untuk ngecek edit sama dgn if($_GET['mod']=='1') echo 'blah.. blah..';
function isEdit() {
	if($_GET['mod']=='1') return true;	
}



//fungsi untuk konfirmasi hapus sama dgn if($_GET['mod']=='2') echo 'blah.. blah..';
function isConfirmDelete() {
	if($_GET['mod']=='2') return true;	
}

//fungsi untuk hapus sama dgn if($_GET['mod']=='3') echo 'blah.. blah..';
function isDelete() {
	if($_GET['mod']=='3') return true;	
}

//fungsi untuk konfirmasi hapus yg dipilih sama dgn if($_GET['mod']=='4') echo 'blah.. blah..';
function isConfirmDeleteSelected() {
	if($_GET['mod']=='4') return true;	
}

//fungsi untuk hapus yg dipilih sama dgn if($_GET['mod']=='5') echo 'blah.. blah..';
function isDeleteSelected() {
	if($_GET['mod']=='5') return true;	
}

//fungsi untuk menyimpan sama dgn if($_GET['mod']=='6') echo 'blah.. blah..';
function isSave() {
	if($_GET['mod']=='6') return true;	
}

function isAktivasi() {
	if($_GET['mod']=='7') return true;	
}

function isDetail() {
	if($_GET['mod']=='8') return true;	
}

function isSaveTo() {
	if($_GET['mod']=='9') return true;	
}

function stripInput($val) {
	$val = preg_replace("/[^a-zA-Z0-9,.()-\/@ \s]/", "", $val);
	return $val;
}


function stripString($val) {
	$val = preg_replace("/[^a-zA-Z0-9,. \s]/", "", $val);
	return $val;
}

function stripUser($val) {
	$val = preg_replace("/[^a-zA-Z0-9@\s]/", "", $val);
	return $val;
}

function stripPass($val) {
	$val = preg_replace("/[^a-zA-Z0-9\s]/", "", $val);
	return $val;
}

//fungsi untuk ngecek nilai jika nilai kosong set nilai ke NULL jika field ditabel kamu mendukung NULL, kalo ga mendukung, ga usah dipake
// $type default = 'STR' / STRING
function isNull($value,$type='STR') {
	switch($type) {
		//untuk nilai STRING / CHARACTER
		case 'STR':
			if($value) {
				return "'".stripInput($value)."'";
			} else
				return "NULL";
			break;
		//untuk nilai STRING / CHARACTER
		case 'ESTR':
			if($value) {
				return "'".stripInput($value)."'";
			} else
				return "''";
			break;
		//untuk nilai INTEGER / FLOAT
		case 'INT':
			if($value) {
				$value = str_replace(',','',$value);
				if(is_numeric($value)) 
					return $value;
				else
					return "NULL";
			} else
				return "NULL";
			break;
		//untuk nilai CURRENCY / UANG
		case 'CUR':
			if($value) {
				$value = str_replace(',','',$value);
				if(is_numeric($value)) 
					return "'".$value."'";
				else
					return "NULL";
			} else
				return "NULL";
			break;
		//untuk nilai TANGGAL
		case 'DATE':
			if($value) {
				$tmp = explode('/',$value);
				if(strlen($tmp[0])<=1) $tmp[0] = '0'.$tmp[0];
				if(strlen($tmp[1])<=1) $tmp[1] = '0'.$tmp[1];
				$value = $tmp[2].'-'.$tmp[1].'-'.$tmp[0];
				if (preg_match("/^(\d{4})-(\d{2})-(\d{2})$/", $value, $matches)) {
					if (checkdate($matches[2], $matches[3], $matches[1]))
						return "'".$value."'";
					else
						return "NULL";
				} else
					return "NULL";
			} else
				return "NULL";
			break;
		//untuk default
		default: 
			return "NULL";
			break;
	}
}

function cFormat($val,$cond=true) {
	if($cond) {
		$val = str_replace(',','',$val);
		return $val;
	} else {
		$val = number_format($val);
		if($val==0) $val ='';
		return $val;	
	}
}
function cNilai($val,$cond=true) {
	if($cond) {
		$val = str_replace(',','',$val);
		return $val;
	} else {
		$val = number_format($val,1);
		if($val==0) $val ='';
		return $val;	
	}
}

function cDate($val) {
	if($val) {
		$tmpval = explode('-',$val);
		$val = $tmpval[2].'/'.$tmpval[1].'/'.$tmpval[0];
	}
	return $val;
}

function cDate2($val) {
	if($val) {
		$tmpval = explode('-',$val);
		$val = $tmpval[2].'-'.$tmpval[1].'-'.$tmpval[0];
	}
	return $val;
}
function cTextDate($val) {
	$day = array('','Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember');
	if($val) {
		$tmpval = explode('-',$val);
		$val = $tmpval[2].' '.$day[intval($tmpval[1])].' '.$tmpval[0];
	}
	return $val;
}

function gabungKontrakTanggal($kontrak, $tgl1, $tgl2) {
	$val = '';
	
	if($tgl1 && !$tgl2) $val = cDate($tgl1);
	if(!$tgl1 && $tgl2) $val = cDate($tgl2);
	if($tgl1 && $tgl2) $val = cDate($tgl1).' - '.cDate($tgl2);
	
	if($kontrak) $val = $kontrak.'<br />'.$val;
	
	return $val;
}

function generateArray($val) {
	$tmpVal = explode('^_^',$val);	
	if(count($tmpVal)>0)
		return $tmpVal;	
	else
		return $val;
}

function generateError($error) {
	$combine_error = '';
	for($i=0;$i<count($error);$i++) {
		$combine_error .= $error[$i].'|*|';	
	}
	$combine_error = substr($combine_error,0,strlen($combine_error)-3);
	return $combine_error;
}

function getValueByTable($query,$result) {
	$rs = mysql_query($query);
	$cnt = mysql_num_rows($rs);
	$rows = mysql_fetch_array($rs);
	if($cnt>0) 
		return $rows[$result];
	else
		return '';
}

function getPermissions($subID) {
	$acc = array();
	$rs_perm = mysql_query("select * from tbl_permissions where menu_kode = '".$subID."' and user_kode = '".$_SESSION['saga_kode']."'");
	$cnt_perm = mysql_num_rows($rs_perm);
	$rows_perm = mysql_fetch_array($rs_perm);
	if($cnt_perm>0)  {
		$acc[-1] = $rows_perm['permissions_view'];
		$acc[0] = $rows_perm['permissions_add'];
		$acc[1] = $rows_perm['permissions_edit'];
		$acc[2] = $rows_perm['permissions_delete'];
		$acc[3] = $rows_perm['permissions_grant'];
		return $acc;
	} 
}



function Noinduk()
	{
		$new_id=rand(11111,99999);
		Connected();
		$qry="SELECT * FROM tbl_user where user_kode='" . $new_id . "'";
		$sqlqry=mysql_query($qry);
		$result=mysql_fetch_array($sqlqry);
		while(!empty($result))
		{
			$new_id=rand(11111,99999);
			
			$qry="SELECT * FROM tbl_user where user_kode='" . $new_id . "'";
			$sqlqry=mysql_query($qry);
			$result=mysql_fetch_array($sqlqry);
		}
		return $new_id;
	}
function Semester()
	{
		$qry="SELECT semester FROM  tbl_user where user_kode='".$_SESSION['user_kode']."'";
		$sqlqry=mysql_query($qry);
		$result=mysql_fetch_array($sqlqry);
		if($result['semester'] == '1') $semester = 'Semester Ganjil'; 
		if($result['semester'] == '2') $semester = 'Semester Genap'; 
		
		return $result['semester'];
	}

function Kepsek()
	{
		$name='';
		$qry="SELECT * FROM configurations where jabatan ='1'";
		$sqlqry=mysql_query($qry);
		$result=mysql_fetch_array($sqlqry);
		$name= $result['value'];
		return $name;
	}
function NoteDU()
	{
		$name='';
		$qry="SELECT * FROM configurations where jabatan ='2'";
		$sqlqry=mysql_query($qry);
		$result=mysql_fetch_array($sqlqry);
		$name= $result['value'];
		return $name;
	}
	

function KodeDaftar($initial,$tabel)
	{
		$qry = mysql_query("SELECT max(".$initial.") FROM ".$tabel);
		$row = mysql_fetch_array($qry);
		if($row[0]=='') {
			$angka=date('ymd').'0001';
		}
		else{
			$angka = $row[0]+1;
		}
	return $angka;
	}
	
function nOINDUKNYA($initial,$tabel)
	{
		$qry = mysql_query("SELECT max(".$initial.") FROM ".$tabel);
		$row = mysql_fetch_array($qry);
		if($row[0]=='') {
			$angka='00001';
		}
		else{
			$angka = $row[0]+1;
		}
	return $angka;
	}
?>
