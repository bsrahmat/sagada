<?php
	require_once '../connectionmysql.php';
	Connected();
	
	$modulID = $_SESSION['module_admin'];
	
	if($modulID=='none') $modulID = '-1';
?>

        <div class="content">
            <div class="sub-nav-box">
                <ul class="sub-nav-button">
                <?php 
				if($_SESSION['type_admin']=='0')
					$qry_submenus = "select * from tbl_submenu where menu_kode = '27' order by submenu_kode ASC";
				else 
					$qry_submenus = "select * from tbl_submenu where modul_kode = '".$modulID."' and menu_kode = '27' order by submenu_kode ASC";
				
				$i = 0; $link='';
				$rs_sub_menu = mysql_query($qry_submenus);
				while($rows_sub_menu=mysql_fetch_array($rs_sub_menu)) {
					
				$qry_subaccess = "select * from tbl_permissions where user_kode = '".$_SESSION['nwip_code']."' and submenu_kode = '".$rows_sub_menu['submenu_kode']."'";
					
				$rs_sub_access = mysql_query($qry_subaccess);
				$rows_sub_access=mysql_fetch_array($rs_sub_access);	
				
				if($rows_sub_access['permissions_view']!='1') {
				if($i==0) { $link = $rows_sub_menu['menusub_link']; $selected = '-selected'; } else $selected = '';
				?>
                <li><div class="tab<? echo $selected?>" link="<? echo $rows_sub_menu['menusub_link'] ?>"><? echo $rows_sub_menu['submenu_name'] ?></div></li>
               <?php
				$i++;
				}
				}
				?>
				</ul>
            </div>
            
            <div class="body">
            	<div class="sub-content">
                     
                    <?php
					if($link) { 
					$link = str_replace('library/','',$link);
						require_once('../'.$link.'.php');
					} else {
						require_once '../error-menu.php';	
					}
					?>
                    
                </div>
            </div>
        </div>