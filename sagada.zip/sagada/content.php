		<?
			require_once 'library/connectionmysql.php';
			Connected();
			$link = 'library/submenu/home/index';
			
			
			
		?>
		
		<div class="nav-box">
            	<div class="info"><font style=" font-size:18px; color:#000;"><? echo indonesian_date (); ?></font><br /><font style="font-size:32px; color:#FF0;"><div id="clockbox"></div></font></div>
            	<div class="sub-nav-box">
                <div class="form-login">
                <h1>Login Form</h1>
                  <form action="validasi.php" method="post">
                    <table>
                    <tr>
                    <td class="fbold">Username :</td>
                    </tr>
                    <tr>
                    <td>
                        <input class="input-text" name="user_name" type="text" />
                        <pk>Tekan <b class="tunder">Enter</b> untuk memasukkan password.</p>
                    </td>
                    </tr>
                    <tr>
                    <tr>
                    <td class="fbold">Password :</td>
                    </tr>
                    <td>
                        <input class="input-text" name="pass_word" type="password" />
                        <pk><b class="tunder">Password</b> belum terisi.</p>
                    </td>
                    </tr>
                    </table>
                  </form>
                    <div class="error"></div>
                   </div>
                   
        		</div>
           </div>
            	<div class="body">
                    <div class="sub-content">
                        <?php if($link) require_once($link.'.php') ?>
                    </div>
            	</div> 