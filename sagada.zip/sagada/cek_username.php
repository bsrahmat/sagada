<?
	require_once 'admin/library/connectionmysql.php';
	Connected();

	//nich berfungsi tuk mengecek apakah ada username yg sama atau tidak, pada proses registrasi member...
	$query=mysql_query("select * from tbl_praktikan where praktikan_username='".$_GET['q']."'");
	$num=mysql_num_rows($query);
	//jika username kosong...
	if($num>0)
		echo '+OK';
	else
		echo '-ERR';
?>